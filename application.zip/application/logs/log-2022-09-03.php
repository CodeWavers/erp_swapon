<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-03 04:44:30 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-03 06:01:22 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 06:01:22 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1453826774', 'INV', '2022-09-03', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1453826774 Customer- ', 0, '3000', 1, 'OpSoxJvBbbS8Rws', '2022-09-03 06:01:22', 1)
ERROR - 2022-09-03 06:21:37 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 06:50:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
ERROR - 2022-09-03 06:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\gui_pos_invoice.php 333
ERROR - 2022-09-03 06:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\gui_pos_invoice.php 339
ERROR - 2022-09-03 06:56:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\gui_pos_invoice.php 333
ERROR - 2022-09-03 06:56:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\gui_pos_invoice.php 339
ERROR - 2022-09-03 07:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:11:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 07:11:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 07:11:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 07:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:16:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 07:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:16:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 07:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 07:17:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:17:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 07:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:17:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 07:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:17:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 07:20:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 07:20:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:20:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:20:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:20:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 07:20:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 07:23:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:23:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:23:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 07:23:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 07:23:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 07:23:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 08:16:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
ERROR - 2022-09-03 08:18:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
ERROR - 2022-09-03 08:26:05 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 09:06:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
ERROR - 2022-09-03 09:16:44 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 09:16:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
ERROR - 2022-09-03 09:19:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-09-03 09:19:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-09-03 09:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-09-03 09:29:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 09:29:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 09:29:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 09:29:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 09:29:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 09:29:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 09:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-09-03 09:33:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 09:33:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 09:33:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 09:33:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 09:33:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 09:33:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 09:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-09-03 09:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 09:59:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:00:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:00:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:00:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:01:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:01:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:01:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:01:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:04:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:05:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:06:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:08:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:08:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:08:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:28:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:28:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:29:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:29:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:29:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:29:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:29:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:29:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:30:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:30:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:30:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:30:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:30:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:30:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:30:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:31:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:31:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:31:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:31:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:32:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:32:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:32:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:32:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:32:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:32:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:40:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:40:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:40:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:40:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:40:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:40:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:40:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:40:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:40:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:40:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:40:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:40:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:41:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:46:27 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 10:46:27 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('2154134333', 'INV', '2022-09-03', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 2154134333 Customer- ', 0, '400', 1, 'OpSoxJvBbbS8Rws', '2022-09-03 10:46:27', 1)
ERROR - 2022-09-03 10:46:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:48:38 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 10:48:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:50:31 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 10:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:51:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:52:59 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 10:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:55:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 10:56:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 10:56:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 10:56:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 10:56:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 10:56:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:01:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:01:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 11:01:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 11:01:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:01:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:01:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 11:02:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:05:46 --> The upload path does not appear to be valid.
ERROR - 2022-09-03 11:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:08:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:10:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-03 11:10:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-03 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-03 11:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-03 11:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:15:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:15:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:16:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:16:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:18:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-09-03 11:19:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:26:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:27:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 706
ERROR - 2022-09-03 11:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-03 11:37:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
