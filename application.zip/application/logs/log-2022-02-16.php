<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-16 06:26:00 --> 404 Page Not Found: Cproduct/manage_finished_product
ERROR - 2022-02-16 06:28:40 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `k`.*
FROM `product_information` `a`
LEFT JOIN `products` `k` ON `k`.`barcode` = `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-16 06:28:46 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `k`.*
FROM `product_information` `a`
LEFT JOIN `products` `k` ON `k`.`barcode` = `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-16 06:32:59 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-02-16 06:32:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-02-16 06:32:59 --> Severity: Notice --> Undefined index: first_name C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 437
ERROR - 2022-02-16 06:32:59 --> Severity: Notice --> Undefined index: last_name C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 438
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:43 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:44 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$image C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 237
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 239
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 241
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 244
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 247
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 250
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$finished_raw C:\laragon\www\git\erp_swapon\application\models\Products.php 253
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: json_data C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 260
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_code C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\laragon\www\git\erp_swapon\application\models\Products.php 263
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Products.php 266
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$product_model C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 269
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\laragon\www\git\erp_swapon\application\models\Products.php 270
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: totalRecordwithFilter C:\laragon\www\git\erp_swapon\application\models\Products.php 289
ERROR - 2022-02-16 06:38:45 --> Severity: Notice --> Undefined variable: totalRecords C:\laragon\www\git\erp_swapon\application\models\Products.php 290
ERROR - 2022-02-16 06:40:50 --> Severity: Notice --> Undefined variable: totalRecordwithFilter C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 06:40:50 --> Severity: Notice --> Undefined variable: totalRecords C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 06:43:00 --> Severity: Notice --> Undefined property: stdClass::$allcount C:\laragon\www\git\erp_swapon\application\models\Products.php 226
ERROR - 2022-02-16 06:45:21 --> Severity: Notice --> Undefined property: stdClass::$allcount C:\laragon\www\git\erp_swapon\application\models\Products.php 226
ERROR - 2022-02-16 06:45:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 06:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:45:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 06:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 06:45:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:45:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 06:45:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 06:45:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 06:45:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:45:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:45:54 --> Severity: Notice --> Undefined property: stdClass::$allcount C:\laragon\www\git\erp_swapon\application\models\Products.php 226
ERROR - 2022-02-16 06:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:46:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 06:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:46:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 06:46:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 06:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:47:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:47:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 06:47:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 06:47:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:47:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 06:47:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:47:19 --> Severity: Notice --> Trying to get property 'count' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 267
ERROR - 2022-02-16 06:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:48:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 06:48:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 06:48:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 06:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:48:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:48:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:48:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 06:49:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 06:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 06:49:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 07:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:06:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 07:06:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 07:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:06:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 07:06:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: draw C:\laragon\www\git\erp_swapon\application\models\Products.php 198
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: start C:\laragon\www\git\erp_swapon\application\models\Products.php 199
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: length C:\laragon\www\git\erp_swapon\application\models\Products.php 200
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Products.php 201
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 201
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 201
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: columns C:\laragon\www\git\erp_swapon\application\models\Products.php 202
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 202
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 202
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Products.php 203
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 203
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 203
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Undefined index: search C:\laragon\www\git\erp_swapon\application\models\Products.php 204
ERROR - 2022-02-16 07:06:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 204
ERROR - 2022-02-16 07:07:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:07:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 07:07:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 07:07:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 07:07:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:07:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:07:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 07:07:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 07:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:07:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 07:09:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:09:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 07:09:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:09:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:09:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 07:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 07:12:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 07:12:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 07:12:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 07:12:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:12:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:13:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:13:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 07:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:13:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 07:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 07:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:48 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:20:49 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:16 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 90
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 91
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 93
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Undefined variable: record C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:21:17 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 95
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:10 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sl C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 92
ERROR - 2022-02-16 08:43:11 --> Severity: Notice --> Undefined property: stdClass::$sku C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 94
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:25 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:02:26 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:58 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:05:59 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:10:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:10:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:10:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:10:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:16:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:16:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:16:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:16:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:16:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:16:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:28:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:28:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:28:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:28:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:28:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:28:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:09 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:10 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:11 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:12 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 09:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:37:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:45:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:45:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:45:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:50:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:50:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:50:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:50:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:50:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:50:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:51:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:51:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:51:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:51:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:53:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:53:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:53:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:53:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:55:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:56:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:56:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:56:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:56:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:58:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:58:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:58:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:58:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:58:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:59:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 09:59:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 09:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 09:59:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 09:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:00:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:02:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:02:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:02:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:03:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-16 10:03:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-16 10:03:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-16 10:03:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-16 10:03:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-16 10:05:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:05:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:06:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:06:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:06:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:06:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:07:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:07:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:07:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:07:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:08:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:08:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:08:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:08:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:08:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:29:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:29:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:29:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:29:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:30:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:30:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:30:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:30:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:30:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:31:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:31:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:31:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:31:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:31:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:31:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:34:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:34:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:34:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:34:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:34:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:34:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:34:31 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 225
ERROR - 2022-02-16 10:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 227
ERROR - 2022-02-16 10:34:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Products.php 261
ERROR - 2022-02-16 10:34:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Products.php 262
ERROR - 2022-02-16 10:37:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:37:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:37:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:37:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:37:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:37:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:37:40 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 225
ERROR - 2022-02-16 10:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 227
ERROR - 2022-02-16 10:38:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:38:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:38:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:38:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:38:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:38:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:38:41 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 225
ERROR - 2022-02-16 10:38:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 227
ERROR - 2022-02-16 10:39:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:39:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:39:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:39:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:39:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:39:38 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 225
ERROR - 2022-02-16 10:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 227
ERROR - 2022-02-16 10:44:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:44:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:44:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:44:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:44:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:44:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:44:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 227
ERROR - 2022-02-16 10:44:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:44:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:44:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:44:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:44:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:44:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:45:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:45:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:45:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:45:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:45:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:45:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:46:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:46:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:46:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:46:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:47:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:47:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:47:09 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 225
ERROR - 2022-02-16 10:47:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:47:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:47:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:47:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:47:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:47:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:48:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:48:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:49:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:49:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:54:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:54:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:54:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:54:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:54:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:54:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:55:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:56:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:56:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:56:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:56:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:56:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:56:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:56:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:56:58 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 225
ERROR - 2022-02-16 10:56:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 231
ERROR - 2022-02-16 10:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:58:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:58:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:59:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:59:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 10:59:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 10:59:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 10:59:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 10:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:00:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:00:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:00:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:00:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:00:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:05:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:05:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:05:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:05:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:05:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:08:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:08:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:08:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:08:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:08:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:08:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:08:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:08:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:09:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:09:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:09:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:09:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:09:13 --> 404 Page Not Found: Cproduct/uploads
ERROR - 2022-02-16 11:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:11:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:11:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:11:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:11:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: button C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined variable: base_url C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:11:42 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 234
ERROR - 2022-02-16 11:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:12:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:12:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:12:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:12:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:13:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:13:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:13:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:13:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:13:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:13:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:15:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:15:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:15:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:15:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:15:27 --> Severity: Notice --> Undefined property: stdClass::$price C:\laragon\www\git\erp_swapon\application\models\Products.php 243
ERROR - 2022-02-16 11:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:16:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:16:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:16:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:16:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:16:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:18:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:19:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:19:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:19:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:19:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:19:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:19:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:19:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:19:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:22:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:22:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:22:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:22:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:22:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:22:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:23:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:23:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:23:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:23:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:23:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:28:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:28:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:30:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:30:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:30:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:30:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:30:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:30:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:31:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:31:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:31:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:31:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:31:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:31:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:31:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:31:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:34:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:34:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:40:07 --> 404 Page Not Found: Cproduct/Cproduct
ERROR - 2022-02-16 11:40:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:40:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:40:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:40:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:40:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:41:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:41:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:41:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:41:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:41:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:54:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-16 11:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-16 11:54:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-16 11:54:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-16 11:54:49 --> 404 Page Not Found: Assets/plugins
