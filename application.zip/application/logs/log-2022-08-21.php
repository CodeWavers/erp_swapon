<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-21 05:22:15 --> The upload path does not appear to be valid.
ERROR - 2022-08-21 05:22:15 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6587725497', 'INV-CC', '2022-08-21', NULL, 'Courier Debit For Invoice No -  1042 Courier  Karanfuli Paribahan', 663.1, 0, 1, 'OpSoxJvBbbS8Rws', '2022-08-21 05:22:15', 1)
ERROR - 2022-08-21 05:22:15 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6587725497', 'INV-CC', '2022-08-21', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1042 Courier  Karanfuli Paribahan', NULL, 0, 1, 'OpSoxJvBbbS8Rws', '2022-08-21 05:22:15', 1)
ERROR - 2022-08-21 05:27:52 --> The upload path does not appear to be valid.
ERROR - 2022-08-21 05:27:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7485436746', 'INV-CC', '2022-08-21', NULL, 'Courier Debit For Invoice No -  1043 Courier  Karanfuli Paribahan', 0, 1655.75, 1, 'OpSoxJvBbbS8Rws', '2022-08-21 05:27:52', 1)
ERROR - 2022-08-21 05:27:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7485436746', 'INV-CC', '2022-08-21', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1043 Courier  Karanfuli Paribahan', 20, 0, 1, 'OpSoxJvBbbS8Rws', '2022-08-21 05:27:52', 1)
ERROR - 2022-08-21 06:16:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:16:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:16:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:16:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:16:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:28:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:28:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:28:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:28:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:28:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:30:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:30:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:30:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:30:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:34:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:34:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:34:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:34:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:34:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:34:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:34:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:34:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:38:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:38:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:38:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:38:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:42:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:42:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:42:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:42:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:42:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:42:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:42:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 06:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 06:46:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 06:46:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:46:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 06:46:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 07:43:12 --> The upload path does not appear to be valid.
ERROR - 2022-08-21 07:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-21 07:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 640
ERROR - 2022-08-21 07:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 633
ERROR - 2022-08-21 07:51:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 636
ERROR - 2022-08-21 07:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 636
ERROR - 2022-08-21 08:12:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 636
ERROR - 2022-08-21 08:12:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 636
ERROR - 2022-08-21 08:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 636
ERROR - 2022-08-21 08:13:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 636
ERROR - 2022-08-21 08:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-21 09:11:24 --> Severity: error --> Exception: syntax error, unexpected '{' C:\laragon\www\git\erp_swapon\application\views\return\return_list.php 132
ERROR - 2022-08-21 11:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:36:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 11:36:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 11:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:36:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 11:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:37:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 11:37:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 11:37:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:37:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 11:37:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 11:39:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 11:39:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 11:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-21 11:39:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-21 11:39:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:39:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 11:40:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-21 11:40:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-21 11:40:02 --> 404 Page Not Found: Assets/datatables
