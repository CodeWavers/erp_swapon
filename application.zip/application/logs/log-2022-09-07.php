<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-07 11:50:21 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-07 11:52:09 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 12:35:45 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 12:36:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 12:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 12:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 12:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 12:43:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 12:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 12:58:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 15:05:51 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-07 15:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 15:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 15:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 15:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-07 15:32:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:34:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:35:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:36:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:38:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:39:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:40:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:41:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-07 15:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-07 15:44:42 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220907154442', 'Purchase', '2022-09-07', NULL, 'Supplier .Factory', 0, '2000.00', 1, 'OpSoxJvBbbS8Rws', '2022-09-07', 1)
ERROR - 2022-09-07 15:47:02 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 15:47:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:49:21 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7889316143', 'INV', '2022-09-07', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 7889316143 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-09-07 15:49:21', 1)
ERROR - 2022-09-07 15:49:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-09-07 15:51:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 15:53:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 700
ERROR - 2022-09-07 16:02:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 16:06:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 16:15:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 16:19:46 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 16:19:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 16:22:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 16:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 1421
ERROR - 2022-09-07 16:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\due_invoice_list.php 68
ERROR - 2022-09-07 16:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 1421
ERROR - 2022-09-07 16:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\due_invoice_list.php 68
ERROR - 2022-09-07 16:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 1421
ERROR - 2022-09-07 16:43:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\due_invoice_list.php 68
ERROR - 2022-09-07 17:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 17:05:31 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 17:05:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 17:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 17:09:13 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 17:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-07 17:14:13 --> The upload path does not appear to be valid.
ERROR - 2022-09-07 17:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
