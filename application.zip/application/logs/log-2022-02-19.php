<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-19 05:18:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 05:18:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 05:18:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 05:18:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 05:18:50 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-19 06:19:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-19 06:19:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-19 06:19:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-19 06:25:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-19 06:55:42 --> Query error: Unknown column 'a.PHeadName' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadName`
FROM `acc_transaction` `a`
JOIN `acc_coa` `b` ON `a`.`COAID`=`b`.`HeadCode`
JOIN `invoice` `i` ON `i`.`invoice_id`=`a`.`VNo`
WHERE `a`.`PHeadName` = 'INV-CC'
AND `a`.`IsAppove` = 1
ORDER BY `a`.`VDate` DESC
 LIMIT 10
ERROR - 2022-02-19 07:42:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 07:42:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 07:42:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 07:42:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 07:42:21 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-19 07:42:38 --> Query error: Unknown column 'a.PHeadName' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadName`
FROM `acc_transaction` `a`
JOIN `acc_coa` `b` ON `a`.`COAID`=`b`.`HeadCode`
JOIN `invoice` `i` ON `i`.`invoice_id`=`a`.`VNo`
WHERE `a`.`PHeadName` = 'Courier Ledger'
AND `a`.`IsAppove` = 1
ORDER BY `a`.`VDate` DESC
 LIMIT 10
ERROR - 2022-02-19 09:13:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 09:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 09:13:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 09:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 09:13:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-19 09:25:05 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 09:25:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-19 09:25:05 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 09:25:05 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-19 09:25:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-19 10:14:10 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-02-19 10:14:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-02-19 10:14:10 --> Severity: Notice --> Undefined index: first_name C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 437
ERROR - 2022-02-19 10:14:10 --> Severity: Notice --> Undefined index: last_name C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 438
ERROR - 2022-02-19 10:15:08 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-19 10:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-19 10:15:08 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-19 10:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-19 10:15:42 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 427
ERROR - 2022-02-19 10:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 427
ERROR - 2022-02-19 10:15:42 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 433
ERROR - 2022-02-19 10:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 433
ERROR - 2022-02-19 10:16:04 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-19 10:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-19 10:16:04 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-19 10:16:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-19 10:43:29 --> Severity: Notice --> Undefined property: Corder::$lorder C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:29 --> Severity: error --> Exception: Call to a member function finished_product_list() on null C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:39 --> Severity: Notice --> Undefined property: Corder::$lorder C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:39 --> Severity: error --> Exception: Call to a member function finished_product_list() on null C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:40 --> Severity: Notice --> Undefined property: Corder::$lorder C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:40 --> Severity: error --> Exception: Call to a member function finished_product_list() on null C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:40 --> Severity: Notice --> Undefined property: Corder::$lorder C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:40 --> Severity: error --> Exception: Call to a member function finished_product_list() on null C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:40 --> Severity: Notice --> Undefined property: Corder::$lorder C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:40 --> Severity: error --> Exception: Call to a member function finished_product_list() on null C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:41 --> Severity: Notice --> Undefined property: Corder::$lorder C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:43:41 --> Severity: error --> Exception: Call to a member function finished_product_list() on null C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 28
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 275
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 275
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 276
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 276
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 277
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 277
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 280
ERROR - 2022-02-19 10:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduct.php 280
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 10:58:28 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 301
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:13:53 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:03 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:14:55 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:15:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:15:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:15:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:15:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:15:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:15:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:33 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:15:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:15:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:15:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:15:43 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:18:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:19:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:19:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:08 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:19:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:19:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:19:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_id C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:00 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:20:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:20:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:20:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:20:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:20:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:20:34 --> Severity: Notice --> Undefined property: stdClass::$product_name C:\laragon\www\git\erp_swapon\application\models\Products.php 305
ERROR - 2022-02-19 11:21:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:21:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:21:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:22:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:22:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:22:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:22:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:22:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:22:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:23:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:23:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:23:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:23:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:23:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:23:34 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Products.php 302
ERROR - 2022-02-19 11:26:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:26:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:26:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:26:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:26:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:26:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:26:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:27:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:27:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:27:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:27:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:27:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:29:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:29:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:29:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:29:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-19 11:29:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:29:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-19 11:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:30:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-19 11:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-19 11:30:09 --> 404 Page Not Found: Assets/plugins
