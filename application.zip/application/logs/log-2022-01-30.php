<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-30 04:51:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 04:51:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 04:51:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 04:51:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 04:51:16 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-01-30 05:25:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 05:25:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 05:25:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 05:25:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 05:25:39 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-01-30 05:26:45 --> Severity: Notice --> Undefined variable: html C:\laragon\www\git\erp_swapon\application\controllers\Permission.php 172
ERROR - 2022-01-30 05:27:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 05:27:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 05:27:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 05:27:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 05:27:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-01-30 05:36:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 05:36:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 05:36:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 05:36:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 05:36:29 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-01-30 05:36:33 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:36:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 05:37:04 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:37:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 05:37:35 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:37:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 05:40:55 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 05:42:24 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:42:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 05:53:20 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:53:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 05:55:17 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:57 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:58 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:58 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:58 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:58 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:58 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:59 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:59 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:55:59 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:56:00 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:56:00 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:56:00 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 05:56:00 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:04:35 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:04:36 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:04:36 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:13:29 --> Severity: Notice --> Trying to get property 'outlet_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1181
ERROR - 2022-01-30 06:13:29 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1184
ERROR - 2022-01-30 06:13:29 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1184
ERROR - 2022-01-30 06:13:55 --> Severity: Notice --> Trying to get property 'outlet_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1181
ERROR - 2022-01-30 06:14:48 --> Severity: Notice --> Trying to get property 'outlet_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1181
ERROR - 2022-01-30 06:15:43 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 06:16:40 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:16:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 06:16:49 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:16:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 06:17:13 --> Severity: Notice --> Trying to get property 'outlet_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1181
ERROR - 2022-01-30 06:17:53 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:17:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 06:35:05 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:35:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 06:40:12 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1196
ERROR - 2022-01-30 06:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-01-30 10:18:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 10:18:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-30 10:18:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 10:18:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-30 10:18:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-01-30 10:18:22 --> Query error: Table 'erp_swapon.product_model' doesn't exist - Invalid query: SELECT `a`.*, `b`.*, `c`.*, `d`.*, `e`.*, `f`.*, `g`.*
FROM `pr_rqsn` `a`
JOIN `pr_rqsn_details` `b` ON `b`.`pr_rqsn_id` = `a`.`pr_rqsn_id`
JOIN `product_information` `c` ON `c`.`product_id` = `b`.`product_id`
LEFT JOIN `product_category` `d` ON `d`.`category_id` = `c`.`category_id`
LEFT JOIN `product_brand` `f` ON `f`.`brand_id` = `c`.`brand_id`
LEFT JOIN `product_model` `g` ON `g`.`model_id` = `c`.`product_model`
WHERE `a`.`status` = 1
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 83
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 88
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 89
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 91
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: purchase_qty C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 93
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 101
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 103
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 104
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 106
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 108
ERROR - 2022-01-30 10:19:13 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 109
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: purchase_qty C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 86
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 94
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 96
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 97
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 99
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 101
ERROR - 2022-01-30 10:21:51 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 102
ERROR - 2022-01-30 10:22:50 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 94
ERROR - 2022-01-30 10:22:50 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 96
ERROR - 2022-01-30 10:22:50 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 97
ERROR - 2022-01-30 10:22:50 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 99
ERROR - 2022-01-30 10:22:50 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 101
ERROR - 2022-01-30 10:22:50 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 102
ERROR - 2022-01-30 10:29:07 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 110
ERROR - 2022-01-30 10:29:07 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 112
ERROR - 2022-01-30 10:29:07 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 113
ERROR - 2022-01-30 10:29:07 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 115
ERROR - 2022-01-30 10:29:07 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 117
ERROR - 2022-01-30 10:29:07 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 118
ERROR - 2022-01-30 10:30:44 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 106
ERROR - 2022-01-30 10:30:44 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 108
ERROR - 2022-01-30 10:30:44 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 109
ERROR - 2022-01-30 10:30:44 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 111
ERROR - 2022-01-30 10:30:44 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 113
ERROR - 2022-01-30 10:30:44 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 114
ERROR - 2022-01-30 10:31:08 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 106
ERROR - 2022-01-30 10:31:08 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 108
ERROR - 2022-01-30 10:31:08 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 109
ERROR - 2022-01-30 10:31:08 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 111
ERROR - 2022-01-30 10:31:08 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 113
ERROR - 2022-01-30 10:31:08 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 114
ERROR - 2022-01-30 10:31:29 --> Severity: Notice --> Undefined index: subcat_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 103
ERROR - 2022-01-30 10:31:29 --> Severity: Notice --> Undefined index: parts C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 105
ERROR - 2022-01-30 10:31:29 --> Severity: Notice --> Undefined index: sku C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 106
ERROR - 2022-01-30 10:31:29 --> Severity: Notice --> Undefined index: model_name C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 108
ERROR - 2022-01-30 10:31:29 --> Severity: Notice --> Undefined index: rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 110
ERROR - 2022-01-30 10:31:29 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 111
ERROR - 2022-01-30 11:23:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:23:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:23:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:23:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:23:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:23:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:23:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:23:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:23:44 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:23:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:23:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:23:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:23:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:23:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:23:57 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:26:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:26:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:26:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:26:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:26:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:26:20 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:27:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:27:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:27:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:27:20 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:27:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:27:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:27:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:27:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:28:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:28:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:28:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:28:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:28:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:28:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:28:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:28:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:28:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:28:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:28:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:29:23 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:29:36 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:31:11 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:34:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:34:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:34:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:34:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:34:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:35:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:35:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:35:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:35:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:35:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:38:41 --> Query error: Unknown column 'a.quantity' in 'field list' - Invalid query: SELECT `a`.*, `b`.*, `c`.*, SUM(a.quantity) as qty
FROM `pr_rqsn` `a`
JOIN `pr_rqsn_details` `b` ON `b`.`pr_rqsn_id` = `a`.`pr_rqsn_id`
JOIN `product_information` `c` ON `c`.`product_id` = `b`.`product_id`
WHERE `a`.`status` = 1
GROUP BY `b`.`product_id`
ERROR - 2022-01-30 11:39:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:39:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:39:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:39:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:39:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:42:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:42:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:42:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:42:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:48:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:48:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-30 11:48:15 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-30 11:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:48:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-30 11:48:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-30 11:48:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-30 11:48:20 --> 404 Page Not Found: Assets/plugins
