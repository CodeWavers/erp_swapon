<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-08 14:53:29 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-08 14:54:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:12:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-08 15:12:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:15:35 --> The upload path does not appear to be valid.
ERROR - 2022-10-08 15:15:35 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9247286827', 'INV-CC', '2022-10-08', NULL, 'Customer debit For Invoice No -  1058 Customer ', '80.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-10-08 15:15:35', 1)
ERROR - 2022-10-08 15:15:35 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 996
ERROR - 2022-10-08 15:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-08 15:22:38 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1001
ERROR - 2022-10-08 15:22:38 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '168884753439142', NULL, '2926399585', '16945P', NULL, '2', '5', '2022-10-01', '2022-10-08', '1716.00', '5', '529.00', 0, '3260.4', NULL, '', 2)
ERROR - 2022-10-08 15:22:38 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('2926399585', 'Replacement', '2022-10-08', NULL, 'Customer account Debit Amount For Customer Invoice NO - 1059 Customer- ', '6305.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-10-08 15:22:38', 1)
ERROR - 2022-10-08 15:22:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:24:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:24:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:25:41 --> The upload path does not appear to be valid.
ERROR - 2022-10-08 15:25:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:26:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 15:30:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:13:17 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:18:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:20:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:21:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:22:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:23:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:23:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:23:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:23:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:24:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:25:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 402
ERROR - 2022-10-08 16:25:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:26:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:27:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 339
ERROR - 2022-10-08 16:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 339
ERROR - 2022-10-08 16:27:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:28:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-08 16:29:30 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1001
ERROR - 2022-10-08 16:29:30 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '686184333698679', NULL, '4188829787', '16945P', '118', '1', '2', '2022-10-08', '2022-10-08', '1716.00', '', '0.00', 0, '1716', NULL, '', 2)
ERROR - 2022-10-08 16:29:30 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '512395522148266', NULL, '4188829787', '16967P', '118', '1', '4', '2022-10-08', '2022-10-08', '1758.00', '', '0.00', 0, '1758', NULL, '', 2)
ERROR - 2022-10-08 16:29:31 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:34:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-08 16:46:43 --> The upload path does not appear to be valid.
ERROR - 2022-10-08 16:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-08 16:47:35 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1001
ERROR - 2022-10-08 16:47:35 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '763633866297328', NULL, '2318192785', '16945P', '118', '2', '5', '2022-10-08', '2022-10-08', '100.00', '', '0.00', 0, '200', NULL, '', 2)
ERROR - 2022-10-08 16:47:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:48:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:52:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:55:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:55:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:56:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 16:57:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-08 17:25:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-08 17:26:10 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-08 17:27:05 --> The upload path does not appear to be valid.
ERROR - 2022-10-08 17:27:05 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4648394865', 'INV-CC', '2022-10-08', NULL, 'Customer debit For Invoice No -  1064 Customer Shameem', '6580.00', 0, 1, 'aagS5NNVIOKoWQc', '2022-10-08 17:27:05', 1)
ERROR - 2022-10-08 17:27:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 996
