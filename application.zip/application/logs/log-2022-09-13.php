<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-13 10:17:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-13 10:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-13 10:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-13 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 219
ERROR - 2022-09-13 11:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 75
ERROR - 2022-09-13 14:29:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-13 14:39:50 --> The upload path does not appear to be valid.
ERROR - 2022-09-13 14:39:50 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4634289133', 'INV', '2022-09-13', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 4634289133 Customer- ', 0, '20000', 1, 'OpSoxJvBbbS8Rws', '2022-09-13 14:39:50', 1)
ERROR - 2022-09-13 14:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:43:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:43:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-13 14:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-13 14:48:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:48:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:48:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:48:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:48:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:48:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:49:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:49:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:49:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:50:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 14:50:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 198
ERROR - 2022-09-13 14:50:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 216
ERROR - 2022-09-13 14:50:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 234
ERROR - 2022-09-13 15:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 15:31:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 15:31:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-13 15:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:34:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 15:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:34:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 15:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-13 15:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:34:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-13 15:34:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 15:34:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 15:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:35:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:35:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-13 15:35:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 15:35:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:35:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 15:35:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:35:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-13 15:35:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 15:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:35:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 15:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-13 15:36:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 15:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 15:36:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 15:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 16:45:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-13 16:48:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-13 16:49:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-13 17:05:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-13 17:14:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-13 17:14:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-13 17:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-13 17:20:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-13 17:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 17:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 17:21:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-13 17:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-13 17:21:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-13 17:21:51 --> 404 Page Not Found: Assets/css
