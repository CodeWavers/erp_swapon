<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-10 05:15:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 05:15:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 05:15:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 05:15:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 05:15:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 05:15:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 05:47:22 --> The upload path does not appear to be valid.
ERROR - 2022-08-10 06:24:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:24:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:24:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:24:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:24:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 337
ERROR - 2022-08-10 06:24:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 337
ERROR - 2022-08-10 06:24:57 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:24:57 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:25:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:25:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:25:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 337
ERROR - 2022-08-10 06:26:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:26:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:27:08 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:27:08 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 333
ERROR - 2022-08-10 06:43:04 --> The upload path does not appear to be valid.
ERROR - 2022-08-10 06:45:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-10 06:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 06:51:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 06:51:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 06:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 06:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 06:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:05:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:05:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:05:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:06:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:06:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:06:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:07:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\supplier_payment_form.php 179
ERROR - 2022-08-10 08:07:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\supplier_payment_form.php 185
ERROR - 2022-08-10 08:07:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:07:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:07:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:07:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:07:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:07:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:07:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:07:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\supplier_payment_form.php 179
ERROR - 2022-08-10 08:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\supplier_payment_form.php 185
ERROR - 2022-08-10 08:08:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:08:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:08:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:08:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:08:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:08:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:10:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:10:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:10:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:10:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:10:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:12:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 08:12:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 08:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 08:12:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 08:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:22:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 09:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:22:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 09:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:22:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 09:23:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:23:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 09:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:23:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 09:23:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 09:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:46:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 09:46:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 09:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 09:46:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 09:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:01:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 10:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:01:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 10:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 10:05:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:05:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 10:05:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 10:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:05:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 10:05:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:06:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:06:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 10:06:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 10:06:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:06:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 10:06:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:07:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 10:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:07:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 10:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:07:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 10:08:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:08:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-10 10:08:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-10 10:08:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-10 10:08:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-10 10:08:10 --> 404 Page Not Found: Assets/js
