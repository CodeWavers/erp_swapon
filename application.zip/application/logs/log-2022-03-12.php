<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-12 04:48:16 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-12 04:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 562
ERROR - 2022-03-12 04:52:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 562
ERROR - 2022-03-12 04:54:19 --> Query error: Column 'outlet_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `outlet_warehouse` `a`
JOIN `users` `b` ON `a`.`user_id`=`b`.`user_id`
WHERE `outlet_id` = 'VC4C6BTBRLL57PF'
ERROR - 2022-03-12 04:54:19 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 437
ERROR - 2022-03-12 05:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 570
ERROR - 2022-03-12 05:30:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 570
ERROR - 2022-03-12 05:30:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 440
ERROR - 2022-03-12 05:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 570
ERROR - 2022-03-12 05:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 570
ERROR - 2022-03-12 05:34:29 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:34:29 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:34:56 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:34:56 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:07 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:07 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:08 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:08 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:08 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:08 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:08 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:08 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:09 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:09 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:09 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:09 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:36:09 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `x`.`first_name`, `x`.`last_name`, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:36:09 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 05:38:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-12 05:39:38 --> Query error: Unknown table 'b' - Invalid query: SELECT `a`.*, `b`.*, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
 LIMIT 7
ERROR - 2022-03-12 05:39:38 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1768
ERROR - 2022-03-12 05:39:52 --> Query error: Unknown table 'b' - Invalid query: SELECT `a`.*, `b`.*, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
LEFT JOIN `users` `x` ON `a`.`send_by` = `x`.`user_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
 LIMIT 7
ERROR - 2022-03-12 05:39:52 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1768
ERROR - 2022-03-12 05:40:06 --> Query error: Unknown table 'b' - Invalid query: SELECT `a`.*, `b`.*, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
 LIMIT 7
ERROR - 2022-03-12 05:40:06 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1767
ERROR - 2022-03-12 05:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 570
ERROR - 2022-03-12 05:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 570
ERROR - 2022-03-12 05:42:55 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*, `sz`.`size_name`, `cl`.`color_name`, `d`.`product_name`, `d`.`product_model`
FROM `rqsn` `a`
JOIN `rqsn_details` `b` ON `a`.`rqsn_id` = `b`.`rqsn_id`
JOIN `product_information` `d` ON `d`.`product_id`=`b`.`product_id`
LEFT JOIN `size_list` `sz` ON `d`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `d`.`color`=`cl`.`color_id`
LEFT JOIN `users` `x` ON `a`.`send_by`=`x`.`user_id`
WHERE `a`.`to_id` != 3
AND `b`.`status` = 3
AND `a`.`rqsn_id` = '1184164035'
ORDER BY `a`.`date` DESC
ERROR - 2022-03-12 05:42:55 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1769
ERROR - 2022-03-12 07:04:20 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-12 07:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 07:16:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-12 07:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 07:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 07:16:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-12 07:16:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-12 08:11:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-12 08:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:11:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-12 08:11:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-12 08:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-12 08:12:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-12 08:12:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-12 08:12:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-12 08:12:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-12 08:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 08:12:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-12 08:25:06 --> Severity: error --> Exception: syntax error, unexpected ')' C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 81
ERROR - 2022-03-12 10:14:41 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-12 10:36:03 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-12 10:36:14 --> 404 Page Not Found: Cretrun_m/courier_payment
ERROR - 2022-03-12 10:39:23 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-12 10:46:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 10:46:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-12 10:46:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 10:46:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 10:46:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-12 10:46:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-12 10:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 10:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-12 10:46:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-12 10:46:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 10:46:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-12 10:46:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-12 10:51:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 277
ERROR - 2022-03-12 10:51:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 295
ERROR - 2022-03-12 10:51:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 313
ERROR - 2022-03-12 10:51:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 277
ERROR - 2022-03-12 10:51:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 295
ERROR - 2022-03-12 10:51:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 313
ERROR - 2022-03-12 10:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 277
ERROR - 2022-03-12 10:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 295
ERROR - 2022-03-12 10:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 313
ERROR - 2022-03-12 11:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 277
ERROR - 2022-03-12 11:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 295
ERROR - 2022-03-12 11:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 313
