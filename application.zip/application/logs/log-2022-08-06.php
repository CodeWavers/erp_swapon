<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-06 06:19:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 06:19:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 06:19:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 06:19:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 06:19:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 06:19:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 12:19:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 280
ERROR - 2022-08-06 12:19:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-06 06:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 06:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 06:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 06:33:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 06:33:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 06:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:39:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:39:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:39:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:39:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:39:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:39:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:44:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:44:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:45:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:45:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:45:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:55:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:55:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:55:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:55:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:55:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:57:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:57:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:58:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:58:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 07:59:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 07:59:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 07:59:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 07:59:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 08:05:23 --> Query error: Column 'shipping_cost' cannot be null - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `date`, `agg_id`, `total_amount`, `invoice`, `paid_amount`, `due_amount`, `shipping_cost`, `sale_type`, `courier_condtion`, `sales_by`, `status`, `payment_type`, `delivery_type`, `courier_id`, `branch_id`, `outlet_id`, `reciever_id`, `receiver_number`, `courier_status`) VALUES ('1214136429', '3574', '2022-08-06', NULL, '-349.00', 1029, '0', '-349.00', NULL, NULL, NULL, 'OpSoxJvBbbS8Rws', 2, 1, NULL, NULL, NULL, 'HK7TGDT69VFMXB7', NULL, NULL, NULL)
ERROR - 2022-08-06 08:05:23 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1214136429', 'INV', '2022-08-06', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1214136429 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-08-06 08:05:23', 1)
ERROR - 2022-08-06 08:05:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-06 09:50:28 --> Query error: Column 'shipping_cost' cannot be null - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `date`, `agg_id`, `total_amount`, `invoice`, `paid_amount`, `due_amount`, `shipping_cost`, `sale_type`, `courier_condtion`, `sales_by`, `status`, `payment_type`, `delivery_type`, `courier_id`, `branch_id`, `outlet_id`, `reciever_id`, `receiver_number`, `courier_status`) VALUES ('6544686962', '3574', '2022-08-06', NULL, '0.00', 1029, '0', '0.00', NULL, NULL, NULL, 'OpSoxJvBbbS8Rws', 2, 1, NULL, NULL, NULL, 'HK7TGDT69VFMXB7', NULL, NULL, NULL)
ERROR - 2022-08-06 09:50:28 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6544686962', 'INV', '2022-08-06', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6544686962 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-08-06 09:50:28', 1)
ERROR - 2022-08-06 09:50:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-06 09:54:57 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:54:57 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:54:57 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:54:57 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:55:08 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:55:08 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:55:08 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:55:08 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:55:28 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:55:28 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:55:28 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:55:28 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:55:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 09:55:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 09:55:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 09:55:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 09:55:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 09:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 09:55:47 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:55:47 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-08-06 09:55:47 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:55:47 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-08-06 09:57:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 09:57:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-06 09:57:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-06 09:57:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 09:57:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-06 09:57:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-06 10:05:16 --> The upload path does not appear to be valid.
ERROR - 2022-08-06 10:06:36 --> 404 Page Not Found: My-assets/image
