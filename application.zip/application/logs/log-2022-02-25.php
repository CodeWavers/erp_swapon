<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-25 16:02:55 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-25 16:02:55 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-25 16:02:55 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-25 16:02:55 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-25 16:02:55 --> Severity: Warning --> A non-numeric value encountered F:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-25 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-25 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-25 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-25 16:08:29 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-25 16:08:29 --> Severity: Warning --> A non-numeric value encountered F:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-25 16:08:35 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-25 16:08:35 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-25 16:08:35 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-25 16:08:35 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-25 16:08:35 --> Severity: Warning --> A non-numeric value encountered F:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-25 16:27:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-25 16:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-25 16:27:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-25 16:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-25 16:27:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-25 16:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-25 16:28:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-25 16:28:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-25 16:28:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-25 16:28:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-25 16:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-25 16:28:07 --> 404 Page Not Found: Assets/js
