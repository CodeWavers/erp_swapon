<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-14 11:19:35 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-14 11:51:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-14 11:51:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-14 11:52:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-14 11:52:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-14 11:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-14 11:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-14 12:02:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-14 12:02:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-14 12:02:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-14 12:02:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-14 12:02:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-14 12:02:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-14 12:17:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-14 12:17:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-14 12:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-14 12:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-14 12:30:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-14 12:30:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-14 20:29:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-14 20:30:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-14 20:30:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-14 20:30:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-14 20:30:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-14 20:30:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-14 20:30:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-14 23:19:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-14 23:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 187
ERROR - 2022-09-14 23:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
