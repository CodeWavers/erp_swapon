<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-23 04:44:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-23 04:44:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-23 04:44:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-23 04:44:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-23 04:44:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-23 05:27:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-23 05:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-23 05:27:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-23 05:27:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-23 05:27:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-23 05:28:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:28:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:28:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:28:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:28:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:28:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:30:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:30:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:30:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:30:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:31:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:31:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:31:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:31:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:31:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:31:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:33:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:33:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:33:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:33:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:33:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:33:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:34:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:34:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:34:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:36:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:36:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:36:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:36:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:36:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:36:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:36:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:36:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:36:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:38:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:38:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:38:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:38:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:38:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:38:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:38:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:38:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:38:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:38:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:38:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:57:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:57:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:57:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:57:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:57:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:58:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:58:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:58:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:58:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:58:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:59:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:59:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:59:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:59:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:59:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:59:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 05:59:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 05:59:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 05:59:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 05:59:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:22:21 --> 404 Page Not Found: Admin_dashboard/Corder
ERROR - 2022-03-23 06:23:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:23:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:23:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:23:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:23:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:23:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:23:14 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 272
ERROR - 2022-03-23 06:23:14 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('359', 'INV-CC', NULL, NULL, 'Courier Debit For e-commerce Order No -  00035984 Courier  S.A Paribahan', 73998.8, 0, 1, 'OpSoxJvBbbS8Rws', '2022-03-23 06:23:14', 1)
ERROR - 2022-03-23 06:24:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:24:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:24:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:24:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:24:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:25:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:25:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:25:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:25:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 282
ERROR - 2022-03-23 06:25:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 283
ERROR - 2022-03-23 06:25:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 284
ERROR - 2022-03-23 06:25:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 287
ERROR - 2022-03-23 06:26:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:26:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:26:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:26:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:26:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:33:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 282
ERROR - 2022-03-23 06:33:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 283
ERROR - 2022-03-23 06:33:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 284
ERROR - 2022-03-23 06:33:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 287
ERROR - 2022-03-23 06:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:34:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:34:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:34:58 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 272
ERROR - 2022-03-23 06:34:59 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('359', 'INV-CC', NULL, NULL, 'Courier Debit For  e-commerce Order No -  00035984 Courier  S.A Paribahan', 0, 75218.8, 1, 'OpSoxJvBbbS8Rws', '2022-03-23 06:34:58', 1)
ERROR - 2022-03-23 06:35:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:35:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:35:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:35:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:35:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:35:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:35:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:35:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:35:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:41:18 --> Severity: Notice --> Undefined property: Corder::$Invoice C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 55
ERROR - 2022-03-23 06:41:18 --> Severity: error --> Exception: Call to a member function retrieve_invoice_order_data() on null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 55
ERROR - 2022-03-23 06:41:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Invoice C:\laragon\www\git\erp_swapon\system\core\Loader.php 348
ERROR - 2022-03-23 06:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:48:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:48:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:48:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:48:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:48:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:48:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:48:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:51:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:51:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:51:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:52:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:52:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:52:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:52:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:52:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:52:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:55:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:55:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:55:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:57:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:57:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:57:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:57:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 06:58:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 06:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 06:58:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 06:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 07:12:25 --> Severity: Notice --> Undefined index: courier_condition C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 562
ERROR - 2022-03-23 07:12:25 --> Severity: Notice --> Undefined index: courier_condition C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 568
ERROR - 2022-03-23 07:12:25 --> Severity: Notice --> Undefined index: courier_condition C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 574
ERROR - 2022-03-23 07:12:25 --> Severity: Notice --> Undefined index: courier_condition C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 591
ERROR - 2022-03-23 07:12:25 --> Severity: Notice --> Undefined variable: courier_condition C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 591
ERROR - 2022-03-23 07:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 07:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 07:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 07:14:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 07:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 07:14:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:12:54 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 570
ERROR - 2022-03-23 09:12:54 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 224
ERROR - 2022-03-23 09:12:54 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 570
ERROR - 2022-03-23 09:12:54 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 224
ERROR - 2022-03-23 09:12:54 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 570
ERROR - 2022-03-23 09:12:54 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 224
ERROR - 2022-03-23 09:27:27 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-23 09:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-23 09:27:27 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-23 09:27:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-23 09:27:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:27:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:27:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:27:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:27:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:27:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:28:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:28:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:10 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-23 09:28:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-23 09:28:10 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-23 09:28:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-23 09:28:10 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-23 09:28:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:28:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:28:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:28:20 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-23 09:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-23 09:28:20 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-23 09:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-23 09:28:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:28:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:28:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:28:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:30:49 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-23 09:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-23 09:30:49 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-23 09:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-23 09:30:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:30:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:30:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:30:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:30:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:30:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:31:37 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:31:37 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:31:37 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:31:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:31:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:31:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:31:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:31:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:31:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:34:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:34:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:34:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:34:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:34:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:34:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:34:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:35:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:35:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:35:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:35:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:35:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:35:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:35:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:35:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:35:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:35:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:35:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-23 09:35:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:35:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-23 09:35:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:35:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-23 09:35:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:35:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:35:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:35:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:41:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:41:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:41:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:41:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:42:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:42:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:43:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:43:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:43:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:43:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:43:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:43:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:54:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:54:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:54:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:54:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:54:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:54:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:55:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:55:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:56:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 352
ERROR - 2022-03-23 09:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 75
ERROR - 2022-03-23 09:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:56:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:56:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:56:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 352
ERROR - 2022-03-23 09:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 75
ERROR - 2022-03-23 09:56:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:56:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:56:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:56:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:57:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 352
ERROR - 2022-03-23 09:57:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 76
ERROR - 2022-03-23 09:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:57:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:57:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:57:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:58:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:58:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:58:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:02 --> Severity: Notice --> Undefined index: variation C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 703
ERROR - 2022-03-23 09:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:58:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 09:58:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 09:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 09:58:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 09:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 11:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 11:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-23 11:06:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-23 11:06:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-23 11:06:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-23 11:06:34 --> 404 Page Not Found: Assets/js
