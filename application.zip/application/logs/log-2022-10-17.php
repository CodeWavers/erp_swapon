<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-17 11:08:53 --> 404 Page Not Found: Login/index
ERROR - 2022-10-17 11:09:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-17 11:35:43 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-17 12:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-10-17 12:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-10-17 12:41:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1299
ERROR - 2022-10-17 12:42:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-10-17 12:42:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-10-17 12:55:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:55:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:55:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:55:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 12:55:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 12:55:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 12:56:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:56:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 12:56:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 12:56:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 12:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:56:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 12:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:56:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 12:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 12:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 12:58:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 12:58:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 12:58:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 12:58:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:26:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'COAID LIKE '104%'' at line 1 - Invalid query: SELECT SUM(acc_transaction.Credit) as total_credit , SUM(acc_transaction.Debit) as total_debit FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode WHERE acc_transaction.IsAppove = 1 AND acc_coa.IsActive = 1 AND VDate BETWEEN '2022-10-17' AND '2022-10-17'  COAID LIKE '104%'
ERROR - 2022-10-17 13:26:53 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\views\newaccount\trial_new.php 37
ERROR - 2022-10-17 13:29:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'COAID LIKE '104%'' at line 1 - Invalid query: SELECT SUM(acc_transaction.Credit) as total_credit , SUM(acc_transaction.Debit) as total_debit FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode WHERE acc_transaction.IsAppove = 1 AND acc_coa.IsActive = 1 AND VDate BETWEEN '2022-10-17' AND '2022-10-17'  COAID LIKE '104%'
ERROR - 2022-10-17 13:29:04 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\views\newaccount\trial_new.php 37
ERROR - 2022-10-17 13:29:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'COAID LIKE '104%'' at line 1 - Invalid query: SELECT SUM(acc_transaction.Credit) as total_credit , SUM(acc_transaction.Debit) as total_debit FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode WHERE acc_transaction.IsAppove = 1 AND acc_coa.IsActive = 1 AND VDate BETWEEN '2022-10-17' AND '2022-10-17'  COAID LIKE '104%'
ERROR - 2022-10-17 13:29:40 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\views\newaccount\trial_new.php 37
ERROR - 2022-10-17 13:30:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'COAID LIKE '104%'' at line 1 - Invalid query: SELECT SUM(acc_transaction.Credit) as total_credit , SUM(acc_transaction.Debit) as total_debit FROM acc_transaction INNER JOIN acc_coa ON acc_transaction.COAID = acc_coa.HeadCode WHERE acc_transaction.IsAppove = 1 AND acc_coa.IsActive = 1 AND acc_transaction.VDate BETWEEN '2022-10-17' AND '2022-10-17'  COAID LIKE '104%'
ERROR - 2022-10-17 13:30:19 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\views\newaccount\trial_new.php 37
ERROR - 2022-10-17 13:55:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:55:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:55:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:55:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:56:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:56:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:56:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:56:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:56:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:56:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:56:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:56:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:58:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:58:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:58:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:58:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:58:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:58:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:59:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:59:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:59:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:59:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:59:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:59:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-17 13:59:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-17 13:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 13:59:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-17 13:59:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-17 14:23:17 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` >= '2022-10-17'
AND `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:23:17 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 565
ERROR - 2022-10-17 14:23:36 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` >= '2022-10-17'
AND `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:23:36 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 565
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:23:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:23:51 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` >= '2022-10-17'
AND `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:23:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:26:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:26:27 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:26:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:26:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:26:33 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:26:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:27:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:27:54 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:27:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:28:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:28:50 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:28:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 14:57:58 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:57:58 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 807
ERROR - 2022-10-17 14:59:06 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:59:06 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 807
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:59:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 14:59:44 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 14:59:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:03:42 --> Query error: Unknown column 'transfer_items.date' in 'where clause' - Invalid query: SELECT SUM(transfer_item_details.quantity) as transfer_item
FROM `transfer_item_details`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 15:03:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:05:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:05:36 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 15:05:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:06:07 --> Query error: Unknown column 'transfer_items.transfer_item_details' in 'on clause' - Invalid query: SELECT SUM(quantity) as transfer_item
FROM `transfer_item_details`
LEFT JOIN `transfer_items` ON `transfer_items`.`transfer_item_details`=`transfer_items`.`pro_id`
WHERE `transfer_items`.`date` <= '2022-10-17'
AND `transfer_item_details`.`product_id` = ''
GROUP BY `transfer_item_details`.`product_id`
ERROR - 2022-10-17 15:06:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:06:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:07:26 --> Severity: error --> Exception: syntax error, unexpected '/' C:\laragon\www\git\erp_swapon\application\models\Reports.php 687
ERROR - 2022-10-17 15:07:35 --> Severity: error --> Exception: syntax error, unexpected '/' C:\laragon\www\git\erp_swapon\application\models\Reports.php 687
ERROR - 2022-10-17 15:09:08 --> Severity: error --> Exception: syntax error, unexpected '/' C:\laragon\www\git\erp_swapon\application\models\Reports.php 687
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 15:09:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-17 16:43:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-17 16:44:35 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-17 16:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-10-17 16:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-10-17 16:46:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-10-17 16:46:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-10-17 16:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-10-17 16:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-10-17 16:49:30 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
