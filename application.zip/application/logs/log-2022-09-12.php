<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-12 11:30:21 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-12 11:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:34:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:35:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:35:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 11:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:35:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 11:35:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 11:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:36:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 11:36:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 11:36:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 11:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:36:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:36:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 11:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:36:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 11:36:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 11:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:40:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:40:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 11:40:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 11:40:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:40:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 11:40:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:41:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 11:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 11:41:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 11:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 11:41:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 11:41:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 11:41:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 11:42:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:45:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:52:53 --> The upload path does not appear to be valid.
ERROR - 2022-09-12 11:52:53 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9226634183', 'INV', '2022-09-12', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 9226634183 Customer- ', 0, '1000', 1, 'OpSoxJvBbbS8Rws', '2022-09-12 11:52:53', 1)
ERROR - 2022-09-12 11:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:54:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 11:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 12:00:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 12:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 12:05:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 12:07:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 12:08:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 715
ERROR - 2022-09-12 12:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 719
ERROR - 2022-09-12 12:17:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 719
ERROR - 2022-09-12 12:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:22:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:22:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:22:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:22:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:22:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:22:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:23:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:23:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:23:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:23:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:23:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:23:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:26:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:26:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:26:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:26:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:26:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:26:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:27:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:27:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:27:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:27:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:28:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:28:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:28:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:40:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:41:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:45:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:49:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:50:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:51:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:51:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:51:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:51:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:51:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:51:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:53:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:53:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:53:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:53:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:53:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:53:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:53:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:53:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:53:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:53:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:53:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:53:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:54:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:54:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:54:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:55:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:55:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:55:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:55:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:55:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:55:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:55:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:55:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 12:55:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 12:55:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:55:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 12:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 908
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 914
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 934
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 939
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 953
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 959
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 975
ERROR - 2022-09-12 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 908
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 914
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 934
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 939
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 953
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 959
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 975
ERROR - 2022-09-12 13:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 908
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 914
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 934
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 939
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 953
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 959
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 975
ERROR - 2022-09-12 13:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 908
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 914
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 934
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 939
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 953
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 959
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 975
ERROR - 2022-09-12 13:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 908
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 914
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 934
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 939
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 953
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 959
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 975
ERROR - 2022-09-12 13:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-09-12 13:08:41 --> Severity: error --> Exception: Call to a member function get_real_card_data() on null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-09-12 13:08:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:09:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 13:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:09:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 13:09:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 13:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:10:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:10:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 13:10:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 13:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 13:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:11:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:11:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:11:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 13:11:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 13:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 13:11:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 13:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 13:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:17:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:33:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:36:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:36:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:44:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:46:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 14:46:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 14:46:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 14:46:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 14:46:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 14:46:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 14:46:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:46:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 14:46:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 14:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 14:46:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 14:46:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 14:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 14:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 14:57:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:28:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:39:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:58:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 15:59:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:01:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:01:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:02:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:03:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:06:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 16:06:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 16:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:06:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-12 16:07:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:07:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:17:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-12 16:19:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:19:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:19:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-12 16:19:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-12 16:19:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-12 16:19:34 --> 404 Page Not Found: Assets/css
