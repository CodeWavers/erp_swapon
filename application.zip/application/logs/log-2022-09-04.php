<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-04 04:39:47 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-04 04:40:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 04:41:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 04:44:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 04:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 04:47:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 05:01:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 05:38:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-09-04 06:24:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:24:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:24:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:24:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:24:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:24:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:24:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:24:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:24:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:24:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:24:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:24:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:25:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:25:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:25:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:25:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:25:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:25:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:34:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:34:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:34:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:37:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:37:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:37:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:37:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:37:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:56:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:56:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:56:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:56:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:56:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:56:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:58:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 06:58:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 06:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 06:58:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 06:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 07:01:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 07:01:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 07:01:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 07:01:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 07:01:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 07:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 07:57:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve.php 74
ERROR - 2022-09-04 07:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-04 07:58:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve.php 74
ERROR - 2022-09-04 08:55:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 83
ERROR - 2022-09-04 08:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 118
ERROR - 2022-09-04 08:58:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 118
ERROR - 2022-09-04 09:06:11 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 201
ERROR - 2022-09-04 09:07:22 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 201
ERROR - 2022-09-04 09:07:34 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 201
ERROR - 2022-09-04 09:14:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 83
ERROR - 2022-09-04 09:22:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 83
ERROR - 2022-09-04 09:23:12 --> Severity: error --> Exception: Call to undefined method Creport::generator() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 201
ERROR - 2022-09-04 09:23:14 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 271
ERROR - 2022-09-04 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 09:59:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 09:59:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 09:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:00:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:00:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:01:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:01:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:04:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:04:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:04:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:04:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:04:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:04:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:06:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:06:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:06:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:07:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:07:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:17:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:17:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:17:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:17:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:17:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:19:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:19:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:19:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:20:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:20:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:20:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:20:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:20:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:20:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:20:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:20:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:20:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:20:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:20:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:20:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:21:00 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-04 10:21:00 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-04 10:21:00 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-04 10:21:00 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-04 10:21:00 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 568
ERROR - 2022-09-04 10:21:00 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 569
ERROR - 2022-09-04 10:21:00 --> Severity: error --> Exception: Call to undefined method Creport::generator() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 201
ERROR - 2022-09-04 10:21:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-09-04 10:21:00 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 271
ERROR - 2022-09-04 10:21:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:21:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:21:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:21:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:21:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:21:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:22:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:22:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:22:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:22:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:22:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:22:10 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 532
ERROR - 2022-09-04 10:22:28 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-04 10:22:28 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-04 10:22:28 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-04 10:22:28 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-04 10:22:28 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 568
ERROR - 2022-09-04 10:22:28 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 569
ERROR - 2022-09-04 10:22:28 --> Severity: error --> Exception: Call to undefined method Creport::generator() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 201
ERROR - 2022-09-04 10:22:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-09-04 10:25:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:25:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:25:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:25:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:25:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:25:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 191
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 193
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 193
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 196
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 196
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'sku' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 200
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 200
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 200
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 202
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 202
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 202
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 207
ERROR - 2022-09-04 10:25:43 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 207
ERROR - 2022-09-04 10:26:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:26:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:26:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:26:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:26:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:26:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:27:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:27:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:28:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:28:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 10:28:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 193
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 195
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 195
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 198
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 198
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'sku' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 202
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 202
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 202
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 204
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 204
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 204
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 209
ERROR - 2022-09-04 10:28:12 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 209
ERROR - 2022-09-04 10:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 10:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 10:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 10:28:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 11:32:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 185
ERROR - 2022-09-04 14:24:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2884
ERROR - 2022-09-04 14:24:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2884
ERROR - 2022-09-04 14:24:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2951
ERROR - 2022-09-04 14:24:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2951
ERROR - 2022-09-04 14:24:18 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-04 14:24:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 185
ERROR - 2022-09-04 14:29:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 185
ERROR - 2022-09-04 14:40:00 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 256
ERROR - 2022-09-04 14:40:26 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 256
ERROR - 2022-09-04 14:40:51 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 256
ERROR - 2022-09-04 14:43:41 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 256
ERROR - 2022-09-04 14:47:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 185
ERROR - 2022-09-04 14:52:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 14:52:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 14:52:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 14:52:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 14:52:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 14:52:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 14:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 14:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-04 14:53:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-04 14:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 14:53:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-04 14:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-04 14:56:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 186
