<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-27 05:34:54 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-27 05:34:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-27 05:34:54 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-27 05:34:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-27 05:34:54 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-27 06:25:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 06:25:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 06:25:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 06:25:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 06:25:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 06:25:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 06:25:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 06:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 06:25:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 06:25:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 06:26:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 06:26:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:42:10 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\system\helpers\form_helper.php 74
ERROR - 2022-02-27 08:42:10 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\helpers\form_helper.php 91
ERROR - 2022-02-27 08:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:42:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:42:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:42:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:15 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\system\helpers\form_helper.php 74
ERROR - 2022-02-27 08:42:15 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\helpers\form_helper.php 91
ERROR - 2022-02-27 08:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:42:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:42:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 08:42:21 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\system\helpers\form_helper.php 74
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\helpers\form_helper.php 91
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 88
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 88
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 88
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 88
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 98
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 98
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 98
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 98
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 136
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 136
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 144
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 144
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 152
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 152
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 160
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 160
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 168
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 168
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 177
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 177
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 260
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 260
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 264
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 264
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 268
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 268
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 287
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 287
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 295
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 295
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 305
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 305
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 312
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 312
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 319
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 319
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 327
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 327
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 338
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 338
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 371
ERROR - 2022-02-27 08:42:21 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 371
ERROR - 2022-02-27 08:42:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:42:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:42:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:42:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:42:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:46:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:46:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:46:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:46:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:46:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:46:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:46:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:46:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:46:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:47:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:47:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:47:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:47:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:47:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:48:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:48:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:48:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:48:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:48:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:48:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:52:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:52:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:52:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:52:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:55:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:55:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 08:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 08:59:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 08:59:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 08:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:20:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:20:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:20:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:20:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:20:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:20:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:21:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:21:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:21:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:21:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:21:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:22:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:22:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:22:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:22:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:24:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:24:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:24:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:24:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:24:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:25:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:25:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:25:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:27:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:27:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:27:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:27:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:27:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:28:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:28:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:28:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:28:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:28:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:29:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:29:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:29:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:35:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:35:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:35:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:35:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:35:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:35:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:36:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:36:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 09:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 09:36:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 09:36:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 09:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 15:39:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 15:39:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 15:39:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-27 15:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-27 15:39:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-27 15:39:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-27 15:39:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-27 15:39:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 15:39:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 15:39:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 15:39:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 15:39:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 15:39:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 15:39:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Undefined property: stdClass::$shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 79
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 86
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 87
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 88
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 89
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 92
ERROR - 2022-02-27 15:39:34 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 93
ERROR - 2022-02-27 15:41:58 --> Severity: Notice --> Undefined property: stdClass::$shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 79
ERROR - 2022-02-27 15:42:29 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 79
ERROR - 2022-02-27 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 79
ERROR - 2022-02-27 15:42:29 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 79
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 106
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 106
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 107
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 107
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 108
ERROR - 2022-02-27 16:03:38 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 108
ERROR - 2022-02-27 16:03:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 288
ERROR - 2022-02-27 16:03:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 106
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 106
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 107
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 107
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 108
ERROR - 2022-02-27 16:04:00 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 108
ERROR - 2022-02-27 16:04:00 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-27 16:04:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 106
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 106
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 107
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 107
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Undefined variable: shipping_address C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 108
ERROR - 2022-02-27 16:04:06 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 108
ERROR - 2022-02-27 16:04:06 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-27 16:04:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-02-27 16:05:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 16:05:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 16:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:05:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 16:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:05:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:05:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 16:05:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:05:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 16:05:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 16:05:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-27 16:07:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-27 16:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-27 16:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-27 16:07:14 --> 404 Page Not Found: Assets/js
