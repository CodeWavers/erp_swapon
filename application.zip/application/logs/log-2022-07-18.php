<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-18 07:01:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-18 07:05:00 --> The upload path does not appear to be valid.
ERROR - 2022-07-18 07:05:00 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7337756211', 'INV-CC', '2022-07-18', NULL, 'Courier Debit For Invoice No -  1005 Courier  Sundarban Courier', 0, 16752, 1, 'OpSoxJvBbbS8Rws', '2022-07-18 07:05:00', 1)
ERROR - 2022-07-18 07:05:00 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7337756211', 'INV-CC', '2022-07-18', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1005 Courier  Sundarban Courier', 300, 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-18 07:05:00', 1)
ERROR - 2022-07-18 12:16:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-18 12:21:41 --> Query error: Unknown column 'rr.reciever_name' in 'field list' - Invalid query: SELECT `a`.*, `cr`.*, `br`.*, `rr`.`reciever_name`, `a`.`due_amount` as `due_amnt`, `a`.`paid_amount` as `p_amnt`, sum(c.quantity) as sum_quantity, `a`.`total_tax` as `taxs`, `a`. `prevous_due`, `b`.`customer_name`, `c`.*, `c`.`tax` as `total_tax`, `c`.`product_id`, `d`.`product_name`, `d`.`product_model`, `d`.`tax`, `d`.`unit`, `d`.*
FROM `invoice` `a`
JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `courier_name` `cr` ON `cr`.`courier_id` = `a`.`courier_id`
LEFT JOIN `branch_name` `br` ON `br`.`branch_id` = `a`.`branch_id`
LEFT JOIN `receiever_info` `rr` ON `rr`.`id` = `a`.`reciever_id`
JOIN `product_information` `d` ON `d`.`product_id` = `c`.`product_id`
WHERE `a`.`invoice_id` = '7337756211'
GROUP BY `d`.`product_id`
ERROR - 2022-07-18 12:21:41 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Invoices.php 2581
ERROR - 2022-07-18 12:22:16 --> Query error: Unknown column 'rr.reciever_name' in 'field list' - Invalid query: SELECT `a`.*, `cr`.*, `br`.*, `rr`.`reciever_name`, `a`.`due_amount` as `due_amnt`, `a`.`paid_amount` as `p_amnt`, sum(c.quantity) as sum_quantity, `a`.`total_tax` as `taxs`, `a`. `prevous_due`, `b`.`customer_name`, `c`.*, `c`.`tax` as `total_tax`, `c`.`product_id`, `d`.`product_name`, `d`.`product_model`, `d`.`tax`, `d`.`unit`, `d`.*
FROM `invoice` `a`
JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `courier_name` `cr` ON `cr`.`courier_id` = `a`.`courier_id`
LEFT JOIN `branch_name` `br` ON `br`.`branch_id` = `a`.`branch_id`
LEFT JOIN `receiever_info` `rr` ON `rr`.`id` = `a`.`reciever_id`
JOIN `product_information` `d` ON `d`.`product_id` = `c`.`product_id`
WHERE `a`.`invoice_id` = '7337756211'
GROUP BY `d`.`product_id`
ERROR - 2022-07-18 12:22:47 --> Severity: Notice --> Undefined index: reciever_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-07-18 12:25:11 --> Severity: Notice --> Undefined index: receiver_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 55
ERROR - 2022-07-18 12:30:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 420
ERROR - 2022-07-18 12:30:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 420
ERROR - 2022-07-18 12:35:15 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 80
