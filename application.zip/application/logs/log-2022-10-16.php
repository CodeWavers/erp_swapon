<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-16 11:19:00 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 14:49:45 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 14:51:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 14:52:30 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 14:53:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 14:53:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 14:53:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 14:53:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 14:53:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 14:53:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 14:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 14:53:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 14:53:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 14:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 14:53:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 14:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:04:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:04:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:04:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:04:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:04:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:04:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:04:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:04:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:05:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:05:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:05:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:05:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:05:27 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 41
ERROR - 2022-10-16 15:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:06:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:06:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:06:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:06:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:07:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:07:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:07:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:07:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:07:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:07:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:07:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:07:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:07:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:08:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:08:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:08:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:08:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:08:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:08:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:08:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:08:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:08:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:09:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:09:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:09:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:09:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:09:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:09:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:09:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:09:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:10:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:10:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:10:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:10:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:10:31 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 42
ERROR - 2022-10-16 15:16:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:16:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:16:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:16:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:16:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:16:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-10-16 15:17:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-10-16 15:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-10-16 15:17:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-10-16 15:17:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 15:17:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-10-16 15:17:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-10-16 15:17:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-10-16 15:17:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-10-16 15:17:29 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 15:17:34 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 41
ERROR - 2022-10-16 15:17:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:17:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:17:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:17:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:17:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:17:42 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 41
ERROR - 2022-10-16 15:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:19:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:19:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:20:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:20:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:20:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:20:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:20:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:20:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:22:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:22:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:23:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:23:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:23:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:23:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:23:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:23:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:23:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:23:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:23:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:23:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:34:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:34:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:34:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:34:39 --> Severity: error --> Exception: Call to undefined function str_contains() C:\laragon\www\git\erp_swapon\application\models\Invoices.php 59
ERROR - 2022-10-16 15:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:40:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:40:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:40:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:40:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:40:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:40:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:41:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:41:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:44:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:44:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:44:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:44:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:34 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 42
ERROR - 2022-10-16 15:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:44:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:44:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:44:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:44:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:44:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:44:52 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 42
ERROR - 2022-10-16 15:45:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:45:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-16 15:45:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-16 15:45:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-16 15:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 15:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-16 20:59:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-16 20:59:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
