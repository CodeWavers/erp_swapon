<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-25 16:55:04 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-25 17:04:18 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-25 17:08:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 634
ERROR - 2022-09-25 17:08:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 634
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: outlet_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 134
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: courier_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 251
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 251
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 373
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 375
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 377
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 450
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 450
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 513
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 513
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 677
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 677
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 683
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 683
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 703
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 703
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 708
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 708
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 722
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 722
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 728
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 728
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 744
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 744
ERROR - 2022-09-25 17:34:08 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 750
ERROR - 2022-09-25 17:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 750
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 174
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 176
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 178
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 251
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 251
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 314
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 314
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 478
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 478
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 484
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 484
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 504
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 504
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 509
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 509
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 523
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 523
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 529
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 529
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 545
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 545
ERROR - 2022-09-25 17:39:03 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 551
ERROR - 2022-09-25 17:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 551
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: courier_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 179
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 179
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 301
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 303
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 305
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 378
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 378
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 441
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 441
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 605
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 605
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 611
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 611
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 631
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 631
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 636
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 636
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 650
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 650
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 656
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 656
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 672
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 672
ERROR - 2022-09-25 17:39:42 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 678
ERROR - 2022-09-25 17:39:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 678
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 207
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 209
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 211
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 284
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 284
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 347
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 347
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 511
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 511
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 517
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 517
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 537
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 537
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 542
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 542
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 556
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 556
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 562
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 562
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 578
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 578
ERROR - 2022-09-25 17:40:12 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 584
ERROR - 2022-09-25 17:40:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 584
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 203
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 205
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 207
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 280
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 280
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 343
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 343
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 507
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 507
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 513
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 513
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 533
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 533
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 538
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 538
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 552
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 552
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 558
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 558
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 574
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 574
ERROR - 2022-09-25 17:40:50 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 580
ERROR - 2022-09-25 17:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 580
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 185
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 187
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 189
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 262
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 262
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 325
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 325
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 489
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 489
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 495
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 495
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 515
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 515
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 520
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 520
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 534
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 534
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 540
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 540
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 556
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 556
ERROR - 2022-09-25 17:42:08 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 562
ERROR - 2022-09-25 17:42:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 562
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 184
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 186
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 188
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 261
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 261
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 324
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 324
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 488
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 488
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 494
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 494
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 514
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 514
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 519
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 519
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 533
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 533
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 539
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 539
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 555
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 555
ERROR - 2022-09-25 17:43:16 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 561
ERROR - 2022-09-25 17:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 561
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 184
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 186
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 188
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 261
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 261
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 324
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 324
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 488
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 488
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 494
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 494
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 514
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 514
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 519
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 519
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 533
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 533
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 539
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 539
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 555
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 555
ERROR - 2022-09-25 17:43:28 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 561
ERROR - 2022-09-25 17:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 561
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 140
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 142
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 144
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 217
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 217
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 280
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 280
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 444
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 444
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 450
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 450
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 470
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 470
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 475
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 475
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 489
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 489
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 495
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 495
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 511
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 511
ERROR - 2022-09-25 17:44:05 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 517
ERROR - 2022-09-25 17:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 517
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 140
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 142
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 144
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 217
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 217
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 280
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 280
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 444
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 444
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 450
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 450
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 470
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 470
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 475
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 475
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 489
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 489
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 495
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 495
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 511
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 511
ERROR - 2022-09-25 17:44:43 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 517
ERROR - 2022-09-25 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 517
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 210
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 212
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 214
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 287
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 287
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 350
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 350
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 514
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 514
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: bank_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 520
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 520
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 540
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 540
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: bkash_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 545
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 545
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 559
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 559
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 565
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 565
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 581
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 581
ERROR - 2022-09-25 17:45:35 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 587
ERROR - 2022-09-25 17:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\order.php 587
ERROR - 2022-09-25 20:54:10 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\include\admin_header.php 162
ERROR - 2022-09-25 20:54:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\include\admin_header.php 162
ERROR - 2022-09-25 20:54:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-09-25 20:54:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-09-25 20:54:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-09-25 20:54:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-09-25 20:54:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-25 20:59:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-25 20:59:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-25 20:59:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-25 20:59:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-25 20:59:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-25 20:59:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-25 21:02:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-25 21:02:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-25 21:02:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-25 21:02:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-25 21:02:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-25 21:02:59 --> 404 Page Not Found: Assets/css
