<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-14 10:13:12 --> The upload path does not appear to be valid.
ERROR - 2022-08-14 10:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:23:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-14 10:23:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-14 10:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:23:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-14 10:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-14 10:24:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:24:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-14 10:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:24:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-14 10:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-14 10:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:28:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-14 10:28:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-14 10:28:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-14 10:28:47 --> Severity: error --> Exception: Call to a member function getCheckList() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-08-14 10:28:52 --> Severity: error --> Exception: Call to a member function getCheckList() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-08-14 10:29:20 --> Severity: Notice --> Undefined property: Linvoice::$Reports C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-08-14 10:29:20 --> Severity: error --> Exception: Call to a member function getCheckList() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
