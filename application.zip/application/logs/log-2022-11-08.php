<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-08 10:35:50 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-08 10:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:39:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 325
ERROR - 2022-11-08 10:39:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 10:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 325
ERROR - 2022-11-08 10:41:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 10:42:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 325
ERROR - 2022-11-08 10:42:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 10:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:43:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 325
ERROR - 2022-11-08 10:43:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 10:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:43:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:43:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 325
ERROR - 2022-11-08 10:43:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 10:43:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:44:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:44:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:45:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-08 10:54:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-08 10:54:34 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3345', 'INV-CC', '2021-09-13', NULL, 'Customer debit For Invoice No -  1013 Customer ', '2182.45', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-08 10:54:34', 1)
ERROR - 2022-11-08 10:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-08 10:54:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-08 10:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 10:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 10:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 168
ERROR - 2022-11-08 10:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 740
ERROR - 2022-11-08 10:55:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 746
ERROR - 2022-11-08 10:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 740
ERROR - 2022-11-08 10:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 746
ERROR - 2022-11-08 10:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 740
ERROR - 2022-11-08 10:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 746
ERROR - 2022-11-08 10:57:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 2614
ERROR - 2022-11-08 10:57:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 2615
ERROR - 2022-11-08 10:57:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 2618
ERROR - 2022-11-08 10:57:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3345', 'INV', '2021-09-13', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 3345 Customer- ', 0, '500', 1, 'OpSoxJvBbbS8Rws', '2022-11-08 10:57:52', 1)
ERROR - 2022-11-08 10:57:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 10:58:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 11:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 11:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 11:05:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3345', 'INV-CC', '2021-09-13', NULL, 'Customer debit For Invoice No -  1013 Customer ', '2182.45', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-08 11:05:01', 1)
ERROR - 2022-11-08 11:05:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 11:06:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 11:07:07 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3345', 'INV-CC', '2021-09-13', NULL, 'Customer debit For Invoice No -  1013 Customer ', '2182.45', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-08 11:07:07', 1)
ERROR - 2022-11-08 11:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 11:09:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-08 11:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 11:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-08 11:32:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-08 11:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 11:38:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-08 11:38:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-08 11:41:42 --> The upload path does not appear to be valid.
ERROR - 2022-11-08 11:41:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 11:44:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 11:44:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-11-08 11:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-11-08 11:45:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 11:45:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-08 11:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-08 15:53:34 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-08 16:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 482
ERROR - 2022-11-08 16:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 488
ERROR - 2022-11-08 16:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-11-08 16:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-11-08 16:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 482
ERROR - 2022-11-08 16:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 488
ERROR - 2022-11-08 16:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-11-08 16:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-11-08 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 495
ERROR - 2022-11-08 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 501
ERROR - 2022-11-08 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 517
ERROR - 2022-11-08 16:22:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 523
ERROR - 2022-11-08 16:22:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 495
ERROR - 2022-11-08 16:22:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 501
ERROR - 2022-11-08 16:22:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 517
ERROR - 2022-11-08 16:22:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 523
ERROR - 2022-11-08 16:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 495
ERROR - 2022-11-08 16:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 501
ERROR - 2022-11-08 16:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 517
ERROR - 2022-11-08 16:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 523
ERROR - 2022-11-08 16:23:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 495
ERROR - 2022-11-08 16:23:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 501
ERROR - 2022-11-08 16:23:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 517
ERROR - 2022-11-08 16:23:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 523
ERROR - 2022-11-08 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 421
ERROR - 2022-11-08 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 427
ERROR - 2022-11-08 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 443
ERROR - 2022-11-08 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 449
ERROR - 2022-11-08 16:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 433
ERROR - 2022-11-08 16:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 439
ERROR - 2022-11-08 16:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 455
ERROR - 2022-11-08 16:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 461
ERROR - 2022-11-08 16:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-11-08 16:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-11-08 16:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 527
ERROR - 2022-11-08 16:47:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 533
ERROR - 2022-11-08 16:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 16:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 16:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 16:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 16:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:00:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:06:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:06:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:06:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:06:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:07:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:07:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:07:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:10:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:10:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:10:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:10:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:10:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:10:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:10:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:11:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:11:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:11:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:11:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:12:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:12:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:12:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:13:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:13:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:13:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:13:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:13:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:13:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:14:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:14:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:14:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:14:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:14:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:14:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:14:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:14:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:14:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:16:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:16:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:16:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:16:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:19:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-08 17:19:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-08 17:19:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-08 17:19:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:19:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-08 17:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:20:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:22:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:22:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:22:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:22:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:24:02 --> Query error: Column 'transport_cost' cannot be null - Invalid query: INSERT INTO `product_purchase` (`purchase_id`, `supplier_id`, `invoice_no`, `grand_total_amount`, `total_discount`, `labour_wages`, `transport_cost`, `purchase_date`, `purchase_details`, `paid_amount`, `due_amount`, `status`, `outlet_id`, `isFinal`) VALUES ('20221108172402', '1', '1001', '10250.00', '50', NULL, NULL, '2022-11-08', NULL, '2000', '8250.00', 1, NULL, 2)
ERROR - 2022-11-08 17:25:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:25:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:25:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:25:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-08 17:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:32:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:32:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:32:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:32:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:34:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:34:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:34:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:34:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:34:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 453
ERROR - 2022-11-08 17:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 459
ERROR - 2022-11-08 17:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 475
ERROR - 2022-11-08 17:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 481
ERROR - 2022-11-08 17:50:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-08 17:50:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-08 17:50:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-08 17:50:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
