<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-01 10:44:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-10-01 10:44:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3257
ERROR - 2022-10-01 10:44:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-10-01 10:44:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3324
ERROR - 2022-10-01 10:44:47 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-01 10:45:34 --> Severity: Notice --> Undefined variable: agg_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 68
ERROR - 2022-10-01 10:45:34 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 71
ERROR - 2022-10-01 10:45:34 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-10-01 10:45:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-10-01 10:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-10-01 10:56:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-10-01 10:57:52 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 10:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-10-01 11:29:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-10-01 11:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 11:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 11:29:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 11:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 11:29:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 11:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 11:38:44 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 11:47:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-10-01 12:11:09 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 12:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-10-01 12:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:44:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:45:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:50:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:50:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 12:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:10:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:10:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:10:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:10:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:10:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:13:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:13:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:13:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:13:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:13:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:13:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:13:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:19:56 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 13:20:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:20:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:20:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:20:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:20:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:20:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:20:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:21:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:24:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:24:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:24:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:24:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:25:35 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 13:25:35 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4229827981', 'INV-CC', '2022-10-01', NULL, 'Customer debit For Invoice No -  1052 Customer ', '14740.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-10-01 13:25:35', 1)
ERROR - 2022-10-01 13:25:35 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 996
ERROR - 2022-10-01 13:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:25:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:26:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:37:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:38:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:38:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:38:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:38:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:38:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:38:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:38:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:38:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:38:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:38:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:39:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:39:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:39:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:39:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:42:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:42:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 13:42:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:42:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:42:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:42:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 752
ERROR - 2022-10-01 13:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 13:49:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 13:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-10-01 13:52:59 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 13:53:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 13:55:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 13:56:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 13:58:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:58:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:58:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 13:58:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 13:58:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 13:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 14:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 14:02:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 14:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:02:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 14:02:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:05:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 14:05:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 14:05:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 14:05:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:08:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:08:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 14:08:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:08:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 14:08:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:08:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 14:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:09:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 14:09:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 14:09:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 14:09:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:15:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:17:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:17:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:17:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 14:17:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:17:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 14:17:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 14:17:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 14:41:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:42:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:54:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:56:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:58:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:58:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:58:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:59:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 14:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:10:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-10-01 15:11:02 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 15:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:18:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-10-01 15:43:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:45:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:51:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 15:54:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 15:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 15:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 15:54:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 15:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 15:54:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 16:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:02:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 16:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 16:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 16:02:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 16:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 16:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 16:07:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 16:07:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-01 16:07:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-01 16:07:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 16:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-01 16:07:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-01 16:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:09:20 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '749635378258683', NULL, '9946938359', '16945P', '118', '3', '5', '2022-10-01', '2022-10-01', '100.00', '', '0.00', 0, '300', NULL, '', 1)
ERROR - 2022-10-01 16:09:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-01 16:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:13:32 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '866946198724974', NULL, '4745767677', '16945P', '118', '3', '5', '2022-10-01', '2022-10-01', '100.00', '', '0.00', 0, '300', NULL, '', 1)
ERROR - 2022-10-01 16:13:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-01 16:14:19 --> The upload path does not appear to be valid.
ERROR - 2022-10-01 16:14:19 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7414888918', 'INV-CC', '2022-10-01', NULL, 'Customer debit For Invoice No -  1057 Customer ', '8051.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-10-01 16:14:19', 1)
ERROR - 2022-10-01 16:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 16:15:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-01 20:11:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
