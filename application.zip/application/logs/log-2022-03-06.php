<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-06 09:38:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-06 09:38:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-06 09:38:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-06 09:38:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-06 09:38:15 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-06 09:39:28 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 363
ERROR - 2022-03-06 09:39:28 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 363
ERROR - 2022-03-06 09:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 410
ERROR - 2022-03-06 09:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 443
ERROR - 2022-03-06 09:39:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-06 09:39:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-06 09:39:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-06 09:39:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-06 09:39:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-06 09:39:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 124
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 124
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 131
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 132
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 133
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 134
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 135
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 137
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 139
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 181
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 181
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 220
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 363
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 363
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 410
ERROR - 2022-03-06 09:45:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 443
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-06 09:45:19 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-06 09:53:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-06 09:53:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-06 09:53:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-06 09:53:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-06 09:53:48 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
