<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-01 05:46:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-01 05:46:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-01 05:46:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-01 05:46:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-01 05:46:51 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-01 07:37:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:37:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:37:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:37:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:37:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:37:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:37:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:37:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:37:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:41:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:41:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:41:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:42:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:42:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:42:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:42:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:42:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:43:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:43:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:43:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:43:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:43:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:43:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:46:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:46:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:47:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:47:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:47:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:47:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:47:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:47:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:56:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:56:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:56:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:56:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:56:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:57:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 07:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 07:57:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 07:57:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 07:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:02:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:02:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:02:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:02:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:02:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:02:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:02:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:02:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:07:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:07:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:07:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:07:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:08:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:08:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:08:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:08:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:08:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:08:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:08:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:08:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:08:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:11:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:11:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:11:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:11:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:11:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:11:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:12:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:12:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:12:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:13:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:13:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:13:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:13:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:13:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:14:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:14:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:14:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:15:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:15:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:15:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:15:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:15:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:15:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:15:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:15:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:15:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:15:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:15:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:15:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:16:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:16:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:16:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:16:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:16:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:16:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:16:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:16:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:16:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:37:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:37:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:37:22 --> Query error: Duplicate entry 'Sarwar Sadu' for key 'customer_id_two' - Invalid query: INSERT INTO `customer_information` (`customer_id_two`, `customer_name`, `customer_address`, `address2`, `customer_mobile`, `phone`, `fax`, `contact`, `contact_person`, `city`, `state`, `zip`, `country`, `cus_type`, `email_address`, `website`, `customer_email`, `status`, `create_by`) VALUES ('Sarwar Sadu', 'Sarwar Sadu', 'Hathazrai,chittgaong', '', '0189735656', '', '8663', '0736347', 'Engineering Solution', 'Chittagong', 'Nowakhali', '6543', 'Afghanistan', '1', 'sadu@mail.com', '', 'sadu@mail.com', 2, 'OpSoxJvBbbS8Rws')
ERROR - 2022-03-01 08:37:33 --> Query error: Duplicate entry 'Sarwar Sadu' for key 'customer_id_two' - Invalid query: INSERT INTO `customer_information` (`customer_id_two`, `customer_name`, `customer_address`, `address2`, `customer_mobile`, `phone`, `fax`, `contact`, `contact_person`, `city`, `state`, `zip`, `country`, `cus_type`, `email_address`, `website`, `customer_email`, `status`, `create_by`) VALUES ('Sarwar Sadu', 'Sarwar Sadu', 'Hathazrai,chittgaong', '', '0189735656', '', '8663', '0736347', 'Engineering Solution', 'Chittagong', 'Nowakhali', '6543', 'Afghanistan', '1', 'sadu@mail.com', '', 'sadu@mail.com', 2, 'OpSoxJvBbbS8Rws')
ERROR - 2022-03-01 08:37:36 --> Query error: Duplicate entry 'Sarwar Sadu' for key 'customer_id_two' - Invalid query: INSERT INTO `customer_information` (`customer_id_two`, `customer_name`, `customer_address`, `address2`, `customer_mobile`, `phone`, `fax`, `contact`, `contact_person`, `city`, `state`, `zip`, `country`, `cus_type`, `email_address`, `website`, `customer_email`, `status`, `create_by`) VALUES ('Sarwar Sadu', 'Sarwar Sadu', 'Hathazrai,chittgaong', '', '0189735656', '', '8663', '0736347', 'Engineering Solution', 'Chittagong', 'Nowakhali', '6543', 'Afghanistan', '1', 'sadu@mail.com', '', 'sadu@mail.com', 2, 'OpSoxJvBbbS8Rws')
ERROR - 2022-03-01 08:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:37:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:37:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:37:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:47:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:47:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:47:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:47:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:47:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:53:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:53:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:53:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:53:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:53:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:57:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:57:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:57:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:57:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:58:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:58:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 08:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 08:58:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 08:58:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 08:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:03:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:03:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:03:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:03:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:03:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 09:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:05:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:06:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:06:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 09:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:08:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:08:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:08:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 09:08:46 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 283
ERROR - 2022-03-01 09:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 292
ERROR - 2022-03-01 09:12:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:12:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:13:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 09:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:13:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:14:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:14:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:14:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:14:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:14:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 09:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:16:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:16:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:16:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 09:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:19:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 09:19:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 09:19:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:19:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 09:19:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:10:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:10:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:10:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:10:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:10:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-01 16:10:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-01 16:10:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-01 16:10:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-01 16:10:45 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-01 16:10:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:10:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:10:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:11:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:11:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:11:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:11:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:11:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:11:48 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Customers.php 235
ERROR - 2022-03-01 16:11:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Customers.php 244
ERROR - 2022-03-01 16:12:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:12:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:12:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:12:34 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Customers.php 235
ERROR - 2022-03-01 16:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Customers.php 244
ERROR - 2022-03-01 16:13:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:13:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:13:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:13:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:13:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:13:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Customers.php 252
ERROR - 2022-03-01 16:13:42 --> Severity: Notice --> Undefined property: stdClass::$slug C:\laragon\www\git\erp_swapon\application\models\Customers.php 254
ERROR - 2022-03-01 16:14:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:14:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:14:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:14:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:14:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:24:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:24:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:24:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:24:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:48:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:48:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-01 16:48:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-01 16:48:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-01 16:48:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-01 16:48:38 --> 404 Page Not Found: Assets/js
