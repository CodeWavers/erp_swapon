<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<<<<<<< HEAD
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 08:37:20 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-26 10:50:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 10:51:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 215
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:42 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:42 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 215
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:56 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:58:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:09:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:30:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:30:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:30:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:30:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:30:20 --> 404 Page Not Found: Assets/js
=======
ERROR - 2022-02-26 06:01:42 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 06:01:42 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 06:01:42 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 06:01:42 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 06:01:43 --> Severity: Warning --> A non-numeric value encountered F:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-26 06:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 06:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 06:22:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 06:22:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 06:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 06:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 06:22:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 06:22:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 06:22:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 06:22:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 06:22:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 06:22:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 06:29:54 --> The upload path does not appear to be valid.
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: customer_address F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: customer_mobile F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: customer_email F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: is_unit F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: is_desc F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: is_serial F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: is_discount F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: discount_type F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-26 06:29:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-26 07:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:04:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:04:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:05:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:05:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:05:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:05:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:09:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:09:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:09:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:12:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:12:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:12:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:12:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:12:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:15:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:15:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:15:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:15:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:15:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:15:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:16:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:17:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:17:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:17:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:17:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:17:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:17:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:17:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:17:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:21:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:21:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:21:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:21:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:21:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:21:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:24:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:24:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:24:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:24:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:24:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:25:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:25:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:25:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:25:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:46:49 --> The upload path does not appear to be valid.
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: customer_address F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: customer_mobile F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: customer_email F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: is_unit F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: is_desc F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: is_serial F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: is_discount F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: discount_type F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: position F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: currency F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Undefined variable: invoice_all_data F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-26 07:46:52 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-26 07:49:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:49:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:49:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:49:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:49:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:49:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:51:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:51:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:51:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:51:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:52:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:52:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:52:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:52:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:53:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:53:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 07:53:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 07:53:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 07:53:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 07:53:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:06:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:06:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:06:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:06:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:06:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:06:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:16:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:16:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:16:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:16:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:18:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:18:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:18:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:18:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:18:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:18:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:19:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:19:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:19:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:19:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:19:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:19:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:20:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:20:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:20:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:20:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:20:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:20:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:20:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:20:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:20:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:20:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:21:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:21:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:21:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:21:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:21:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:21:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:26:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:26:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:26:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:37:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:37:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 08:37:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:37:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 08:37:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 08:37:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 08:38:56 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 09:15:30 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to get property 'customer_name' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1687
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1689
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to get property 'customer_name' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1716
ERROR - 2022-02-26 09:15:48 --> Severity: Notice --> Trying to get property 'customer_name' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1732
ERROR - 2022-02-26 09:15:48 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES (NULL, 'INV', NULL, NULL, 'Customer debit For Invoice NO -  customer-  ', NULL, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-26 09:15:48', 1)
ERROR - 2022-02-26 09:15:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\erp_swapon\system\core\Exceptions.php:271) F:\xampp\htdocs\erp_swapon\system\core\Common.php 570
ERROR - 2022-02-26 09:16:48 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 09:17:42 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 09:21:43 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 09:32:04 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1675
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to get property 'customer_name' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1687
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1689
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to get property 'customer_name' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1716
ERROR - 2022-02-26 09:32:17 --> Severity: Notice --> Trying to get property 'customer_name' of non-object F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1732
ERROR - 2022-02-26 09:32:17 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES (NULL, 'INV', NULL, NULL, 'Customer debit For Invoice NO -  customer-  ', NULL, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-26 09:32:17', 1)
ERROR - 2022-02-26 09:32:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at F:\xampp\htdocs\erp_swapon\system\core\Exceptions.php:271) F:\xampp\htdocs\erp_swapon\system\core\Common.php 570
ERROR - 2022-02-26 09:45:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 09:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 09:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 09:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 09:45:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 09:45:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 09:48:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 09:48:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 09:48:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 09:48:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 09:48:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 09:48:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 09:59:57 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 10:01:29 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\models\Invoices.php 1808
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:03:13 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:11:18 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:12:59 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:13:00 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 407
ERROR - 2022-02-26 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 407
ERROR - 2022-02-26 10:13:00 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 413
ERROR - 2022-02-26 10:13:00 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 413
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:14:12 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:14:13 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 407
ERROR - 2022-02-26 10:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 407
ERROR - 2022-02-26 10:14:13 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 413
ERROR - 2022-02-26 10:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 413
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:14:41 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:14:42 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 407
ERROR - 2022-02-26 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 407
ERROR - 2022-02-26 10:14:42 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 413
ERROR - 2022-02-26 10:14:42 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 413
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:15:33 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:20:50 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:20:50 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:20:50 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:20:50 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-02-26 10:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-02-26 10:20:51 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-02-26 10:20:51 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 10:31:45 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 207
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 219
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 224
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 225
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 226
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 228
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 229
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 230
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 231
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 232
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 233
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 234
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 235
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 236
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 239
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 240
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type bool F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 11:37:54 --> Severity: Notice --> Trying to access array offset on value of type null F:\xampp\htdocs\erp_swapon\application\libraries\Lpurchase.php 246
ERROR - 2022-02-26 11:37:55 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-02-26 11:37:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-02-26 11:37:55 --> Severity: Notice --> Undefined variable: card_list F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-02-26 11:37:55 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\erp_swapon\application\views\purchase\edit_purchase_form.php 412
>>>>>>> 4d1eba44a166544beba56b50bd5915957b90c018
