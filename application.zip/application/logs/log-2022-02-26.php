<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 08:37:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 08:37:20 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-26 10:50:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 10:51:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-26 10:51:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:52:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:52:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:53:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 215
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:42 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:42 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:42 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-26 10:55:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 215
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 259
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 263
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 267
ERROR - 2022-02-26 10:55:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:56 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 280
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 286
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 337
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:56 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:55:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:58:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 10:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:09:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:09:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:29:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:30:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:30:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-26 11:30:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-26 11:30:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-26 11:30:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-26 11:30:20 --> 404 Page Not Found: Assets/js
