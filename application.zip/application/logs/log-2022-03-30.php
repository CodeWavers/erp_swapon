<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-30 04:44:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-30 04:44:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-30 04:44:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-30 04:44:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-30 04:44:34 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
