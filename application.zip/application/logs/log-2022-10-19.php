<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-19 11:12:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-19 11:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-19 11:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-19 11:26:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-19 11:26:14 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 11:28:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-19 11:28:09 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 11:28:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-19 11:28:10 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 11:28:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-19 11:28:48 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1830
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1832
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1846
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1847
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1848
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1849
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1086
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1086
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-19 11:29:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-19 11:29:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-19 11:29:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1830
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1832
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1846
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1847
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1848
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1849
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1090
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1090
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-19 11:30:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1105
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1106
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type float C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1110
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 66
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 66
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 66
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 70
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 70
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 70
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 73
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 73
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 73
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 75
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 75
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 75
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 77
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 77
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 77
ERROR - 2022-10-19 11:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 164
ERROR - 2022-10-19 11:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 189
ERROR - 2022-10-19 11:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 309
ERROR - 2022-10-19 11:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 332
ERROR - 2022-10-19 11:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 355
ERROR - 2022-10-19 11:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 392
ERROR - 2022-10-19 11:30:19 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 494
ERROR - 2022-10-19 11:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 164
ERROR - 2022-10-19 11:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 189
ERROR - 2022-10-19 11:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 309
ERROR - 2022-10-19 11:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 332
ERROR - 2022-10-19 11:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 355
ERROR - 2022-10-19 11:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 392
ERROR - 2022-10-19 11:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 178
ERROR - 2022-10-19 11:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 203
ERROR - 2022-10-19 11:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 323
ERROR - 2022-10-19 11:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 346
ERROR - 2022-10-19 11:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 369
ERROR - 2022-10-19 11:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 406
ERROR - 2022-10-19 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 180
ERROR - 2022-10-19 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 205
ERROR - 2022-10-19 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 325
ERROR - 2022-10-19 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 348
ERROR - 2022-10-19 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 371
ERROR - 2022-10-19 11:34:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 408
ERROR - 2022-10-19 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 170
ERROR - 2022-10-19 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 325
ERROR - 2022-10-19 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 348
ERROR - 2022-10-19 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 371
ERROR - 2022-10-19 11:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 408
ERROR - 2022-10-19 11:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 170
ERROR - 2022-10-19 11:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 11:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 330
ERROR - 2022-10-19 11:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 353
ERROR - 2022-10-19 11:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 376
ERROR - 2022-10-19 11:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 413
ERROR - 2022-10-19 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 170
ERROR - 2022-10-19 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 330
ERROR - 2022-10-19 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 353
ERROR - 2022-10-19 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 376
ERROR - 2022-10-19 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 413
ERROR - 2022-10-19 11:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 170
ERROR - 2022-10-19 11:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 196
ERROR - 2022-10-19 11:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 331
ERROR - 2022-10-19 11:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 354
ERROR - 2022-10-19 11:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 11:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 414
ERROR - 2022-10-19 11:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 171
ERROR - 2022-10-19 11:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 197
ERROR - 2022-10-19 11:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 334
ERROR - 2022-10-19 11:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 358
ERROR - 2022-10-19 11:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 382
ERROR - 2022-10-19 11:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 420
ERROR - 2022-10-19 11:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 171
ERROR - 2022-10-19 11:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 197
ERROR - 2022-10-19 11:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 333
ERROR - 2022-10-19 11:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 357
ERROR - 2022-10-19 11:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 381
ERROR - 2022-10-19 11:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 419
ERROR - 2022-10-19 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 171
ERROR - 2022-10-19 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 197
ERROR - 2022-10-19 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 333
ERROR - 2022-10-19 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 357
ERROR - 2022-10-19 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 381
ERROR - 2022-10-19 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 419
ERROR - 2022-10-19 12:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 171
ERROR - 2022-10-19 12:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 197
ERROR - 2022-10-19 12:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 266
ERROR - 2022-10-19 12:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 356
ERROR - 2022-10-19 12:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 380
ERROR - 2022-10-19 12:00:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 404
ERROR - 2022-10-19 12:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 171
ERROR - 2022-10-19 12:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 197
ERROR - 2022-10-19 12:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 266
ERROR - 2022-10-19 12:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 356
ERROR - 2022-10-19 12:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 380
ERROR - 2022-10-19 12:03:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 404
ERROR - 2022-10-19 12:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 171
ERROR - 2022-10-19 12:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 197
ERROR - 2022-10-19 12:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 266
ERROR - 2022-10-19 12:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 356
ERROR - 2022-10-19 12:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 380
ERROR - 2022-10-19 12:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 404
ERROR - 2022-10-19 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 201
ERROR - 2022-10-19 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 270
ERROR - 2022-10-19 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 360
ERROR - 2022-10-19 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 384
ERROR - 2022-10-19 12:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 408
ERROR - 2022-10-19 12:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 276
ERROR - 2022-10-19 12:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 366
ERROR - 2022-10-19 12:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 390
ERROR - 2022-10-19 12:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 414
ERROR - 2022-10-19 12:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 277
ERROR - 2022-10-19 12:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 367
ERROR - 2022-10-19 12:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 391
ERROR - 2022-10-19 12:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 415
ERROR - 2022-10-19 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 279
ERROR - 2022-10-19 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 369
ERROR - 2022-10-19 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 393
ERROR - 2022-10-19 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 417
ERROR - 2022-10-19 12:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:16:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:21:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:21:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:21:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:21:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:21:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:21:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:21:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:22:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:22:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:24:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:26:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 289
ERROR - 2022-10-19 12:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 379
ERROR - 2022-10-19 12:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 403
ERROR - 2022-10-19 12:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 427
ERROR - 2022-10-19 12:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 384
ERROR - 2022-10-19 12:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 408
ERROR - 2022-10-19 12:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 432
ERROR - 2022-10-19 12:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 384
ERROR - 2022-10-19 12:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 408
ERROR - 2022-10-19 12:31:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 432
ERROR - 2022-10-19 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 12:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 12:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 12:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 12:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 12:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 12:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 12:34:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 12:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 12:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 12:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 12:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 12:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 12:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 12:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 12:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 12:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 13:09:58 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:10:10 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:10:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:10:10 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:10:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:10:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:10:16 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:10:20 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:11:02 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:11:03 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:11:03 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:11:04 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:11:14 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:11:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:11:14 --> Severity: error --> Exception: Call to undefined function get() C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1690
ERROR - 2022-10-19 13:12:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:12:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:12:43 --> Query error: Unknown column 'acc_transaction.VDate' in 'where clause' - Invalid query: SELECT *
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
WHERE `HeadType` = 'I'
AND `b`.`VDate` >= '2022-10-19'
AND `acc_transaction`.`VDate` <= '2022-10-19'
AND  `COAID` LIKE '%3040%' ESCAPE '!'
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1600
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_ac_pay C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1828
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1830
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1832
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1846
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1847
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1848
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1849
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Undefined variable: arr_ac_rcv C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1850
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1090
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1090
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-19 13:13:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1114
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1115
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 13:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 13:13:28 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 571
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 13:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 13:24:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 13:25:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-19 13:28:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 13:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 13:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 13:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:21:00 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1124
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:30:11 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-10-19 14:30:26 --> Query error: Unknown column 'acc_transaction.VDate' in 'where clause' - Invalid query: SELECT *
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `x`.`outlet_id` = '1'
AND `HeadType` = 'E'
AND  `COAID` LIKE '%4010%' ESCAPE '!'
AND `acc_transaction`.`VDate` >= '2022-01-19'
AND `acc_transaction`.`VDate` <= '2022-10-19'
ERROR - 2022-10-19 14:30:26 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1653
ERROR - 2022-10-19 14:30:46 --> Query error: Unknown column 'acc_transaction.VDate' in 'where clause' - Invalid query: SELECT *
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `x`.`outlet_id` = '1'
AND `HeadType` = 'E'
AND  `COAID` LIKE '%4010%' ESCAPE '!'
AND `acc_transaction`.`VDate` >= '2022-01-19'
AND `acc_transaction`.`VDate` <= '2022-10-19'
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_ac_pay C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1838
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1840
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1842
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1856
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1857
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1858
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1859
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Undefined variable: arr_ac_rcv C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1860
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:34:53 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1110
ERROR - 2022-10-19 14:34:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1580
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:36:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:36:07 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-10-19 14:36:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-19 14:36:20 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-10-19 14:36:24 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1110
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_ac_pay C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1838
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1840
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1842
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1856
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1857
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1858
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1859
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Undefined variable: arr_ac_rcv C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1860
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:37:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:37:58 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1110
ERROR - 2022-10-19 14:37:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_ac_pay C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1838
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1840
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1842
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1856
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1857
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1858
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1859
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Undefined variable: arr_ac_rcv C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1860
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:38:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:38:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1127
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1128
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined index: sales_discount C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1180
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:38:40 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 571
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:39:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:40:21 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1580
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:40:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:40:36 --> Severity: error --> Exception: Call to undefined method reports::outlet_stock() C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-10-19 14:40:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1580
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1241
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1242
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-19 14:41:22 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 568
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 14:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 134
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 161
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 190
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 278
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 320
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 373
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 397
ERROR - 2022-10-19 14:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 421
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 134
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 161
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 190
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 278
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 320
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 373
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 397
ERROR - 2022-10-19 14:47:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 421
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:05:03 --> Query error: Unknown column 'outlet_warehouse.id' in 'where clause' - Invalid query: SELECT *, (sum(b.debit)-sum(b.credit)) as total_debit
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `outlet_warehouse`.`id` IS NULL
AND `HeadType` = 'A'
AND `b`.`VDate` >= '2022-01-19'
AND `b`.`VDate` <= '2022-10-19'
AND  `COAID` LIKE '%1020%' ESCAPE '!'
ERROR - 2022-10-19 15:05:03 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1619
ERROR - 2022-10-19 15:05:24 --> Query error: Unknown column 'outlet_warehouse.id' in 'where clause' - Invalid query: SELECT *, (sum(b.debit)-sum(b.credit)) as total_debit
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `outlet_warehouse`.`id` IS NULL
AND `HeadType` = 'A'
AND `b`.`VDate` >= '2022-01-19'
AND `b`.`VDate` <= '2022-10-19'
AND  `COAID` LIKE '%1020%' ESCAPE '!'
ERROR - 2022-10-19 15:07:08 --> Query error: Unknown column 'outlet_warehouse.id' in 'where clause' - Invalid query: SELECT *, (sum(b.debit)-sum(b.credit)) as total_debit
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `outlet_warehouse`.`id` IS NULL
AND `HeadType` = 'A'
AND `b`.`VDate` >= '2022-01-19'
AND `b`.`VDate` <= '2022-10-19'
AND  `COAID` LIKE '%1020%' ESCAPE '!'
ERROR - 2022-10-19 15:07:18 --> Query error: Unknown column 'outlet_warehouse.id' in 'where clause' - Invalid query: SELECT *, (sum(b.debit)-sum(b.credit)) as total_debit
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `outlet_warehouse`.`id` IS NULL
AND `HeadType` = 'A'
AND `b`.`VDate` >= '2022-01-19'
AND `b`.`VDate` <= '2022-10-19'
AND  `COAID` LIKE '%1020%' ESCAPE '!'
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Undefined variable: arr_ncl C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1904
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Undefined variable: arr_fixed_assets C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1906
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Undefined variable: arr_cash_bank C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1920
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Undefined variable: arr_cash_bkash C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1921
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Undefined variable: arr_cash_nagad C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1922
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Undefined variable: arr_em_led C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1923
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 15:09:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1527
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 15:09:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1127
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1128
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined index: sales_discount C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1180
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 82
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 86
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 89
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 91
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 15:09:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 93
ERROR - 2022-10-19 15:09:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:09:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:09:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:09:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:09:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:09:23 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 571
ERROR - 2022-10-19 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:10:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 324
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:33:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-19 15:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:45:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:59:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:59:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:59:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:59:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:59:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:59:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 15:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 165
ERROR - 2022-10-19 15:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 194
ERROR - 2022-10-19 15:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 282
ERROR - 2022-10-19 15:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 377
ERROR - 2022-10-19 15:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 401
ERROR - 2022-10-19 15:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 425
ERROR - 2022-10-19 16:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 166
ERROR - 2022-10-19 16:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 16:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 283
ERROR - 2022-10-19 16:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 378
ERROR - 2022-10-19 16:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 402
ERROR - 2022-10-19 16:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 426
ERROR - 2022-10-19 16:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 166
ERROR - 2022-10-19 16:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 16:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 283
ERROR - 2022-10-19 16:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 378
ERROR - 2022-10-19 16:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 402
ERROR - 2022-10-19 16:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 426
ERROR - 2022-10-19 16:07:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 166
ERROR - 2022-10-19 16:07:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 16:07:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 283
ERROR - 2022-10-19 16:07:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 378
ERROR - 2022-10-19 16:07:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 402
ERROR - 2022-10-19 16:07:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 426
ERROR - 2022-10-19 16:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 166
ERROR - 2022-10-19 16:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-19 16:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 283
ERROR - 2022-10-19 16:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 378
ERROR - 2022-10-19 16:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 402
ERROR - 2022-10-19 16:08:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 426
ERROR - 2022-10-19 16:18:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 403
ERROR - 2022-10-19 16:27:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 403
ERROR - 2022-10-19 17:25:56 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-19 17:28:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-19 17:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-19 17:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-19 17:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-19 17:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-19 17:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-19 17:31:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:31:50 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 17:32:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:32:15 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 17:32:22 --> Severity: error --> Exception: Too few arguments to function Creport::stock_taking_view(), 1 passed in C:\laragon\www\git\erp_swapon\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 116
ERROR - 2022-10-19 17:32:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:32:33 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 17:33:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:33:39 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 17:33:44 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-19 17:33:44 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-19 17:33:44 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-19 17:33:44 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-19 17:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:35:05 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-19 17:35:05 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-19 17:35:05 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-19 17:35:05 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-19 17:37:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-19 17:37:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-19 17:37:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-19 17:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-19 17:37:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:37:31 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-19 17:37:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-19 17:37:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-19 17:37:55 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
