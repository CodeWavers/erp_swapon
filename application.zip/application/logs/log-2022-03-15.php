<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-15 04:42:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-15 04:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-15 04:45:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:45:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:45:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 04:45:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:45:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:46:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:46:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:46:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:46:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:46:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 04:46:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-15 04:47:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:47:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:47:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:47:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 04:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:47:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:47:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:47:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:47:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:47:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 04:47:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:48:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:48:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:48:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 04:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:49:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:49:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:49:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 04:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-15 04:57:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 04:57:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 04:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 04:57:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 05:23:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 05:23:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 05:23:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 05:23:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 05:23:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 05:23:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 05:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 05:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 05:29:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 05:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 05:29:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 05:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:03:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:03:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 06:03:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:03:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 06:03:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:03:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 06:03:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:03:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 06:03:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 06:03:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:03:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 06:03:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-15 06:08:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-15 06:08:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:08:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-15 06:08:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-15 06:12:49 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:10 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:11 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:11 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:12 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:12 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:12 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:13 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:14:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 108
ERROR - 2022-03-15 06:28:45 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 113
ERROR - 2022-03-15 06:29:43 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 122
ERROR - 2022-03-15 06:35:27 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 260
ERROR - 2022-03-15 06:36:10 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 260
ERROR - 2022-03-15 06:36:17 --> Severity: error --> Exception: Cannot use [] for reading C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 131
ERROR - 2022-03-15 06:36:56 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 260
ERROR - 2022-03-15 06:38:11 --> Severity: Compile Error --> Cannot use [] for reading C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 260
ERROR - 2022-03-15 06:38:18 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 260
ERROR - 2022-03-15 08:11:15 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 114
ERROR - 2022-03-15 08:11:15 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 268
ERROR - 2022-03-15 08:11:55 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 268
ERROR - 2022-03-15 08:11:55 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:12:24 --> Severity: Notice --> Undefined index: select_check C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 114
ERROR - 2022-03-15 08:13:18 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:16:38 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:17:03 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:17:38 --> Severity: error --> Exception: [] operator not supported for strings C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 117
ERROR - 2022-03-15 08:17:58 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:19:40 --> Severity: error --> Exception: [] operator not supported for strings C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 117
ERROR - 2022-03-15 08:37:06 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:37:44 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:37:50 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 08:38:29 --> Severity: error --> Exception: [] operator not supported for strings C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 117
ERROR - 2022-03-15 11:33:33 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-15 11:43:53 --> 404 Page Not Found: OrderController/show_all
