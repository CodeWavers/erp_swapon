<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-20 05:35:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 05:37:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 05:47:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:47:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:47:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:49:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:49:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:49:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:49:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:50:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:50:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:50:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:50:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:50:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:52:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:52:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:52:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:52:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:52:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:52:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:52:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:52:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:52:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:52:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:56:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:56:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:56:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:56:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:56:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:56:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 05:56:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 05:56:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 05:56:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 05:56:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:00:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:00:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:00:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:00:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:01:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:01:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:01:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:01:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:01:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:02:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:02:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:04:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:04:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:04:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:08:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:08:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:08:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:08:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:08:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:08:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:08:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-08-20 06:09:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-08-20 06:11:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220820061102', 'Purchase', '2022-08-20', NULL, 'Supplier .Factory', 0, '84486.00', 1, 'OpSoxJvBbbS8Rws', '2022-08-20', 1)
ERROR - 2022-08-20 06:11:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:11:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:12:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:12:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:15:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:15:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:15:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:15:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:15:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:16:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:16:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:16:12 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:16:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:16:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:16:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:16:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:16:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:16:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:16:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:17:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:17:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:17:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:17:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:17:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:17:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:17:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:17:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:17:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:17:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:17:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:17:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:17:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:17:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:17:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:18:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:18:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:18:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:18:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:18:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:18:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:18:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:19:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:19:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:19:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:19:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:19:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:19:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:19:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:19:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:19:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:19:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:21:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:21:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 06:21:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 06:21:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:21:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 06:21:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 06:21:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:22:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:23:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 06:35:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-20 07:21:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 07:21:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 07:21:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 07:21:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 07:21:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 07:21:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 07:22:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 07:22:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:32:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:36:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:36:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:36:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:36:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:36:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:36:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:36:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:36:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:36:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:36:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:36:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:36:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:36:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:37:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:37:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:37:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:37:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:38:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:38:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:40:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:40:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:40:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:40:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:40:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 385
ERROR - 2022-08-20 08:41:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:41:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:41:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:41:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:41:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 385
ERROR - 2022-08-20 08:41:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:41:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:41:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:41:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:41:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:42:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 385
ERROR - 2022-08-20 08:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:42:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:42:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:42:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:44:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:44:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:44:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:44:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:44:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:44:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:44:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:44:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 08:44:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:44:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:44:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:44:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 385
ERROR - 2022-08-20 08:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:45:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:49:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:53:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:55:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:58:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 08:58:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 08:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:58:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 08:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 08:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:00:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:00:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:00:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:00:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:00:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:00:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:01:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:01:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:01:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:01:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:01:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:01:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:01:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:02:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:02:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:02:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 392
ERROR - 2022-08-20 09:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:07:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 392
ERROR - 2022-08-20 09:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:07:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:07:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:10:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:36:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:36:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:36:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 391
ERROR - 2022-08-20 09:42:03 --> Severity: error --> Exception: Call to a member function get_courier_list() on null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 43
ERROR - 2022-08-20 09:42:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:42:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:42:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:42:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:42:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:44:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:44:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:44:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:44:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:46:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:46:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:46:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:46:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:47:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-08-20 09:47:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-08-20 09:48:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:48:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:48:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:48:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:48:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:48:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:53:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:53:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:53:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:53:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:53:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:53:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:55:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:55:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:55:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:55:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:55:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:55:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:57:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:57:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:57:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:57:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 09:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:58:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-08-20 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 09:59:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 09:59:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:59:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 09:59:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:00:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:00:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:00:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:00:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:25:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:25:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:25:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:25:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:25:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:25:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:28:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:28:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:28:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:28:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:28:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:28:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 568
ERROR - 2022-08-20 10:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 625
ERROR - 2022-08-20 10:29:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:29:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:29:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:29:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:29:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:35:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:35:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:35:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:35:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:40:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:40:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:40:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:40:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:40:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:40:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:42:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:42:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:42:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:42:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:42:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:43:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:43:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:43:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:43:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:43:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:43:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:43:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:49:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:49:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:49:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:49:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:49:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:51:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:51:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:51:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:51:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:51:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:51:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:51:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:51:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:52:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 567
ERROR - 2022-08-20 10:52:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 624
ERROR - 2022-08-20 10:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:52:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:52:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:54:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 608
ERROR - 2022-08-20 10:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:54:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:54:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:54:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 608
ERROR - 2022-08-20 10:55:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:55:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:55:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:55:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:55:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:56:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 608
ERROR - 2022-08-20 10:56:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:56:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:56:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:56:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:56:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:56:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:56:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 608
ERROR - 2022-08-20 10:56:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:56:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:56:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:56:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 10:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 609
ERROR - 2022-08-20 10:57:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:57:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 10:57:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 10:57:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:57:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 10:57:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:06:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 609
ERROR - 2022-08-20 11:07:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 609
ERROR - 2022-08-20 11:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 609
ERROR - 2022-08-20 11:12:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 611
ERROR - 2022-08-20 11:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:18:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:18:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:20:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:20:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:20:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:20:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:26:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:26:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:26:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 611
ERROR - 2022-08-20 11:26:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:26:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:26:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:26:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:26:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:26:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:29:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:29:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 611
ERROR - 2022-08-20 11:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:30:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:30:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:30:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:30:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:31:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 611
ERROR - 2022-08-20 11:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:31:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-20 11:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-20 11:31:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-20 11:31:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-20 11:31:16 --> 404 Page Not Found: Assets/js
