<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-13 05:23:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-13 05:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 05:25:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-13 05:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 05:29:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 05:29:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-13 05:29:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-13 05:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 05:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1164
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:40:00 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 05:54:00 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 05:55:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1150
ERROR - 2022-02-13 05:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1164
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:03:33 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:04:01 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:05:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:06:23 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1164
ERROR - 2022-02-13 06:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1150
ERROR - 2022-02-13 06:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:13:13 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:15:54 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:00 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:17:58 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 06:20:45 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 06:20:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:11:06 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:18:58 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:28:22 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 07:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1186
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:39:51 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:51:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 07:53:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:01:19 --> Query error: Unknown column 'barcode' in 'field list' - Invalid query: UPDATE `product_information` SET `barcode` = '031133', `name` = 'Shallu-041133', `added_by` = 'ERP', `cats` = '2,3', `brand_id` = '14', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `description` = 'Test', `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:02:28 --> Query error: Unknown column 'name' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `name` = 'Shallu-041133', `added_by` = 'ERP', `cats` = '2,3', `brand_id` = '14', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `description` = 'Test', `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:04:16 --> Query error: Unknown column 'added_by' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `added_by` = 'ERP', `cats` = '2,3', `brand_id` = '14', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `description` = 'Test', `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:05:59 --> Query error: Unknown column 'cats' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `cats` = '2,3', `brand_id` = '14', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `description` = 'Test', `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:06:59 --> Query error: Unknown column 'video_provider' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `description` = 'Test', `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:08:36 --> Query error: Unknown column 'tags' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:08:53 --> Query error: Unknown column 'sku' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `sku` = 'Sh Sku', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `unit` = 'Pcs', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:09:27 --> Query error: Unknown column 'colors' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:09:53 --> Query error: Unknown column 'product_status' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `product_status` = '1', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:10:29 --> Query error: Unknown column 'min_qty' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `min_qty` = '12', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:10:41 --> Query error: Unknown column 'unit_price' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `tax` = 0, `unit_price` = '7000', `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:10:51 --> Query error: Unknown column 'refundable' in 'field list' - Invalid query: UPDATE `product_information` SET `product_id` = '031133', `product_name` = 'Shallu-041133', `brand_id` = '14', `tax` = 0, `refundable` = 'on', `image` = NULL
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:11:03 --> Query error: Unknown column 'product_id' in 'where clause' - Invalid query: UPDATE `products` SET `product_id` = '031133', `category_id` = '2,3', `brand_id` = '14', `name` = 'Shallu-041133', `added_by` = 'ERP', `finished_raw` = '1', `price` = '7000', `cats` = '2,3', `unit` = 'Pcs', `tax` = 0, `product_details` = 'Test', `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '12', `unit_price` = '7000', `refundable` = 'on'
WHERE `product_id` = '031133'
ERROR - 2022-02-13 08:17:26 --> Query error: Unknown column 'product_id' in 'field list' - Invalid query: UPDATE `products` SET `product_id` = '031133', `category_id` = '2,3', `brand_id` = '14', `name` = 'Shallu-041133', `added_by` = 'ERP', `finished_raw` = '1', `price` = '7000', `cats` = '2,3', `unit` = 'Pcs', `tax` = 0, `product_details` = 'Test', `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'Specific Tags', `sku` = 'Sh Sku', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '12', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:17:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 08:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1186
ERROR - 2022-02-13 08:24:35 --> Query error: Unknown column 'product_id' in 'field list' - Invalid query: UPDATE `products` SET `product_id` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `finished_raw` = '1', `price` = '7000', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `product_details` = 'Test', `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 08:26:54 --> Query error: Unknown column 'finished_raw' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `finished_raw` = '1', `price` = '7000', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `product_details` = 'Test', `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:23:55 --> Query error: Unknown column 'price' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `price` = '7000', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `product_details` = 'Test', `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:25:13 --> Query error: Unknown column 'product_details' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `product_details` = 'Test', `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:25:58 --> Query error: Unknown column 'image' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:26:20 --> Query error: Unknown column 'image' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `image` = NULL, `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:26:43 --> Query error: Unknown column 'image' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:28:19 --> Query error: Unknown column 'image' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `image` = 'https://localhost/erp_swapon/my-assets/image/product.png', `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on', `thumbnail_img` = NULL
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:28:46 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `products` SET `barcode` = '031133', `category_id` = '1,2', `brand_id` = '12', `name` = 'Shallu-091133', `added_by` = 'ERP', `cats` = '1,2', `unit` = 'Dozen', `tax` = 0, `thumbnail_img` = NULL, `status` = 1, `product_summary` = '<p>Arman Vhai</p>\r\n', `information` = '<p>Babu Vhai</p>\r\n', `tc` = '<p>Sarwar Vhai</p>\r\n', `video_provider` = '1', `video_link` = 'https://leetcode.com/problemset/all/', `description` = 'Test', `tags` = 'entire tag', `sku` = 'anananana', `variations` = '[]', `colors` = '#FA8072,#FFA07A', `product_status` = '1', `min_qty` = '1234', `unit_price` = '7000', `refundable` = 'on'
WHERE `barcode` = '031133'
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:30:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-13 10:44:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
