<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-30 04:43:14 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-30 04:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-30 04:47:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 04:47:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 04:47:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 04:47:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 04:47:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 04:47:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 04:52:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-30 04:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 04:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 04:52:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 04:52:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 04:52:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 04:52:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 06:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 645
ERROR - 2022-08-30 06:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 648
ERROR - 2022-08-30 06:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 648
ERROR - 2022-08-30 06:55:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 648
ERROR - 2022-08-30 07:15:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 648
ERROR - 2022-08-30 07:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:20:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:24:47 --> The upload path does not appear to be valid.
ERROR - 2022-08-30 07:24:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:57:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 07:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 08:00:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 08:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 649
ERROR - 2022-08-30 08:01:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 650
ERROR - 2022-08-30 08:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 650
ERROR - 2022-08-30 08:03:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 652
ERROR - 2022-08-30 08:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 654
ERROR - 2022-08-30 08:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 652
ERROR - 2022-08-30 08:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 643
ERROR - 2022-08-30 08:09:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-08-30 08:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 650
ERROR - 2022-08-30 08:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 650
ERROR - 2022-08-30 08:10:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 650
ERROR - 2022-08-30 08:11:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 650
ERROR - 2022-08-30 08:19:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 651
ERROR - 2022-08-30 08:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 652
ERROR - 2022-08-30 08:23:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 660
ERROR - 2022-08-30 08:23:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 660
ERROR - 2022-08-30 08:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 660
ERROR - 2022-08-30 08:28:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 657
ERROR - 2022-08-30 08:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 662
ERROR - 2022-08-30 08:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 662
ERROR - 2022-08-30 08:30:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-30 08:31:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 662
ERROR - 2022-08-30 08:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 662
ERROR - 2022-08-30 08:33:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 662
ERROR - 2022-08-30 08:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 662
ERROR - 2022-08-30 08:40:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 663
ERROR - 2022-08-30 08:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 663
ERROR - 2022-08-30 08:43:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 663
ERROR - 2022-08-30 08:44:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 663
ERROR - 2022-08-30 08:44:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 663
ERROR - 2022-08-30 08:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 663
ERROR - 2022-08-30 08:59:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 675
ERROR - 2022-08-30 08:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 675
ERROR - 2022-08-30 09:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 684
ERROR - 2022-08-30 09:02:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 685
ERROR - 2022-08-30 09:04:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:05:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:06:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:06:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:11:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:12:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:13:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:20:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:20:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 09:48:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-08-30 09:48:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-08-30 09:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-08-30 09:49:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 09:50:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 09:53:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 708
ERROR - 2022-08-30 09:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 708
ERROR - 2022-08-30 09:56:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 708
ERROR - 2022-08-30 09:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 09:58:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 09:58:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:11:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:12:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:15:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:20:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-08-30 10:23:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 10:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 10:28:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 10:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-30 10:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-30 10:40:10 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220830104010', 'Purchase', '2022-08-30', NULL, 'Supplier .Factory', 0, '100000.00', 1, 'OpSoxJvBbbS8Rws', '2022-08-30', 1)
ERROR - 2022-08-30 10:42:38 --> The upload path does not appear to be valid.
ERROR - 2022-08-30 10:42:38 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8162684832', 'INV-CC', '2022-08-30', NULL, 'Courier Debit For Invoice No -  1052 Courier  Karanfuli Paribahan', 0, 17160, 1, 'OpSoxJvBbbS8Rws', '2022-08-30 10:42:38', 1)
ERROR - 2022-08-30 10:42:38 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8162684832', 'INV-CC', '2022-08-30', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1052 Courier  Karanfuli Paribahan', 10, 0, 1, 'OpSoxJvBbbS8Rws', '2022-08-30 10:42:38', 1)
ERROR - 2022-08-30 10:42:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 10:44:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 692
ERROR - 2022-08-30 10:46:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 699
ERROR - 2022-08-30 10:51:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-08-30 10:52:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-08-30 10:59:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-08-30 11:08:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-08-30 11:17:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 705
ERROR - 2022-08-30 11:18:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:20:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:20:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:20:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:20:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:20:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:20:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:20:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-30 11:21:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-30 11:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:23:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:23:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:23:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:23:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:23:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:24:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:24:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:25:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:25:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:27:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:27:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:28:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:28:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:28:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:28:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:28:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:28:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:29:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:29:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:30:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:30:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:31:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:31:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:32:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:33:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:33:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:33:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:33:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:33:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:33:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:35:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:35:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:35:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-30 11:35:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-30 11:35:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:35:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-30 11:35:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-30 11:36:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-30 11:46:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
