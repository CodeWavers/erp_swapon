<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-17 10:35:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-17 10:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 11:08:59 --> Query error: Not unique table/alias: 'b' - Invalid query: SELECT *
FROM `card_list` `a`
JOIN `bank_add` `b` ON `a`.`bank_id`=`b`.`bank_id`
JOIN `card` `b` ON `a`.`card_id` = `b`.`card_id`
ERROR - 2022-09-17 11:08:59 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Settings.php 1121
ERROR - 2022-09-17 11:09:01 --> Query error: Not unique table/alias: 'b' - Invalid query: SELECT *
FROM `card_list` `a`
JOIN `bank_add` `b` ON `a`.`bank_id`=`b`.`bank_id`
JOIN `card` `b` ON `a`.`card_id` = `b`.`card_id`
ERROR - 2022-09-17 11:09:01 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Settings.php 1121
ERROR - 2022-09-17 11:09:41 --> Query error: Not unique table/alias: 'b' - Invalid query: SELECT *
FROM `card_list` `a`
LEFT JOIN `bank_add` `b` ON `a`.`bank_id`=`b`.`bank_id`
JOIN `card` `b` ON `a`.`card_id` = `b`.`card_id`
ERROR - 2022-09-17 11:14:02 --> Severity: Notice --> Undefined variable: agg_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 68
ERROR - 2022-09-17 11:14:03 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 71
ERROR - 2022-09-17 11:14:03 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 11:14:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 11:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:25:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:27:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:40:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:40:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:40:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 12:40:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 12:40:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 12:40:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:40:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:40:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 12:40:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 12:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:40:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 12:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:44:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:45:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:45:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:48:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 12:48:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 12:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:48:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 12:48:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 12:48:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 12:59:22 --> The upload path does not appear to be valid.
ERROR - 2022-09-17 12:59:22 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6991969811', 'INV-CC', '2022-09-17', NULL, 'Customer debit For Invoice No -  1009 Customer ', '4000.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-17 12:59:22', 1)
ERROR - 2022-09-17 12:59:22 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 994
ERROR - 2022-09-17 12:59:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 13:14:38 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6991969811', 'INV', '2022-09-17', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6991969811 Customer- ', 0, '', 1, 'OpSoxJvBbbS8Rws', '2022-09-17 13:14:38', 1)
ERROR - 2022-09-17 13:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 14:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:48:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 14:48:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:48:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 14:49:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 14:51:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:51:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 14:51:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 14:51:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:51:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:51:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 14:53:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:53:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 14:53:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 14:53:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 14:53:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 14:53:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:27:41 --> The upload path does not appear to be valid.
ERROR - 2022-09-17 15:27:41 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9733284257', 'INV-CC', '2022-09-17', NULL, 'Customer debit For Invoice No -  1010 Customer ', '21216.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-17 15:27:41', 1)
ERROR - 2022-09-17 15:27:41 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 994
ERROR - 2022-09-17 15:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:30:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:31:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:32:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:32:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:32:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:32:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:32:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:32:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:32:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:33:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:33:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:33:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:33:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:33:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:33:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:34:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:34:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:34:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:34:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:34:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:34:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:34:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:34:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:34:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:34:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:35:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:35:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:35:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:35:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:35:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:35:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:35:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:35:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:35:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:35:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:35:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:35:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:03 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-17 15:50:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:50:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:50:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\supplier_payment_form.php 179
ERROR - 2022-09-17 15:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\supplier_payment_form.php 185
ERROR - 2022-09-17 15:51:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:51:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:51:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:51:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:51:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:51:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 15:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:51:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 15:51:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 15:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 15:51:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-17 15:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 724
ERROR - 2022-09-17 16:08:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:08:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:08:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:08:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:08:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:08:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 724
ERROR - 2022-09-17 16:09:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:09:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:09:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:09:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:09:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:09:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 725
ERROR - 2022-09-17 16:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:22:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:22:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:22:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:22:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:23:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 727
ERROR - 2022-09-17 16:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:24:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:24:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:24:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 727
ERROR - 2022-09-17 16:24:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:24:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:24:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:24:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:24:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:24:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:25:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 727
ERROR - 2022-09-17 16:25:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:25:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:25:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:25:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:25:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:25:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:27:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:27:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:27:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:27:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:27:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:27:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:28:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:28:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:28:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:28:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:28:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:29:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:29:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:29:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:33:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:34:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:34:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:34:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:34:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:36:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:36:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:36:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:36:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:36:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:37:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:37:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:37:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:37:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:37:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:39:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:39:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:39:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:39:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:39:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:39:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:42:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:43:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 16:43:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:43:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 16:43:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 16:43:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 16:48:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 729
ERROR - 2022-09-17 16:53:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 730
ERROR - 2022-09-17 16:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 730
ERROR - 2022-09-17 16:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 16:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:13:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 17:13:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 17:13:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-17 17:13:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-17 17:13:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-17 17:13:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-17 17:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:23:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:25:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:26:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
ERROR - 2022-09-17 17:34:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 731
