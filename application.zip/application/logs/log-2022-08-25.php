<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-25 04:46:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2831
ERROR - 2022-08-25 04:46:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2831
ERROR - 2022-08-25 04:46:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2898
ERROR - 2022-08-25 04:46:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2898
ERROR - 2022-08-25 04:46:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-25 05:11:28 --> Severity: Notice --> Undefined index: stid_no C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 94
ERROR - 2022-08-25 05:11:51 --> Severity: Notice --> Undefined index: stid_no C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 94
ERROR - 2022-08-25 05:31:08 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 163
ERROR - 2022-08-25 05:31:36 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 163
ERROR - 2022-08-25 05:31:37 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 163
ERROR - 2022-08-25 05:31:37 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 163
ERROR - 2022-08-25 05:31:38 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 163
ERROR - 2022-08-25 06:16:46 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 65
ERROR - 2022-08-25 06:16:46 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 66
ERROR - 2022-08-25 06:16:46 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 67
ERROR - 2022-08-25 06:16:46 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 79
ERROR - 2022-08-25 06:16:46 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 92
ERROR - 2022-08-25 06:16:46 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 118
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 65
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 66
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 67
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 79
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 92
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 100
ERROR - 2022-08-25 06:18:55 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 121
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 65
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 66
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 67
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 79
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 92
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 100
ERROR - 2022-08-25 06:19:21 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 145
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:04 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:30:54 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:31:09 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:09 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:09 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:09 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-08-25 06:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:31:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:31:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:31:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:31:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:31:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:31:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:31:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:33:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:33:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:33:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:33:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:33:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:33:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:37:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:37:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:41:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:41:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:41:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:41:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:44:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:44:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:44:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:44:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:44:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:44:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:45:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:45:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:45:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:45:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:45:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:45:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:45:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:45:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:45:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:45:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:46:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:46:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:46:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:46:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:46:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:46:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:47:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:47:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:47:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:47:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:51:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:51:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:51:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:51:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:51:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:51:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:52:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:52:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:53:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:53:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:53:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:53:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:53:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:53:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:53:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:53:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:53:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:53:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:54:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:54:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:54:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:54:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:54:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:54:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:54:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:54:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:58:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:58:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:58:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 06:58:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 06:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 06:58:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 06:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:00:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:00:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:00:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:00:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:00:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:00:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:00:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:00:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:00:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:00:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:00:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:00:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:00:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:01:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:01:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:01:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:01:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:01:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:01:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:01:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:02:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:02:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:02:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:02:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:02:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:02:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:02:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:03:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:03:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:03:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:03:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:03:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:03:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:03:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:03:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:03:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:03:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:03:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:08:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:08:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:08:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:08:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:08:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:08:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:08:50 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 07:08:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 07:08:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:08:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:08:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:08:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:08:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:08:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:10:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:10:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:10:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:10:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:10:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:10:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:10:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:10:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:10:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:10:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:13:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:13:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:13:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:13:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:13:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:13:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:13:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:13:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:14:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:14:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:14:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:14:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:14:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:14:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:18:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:18:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:18:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:18:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:23:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:23:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:23:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:23:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:23:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:23:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:23:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:23:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:23:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:23:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:23:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:24:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:24:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:24:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:24:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:32 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 07:25:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 07:25:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 07:25:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 07:25:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 07:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 07:25:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:07:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:07:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:32 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 08:07:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 08:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:07:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:07:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:07:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:07:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:07:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:07:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:08:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:08:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:08:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:08:44 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 08:08:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 199
ERROR - 2022-08-25 08:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:08:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:08:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:09:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:09:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:11:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:11:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:13:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:13:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:13:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:13:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:13:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:13:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:22:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:22:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:22:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:26:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:26:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:26:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:26:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:26:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:26:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:26:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:26:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:26:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:27:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:27:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:27:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:29:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:29:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:29:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:29:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:29:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:29:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:29:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:29:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:29:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:29:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:30:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:30:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:30:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:30:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:30:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:30:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:30:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:30:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:30:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:30:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:32:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:32:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:32:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:32:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:32:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:32:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:33:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:33:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:33:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:33:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:33:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:33:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:53:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:53:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:53:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:53:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:53:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:53:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:54:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:54:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:54:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:54:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:54:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:54:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:54:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:54:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:55:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:55:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:55:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:55:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:56:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:56:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:56:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:56:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:56:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:56:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:56:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:56:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 08:56:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 08:56:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 08:56:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 08:56:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:05:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:05:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:05:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:06:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:06:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:06:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:06:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:06:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:06:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:10:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:10:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:10:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:10:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:16:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:16:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:16:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:18 --> Query error: Unknown column 'stock_taking_details' in 'field list' - Invalid query: SELECT SUM(stock_taking_details) as phy_qty
FROM `stock_taking_details`
WHERE `product_id` = 'ABV1234'
AND `create_date` >= '2022-08-25'
AND `create_date` = 1
GROUP BY `stock_taking_details`
ERROR - 2022-08-25 09:16:18 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 413
ERROR - 2022-08-25 09:16:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:16:24 --> Query error: Unknown column 'stock_taking_details' in 'field list' - Invalid query: SELECT SUM(stock_taking_details) as phy_qty
FROM `stock_taking_details`
WHERE `product_id` = 'ABV1234'
AND `create_date` >= '2022-08-25'
AND `create_date` = 1
GROUP BY `stock_taking_details`
ERROR - 2022-08-25 09:16:24 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 413
ERROR - 2022-08-25 09:16:43 --> Query error: Unknown column 'stock_taking_details' in 'field list' - Invalid query: SELECT SUM(stock_taking_details) as phy_qty
FROM `stock_taking_details`
WHERE `product_id` = '1'
AND `create_date` >= '2022-08-25'
AND `create_date` = 1
GROUP BY `stock_taking_details`
ERROR - 2022-08-25 09:16:43 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 413
ERROR - 2022-08-25 09:16:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:16:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:16:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:16:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:16:54 --> Query error: Unknown column 'stock_taking_details' in 'field list' - Invalid query: SELECT SUM(stock_taking_details) as phy_qty
FROM `stock_taking_details`
WHERE `product_id` = 'ABV1234'
AND `create_date` >= '2022-08-25'
AND `create_date` = 1
GROUP BY `stock_taking_details`
ERROR - 2022-08-25 09:17:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:17:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:17:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:17:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:17:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:17:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:17:27 --> Query error: Unknown column 'stock_taking_details' in 'group statement' - Invalid query: SELECT SUM(physical_stock) as phy_qty
FROM `stock_taking_details`
WHERE `product_id` = 'ABV1234'
AND `create_date` >= '2022-08-25'
AND `create_date` = 1
GROUP BY `stock_taking_details`
ERROR - 2022-08-25 09:17:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:17:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-25 09:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:17:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-25 09:17:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-25 09:17:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 78
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 81
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 95
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 98
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 108
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 161
ERROR - 2022-08-25 09:17:53 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 172
ERROR - 2022-08-25 11:21:08 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
