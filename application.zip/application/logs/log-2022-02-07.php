<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-07 05:17:01 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 05:17:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 05:17:01 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 05:17:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 05:17:01 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-07 05:54:47 --> Severity: error --> Exception: Call to undefined method Courier::customer_product_buy() C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 148
ERROR - 2022-02-07 06:07:42 --> Severity: Notice --> Undefined index: customer_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 74
ERROR - 2022-02-07 06:07:42 --> Severity: Notice --> Undefined index: customer_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 74
ERROR - 2022-02-07 06:07:42 --> Severity: Notice --> Undefined index: customer_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 74
ERROR - 2022-02-07 06:09:40 --> Severity: Notice --> Undefined index: name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 74
ERROR - 2022-02-07 06:09:40 --> Severity: Notice --> Undefined index: name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 74
ERROR - 2022-02-07 06:33:36 --> Severity: error --> Exception: Call to undefined method Courier::customer_list_ledger() C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 175
ERROR - 2022-02-07 06:34:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 06:34:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 08:34:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 08:34:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 08:34:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 08:34:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 08:34:44 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-07 08:36:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 197
ERROR - 2022-02-07 08:36:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 210
ERROR - 2022-02-07 13:22:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 13:22:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 13:22:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 13:22:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 13:22:23 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-07 13:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 197
ERROR - 2022-02-07 13:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 210
ERROR - 2022-02-07 13:23:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 197
ERROR - 2022-02-07 13:23:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 210
ERROR - 2022-02-07 13:27:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 210
ERROR - 2022-02-07 13:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 210
ERROR - 2022-02-07 13:32:52 --> Severity: Notice --> Undefined property: stdClass::$customer_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 999
ERROR - 2022-02-07 13:32:52 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1001
ERROR - 2022-02-07 13:32:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3424116928', 'INV', '2022-02-07', NULL, 'Courier debit For Invoice No -  1000 Courier  S.A Paribahan', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-07 13:32:52', 1)
ERROR - 2022-02-07 13:33:06 --> Severity: Notice --> Undefined property: stdClass::$customer_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 999
ERROR - 2022-02-07 13:33:06 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1001
ERROR - 2022-02-07 13:33:06 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4265162811', 'INV', '2022-02-07', NULL, 'Courier debit For Invoice No -  1001 Courier  S.A Paribahan', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-07 13:33:06', 1)
ERROR - 2022-02-07 13:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:33:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-07 13:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:33:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-07 13:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:33:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-07 13:33:17 --> Severity: Notice --> Undefined property: stdClass::$customer_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 999
ERROR - 2022-02-07 13:33:17 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1001
ERROR - 2022-02-07 13:33:17 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4689356946', 'INV', '2022-02-07', NULL, 'Courier debit For Invoice No -  1002 Courier  S.A Paribahan', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-07 13:33:16', 1)
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1513
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-07 13:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-07 13:38:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:38:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-07 13:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:38:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-07 13:38:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-07 13:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:43:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:43:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-07 13:43:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:43:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-07 13:43:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-07 13:43:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-07 13:43:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 13:43:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-07 13:43:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 13:43:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-07 13:43:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-07 13:49:54 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 13:49:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:06:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:06:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:06:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:06:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:07:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:07:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:11:04 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:11:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:13:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:13:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:13:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:13:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:14:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:14:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 183
ERROR - 2022-02-07 14:18:22 --> Severity: Notice --> Undefined variable: courier_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 123
ERROR - 2022-02-07 14:18:45 --> Severity: Notice --> Undefined variable: courier_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 123
ERROR - 2022-02-07 14:20:12 --> Severity: Notice --> Undefined variable: courier_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 123
ERROR - 2022-02-07 14:20:16 --> Severity: Notice --> Undefined variable: courier_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_ledger_report.php 123
ERROR - 2022-02-07 15:42:56 --> Query error: Unknown column 'b.courier_id' in 'on clause' - Invalid query: SELECT `a`.*, `b`.*, `c`.*
FROM `invoice` `a`
LEFT JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
LEFT JOIN `courier_name` `c` ON `c`.`courier_id` = `b`.`courier_id`
WHERE `a`.`status` = 1
ERROR - 2022-02-07 15:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 209
ERROR - 2022-02-07 15:43:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 74
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:15 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:46:44 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_name C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 103
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 104
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_detail_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 105
ERROR - 2022-02-07 15:47:11 --> Severity: Notice --> Undefined index: pr_rqsn_id C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 106
