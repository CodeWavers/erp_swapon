<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-20 04:42:52 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-20 04:42:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-20 04:42:52 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-20 04:42:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-20 04:42:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-20 04:44:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-20 04:45:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-20 06:18:54 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 397
ERROR - 2022-03-20 06:19:08 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 397
ERROR - 2022-03-20 06:40:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-20 06:40:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-20 06:40:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-20 06:40:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-20 06:40:21 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-20 06:41:02 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-20 06:41:02 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 145
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 146
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 147
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 148
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 149
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 150
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-20 06:41:04 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-20 06:41:13 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-20 06:41:13 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 145
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 146
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 147
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 148
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 149
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 150
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-20 06:41:15 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-20 06:41:24 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-20 06:41:24 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 145
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 146
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 147
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 148
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 149
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 150
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-20 06:41:26 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-03-20 06:41:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 06:41:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 06:41:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 06:41:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 06:41:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 06:41:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 06:42:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 06:42:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 06:42:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 06:42:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 06:42:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 06:42:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:08:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:08:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 07:08:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 07:08:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 07:08:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:08:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:13:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:13:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 07:13:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 07:13:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:13:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 07:13:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:14:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:14:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 07:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 07:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:14:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 07:15:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 07:15:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 07:15:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 07:15:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:15:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 07:16:16 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 396
ERROR - 2022-03-20 07:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 396
ERROR - 2022-03-20 08:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 08:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 08:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 08:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 08:07:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 08:07:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 08:33:30 --> Severity: error --> Exception: Call to undefined method Web_settings::current_stock() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 223
ERROR - 2022-03-20 08:34:29 --> Severity: error --> Exception: Call to undefined method Web_settings::current_stock() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 223
ERROR - 2022-03-20 08:37:18 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-20 08:37:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-20 08:37:18 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-20 08:37:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-20 08:41:12 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Purchases.php 370
ERROR - 2022-03-20 08:41:12 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220320084112', 'Purchase', '2022-03-20', NULL, 'Supplier .Factory', 0, '100.00', 1, 'OpSoxJvBbbS8Rws', '2022-03-20', 1)
ERROR - 2022-03-20 08:43:11 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Purchases.php 370
ERROR - 2022-03-20 08:43:11 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220320084311', 'Purchase', '2022-03-20', NULL, 'Supplier .Factory', 0, '100.00', 1, 'OpSoxJvBbbS8Rws', '2022-03-20', 1)
ERROR - 2022-03-20 08:43:54 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-20 08:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-20 08:43:54 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-20 08:43:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-20 08:43:58 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-20 08:43:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-20 08:43:58 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-20 08:43:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-20 09:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:08:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 09:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:08:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 09:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 09:16:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:16:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 09:16:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:16:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 09:16:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 09:16:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:23:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:23:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 09:23:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 09:23:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:23:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 09:23:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:34:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:34:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 09:34:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 09:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 09:34:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 10:18:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 10:18:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 10:18:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 10:18:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 10:18:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 10:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 10:21:50 --> Query error: Column 'total_amount' cannot be null - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `agg_id`, `date`, `total_amount`, `total_tax`, `customer_name_two`, `customer_mobile_two`, `invoice`, `invoice_details`, `invoice_discount`, `total_discount`, `paid_amount`, `due_amount`, `prevous_due`, `shipping_cost`, `condition_cost`, `commission`, `sale_type`, `courier_condtion`, `sales_by`, `status`, `courier_status`) VALUES ('202203201050', NULL, NULL, '2022-03-20', NULL, NULL, NULL, NULL, 1007, '', NULL, NULL, '40409.65', '39409.65', NULL, '200', NULL, NULL, NULL, NULL, 'OpSoxJvBbbS8Rws', 2, 1)
ERROR - 2022-03-20 10:23:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 10:23:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 10:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 10:23:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 10:23:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 10:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:26:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:26:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 11:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:26:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:33:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:33:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:33:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:33:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 11:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:34:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:34:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 11:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:45:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:45:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:45:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:45:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:45:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 11:45:20 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 236
ERROR - 2022-03-20 11:45:20 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 236
ERROR - 2022-03-20 11:45:20 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 236
ERROR - 2022-03-20 11:45:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:45:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:45:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:45:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:45:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 11:45:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:47:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:47:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-20 11:47:21 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 236
ERROR - 2022-03-20 11:47:21 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 236
ERROR - 2022-03-20 11:47:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-20 11:47:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-20 11:47:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-20 11:47:29 --> 404 Page Not Found: Assets/plugins
