<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-24 10:21:49 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-24 10:24:52 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 10:24:52 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 10:24:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:24:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 10:24:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:24:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:24:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 10:24:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 10:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:25:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 10:25:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 10:25:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:25:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 10:25:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:25:09 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 10:25:09 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 10:30:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 10:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:30:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 10:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:30:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 10:31:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:31:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 10:31:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:31:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 10:31:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:31:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 10:31:39 --> Severity: Notice --> Undefined variable: closing_inventory C:\laragon\www\git\erp_swapon\application\models\Reports.php 788
ERROR - 2022-09-24 10:33:24 --> Severity: Notice --> Undefined variable: closing_inventory C:\laragon\www\git\erp_swapon\application\models\Reports.php 788
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: draw C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: length C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: columns C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Undefined index: search C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-09-24 10:33:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-09-24 10:34:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:34:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 10:34:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 10:34:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:34:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 10:34:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: draw C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: length C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: columns C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Undefined index: search C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-09-24 10:34:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-09-24 11:31:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 11:31:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 11:31:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 11:31:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 11:31:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 11:31:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 11:31:46 --> Query error: Unknown column 'rqsn.date' in 'where clause' - Invalid query: SELECT `supplier_price`
FROM `supplier_product`
WHERE `rqsn`.`date` <= ''
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 12:45:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:45:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:45:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:45:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:45:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:45:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:45:04 --> Query error: Unknown column 'rqsn.date' in 'where clause' - Invalid query: SELECT `supplier_price`
FROM `supplier_product`
WHERE `rqsn`.`date` <= ''
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 12:49:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:49:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:49:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:49:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:49:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:49:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:49:04 --> Query error: Unknown column 'rqsn.date' in 'where clause' - Invalid query: SELECT `supplier_price`
FROM `supplier_product`
WHERE `rqsn`.`date` <= ''
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 12:51:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:51:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:51:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:51:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:51:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:51:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:51:08 --> Query error: Unknown column 'rqsn.date' in 'where clause' - Invalid query: SELECT `supplier_price`
FROM `supplier_product`
WHERE `rqsn`.`date` <= ''
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 12:54:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:54:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:54:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:54:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:54:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:54:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:54:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:54:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:56:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:56:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:56:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:56:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:56:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:56:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:58:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:58:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 12:58:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 12:58:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 12:58:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:58:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 12:58:28 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-15'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:01:02 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-15'
AND `product_purchase`.`purchase_date` <= '2022-09-20'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:01:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:01:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:01:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:01:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:01:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:01:55 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-23'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:02:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:02:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:02:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:02:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:02:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:02:07 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-25'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:13:22 --> Query error: Unknown column 'opening_inventory.date' in 'where clause' - Invalid query: SELECT `stock_qty`
FROM `opening_inventory`
WHERE `opening_inventory`.`date` >= '2022-09-08'
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:13:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:13:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:13:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:13:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:13:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:14:05 --> Query error: Unknown column 'opening_inventory.date' in 'where clause' - Invalid query: SELECT `stock_qty`
FROM `opening_inventory`
WHERE `opening_inventory`.`date` >= '2022-09-16'
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:16:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:16:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:16:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:16:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:16:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:16:59 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-14'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:21:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:21:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:21:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:21:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 741
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 764
ERROR - 2022-09-24 13:21:13 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:22:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:22:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:22:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 441
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 660
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 744
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 765
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 767
ERROR - 2022-09-24 13:22:14 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 768
ERROR - 2022-09-24 13:22:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:22:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:22:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:22:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:22:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:22:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:23:00 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-08'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 760
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 762
ERROR - 2022-09-24 13:24:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 763
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:32:29 --> Severity: Notice --> Undefined variable: opening_stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 533
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:37 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:33:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:33:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:33:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:33:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:33:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:33:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:33:50 --> Severity: Notice --> Undefined variable: from_date C:\laragon\www\git\erp_swapon\application\models\Reports.php 526
ERROR - 2022-09-24 13:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:34:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:34:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:37:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:37:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:37:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:38:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:38:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:38:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:39:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:39:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:39:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:39:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:39:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:39:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:40:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:40:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:40:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:43:43 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-02'
AND `status` = 2
AND `product_id` = '1532S'
ERROR - 2022-09-24 13:43:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:43:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:43:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:43:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:43:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:43:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:44:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:44:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:44:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:44:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:44:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:47:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:47:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:47:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:47:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:47:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:47:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:49:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:49:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:49:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:50:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:50:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:50:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:50:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:50:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:50:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:51:08 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-09'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 13:51:08 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 463
ERROR - 2022-09-24 13:52:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:52:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:52:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:52:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:53:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:53:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:55:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:55:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:55:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:55:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:57:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 13:57:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 13:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 13:57:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 13:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:01:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:01:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:01:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:01:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:01:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:01:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:11 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 14:04:11 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 14:04:15 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 14:04:15 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 14:04:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:04:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:04:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:04:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 657
ERROR - 2022-09-24 14:04:27 --> Severity: Notice --> Undefined variable: stock C:\laragon\www\git\erp_swapon\application\models\Reports.php 737
ERROR - 2022-09-24 14:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:05:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:05:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:05:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:05:24 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-22'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:07:24 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\laragon\www\git\erp_swapon\application\models\Reports.php 598
ERROR - 2022-09-24 14:07:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:07:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:07:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:07:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:07:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:07:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:07:37 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-09'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:07:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:07:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:07:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:07:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:07:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:07:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:07:59 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-15'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:10:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:10:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:10:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:10:59 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-14'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:10:59 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 466
ERROR - 2022-09-24 14:11:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:11:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:11:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:11:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:11:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:11:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:23 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-16'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:11:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:11:43 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-16'
AND `product_purchase`.`purchase_date` <= '2022-09-20'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:12:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:12:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:12:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:12:50 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-25'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:15:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:15:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:15:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:15:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:15:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:15:03 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-08'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:15:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:15:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:15:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:15:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:15:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:15:30 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-30'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:16:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:16:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:16:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:16:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:16:45 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-09'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: draw C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: length C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: columns C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: order C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Undefined index: search C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-09-24 14:16:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-09-24 14:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:18:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:18:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:18:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:18:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3164
ERROR - 2022-09-24 14:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3164
ERROR - 2022-09-24 14:18:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3231
ERROR - 2022-09-24 14:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3231
ERROR - 2022-09-24 14:18:46 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-24 14:19:04 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-09'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:19:12 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-22'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:19:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:19:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:19:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:19:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:19:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:19:28 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-21'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:23:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:23:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:23:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:23:31 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-16'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:26:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:26:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:26:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:26:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:26:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:26:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:26:49 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-17'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:26:52 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-17'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:30:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:30:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:30:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:30:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:30:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:30:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:30:51 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-06'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:31:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:31:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:31:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:31:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:31:31 --> Query error: Unknown column 'product_purchase.purchase_date' in 'where clause' - Invalid query: SELECT sum(qty) as totalPurchaseQnty, sum(damaged_qty) as damaged_qty, Avg(rate) as purchaseprice
FROM `product_purchase_details`
WHERE `product_purchase`.`purchase_date` >= '2022-09-09'
AND `status` = 2
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:33:19 --> Query error: Unknown column 'opening_inventory.date' in 'where clause' - Invalid query: SELECT `stock_qty`
FROM `opening_inventory`
WHERE `opening_inventory`.`date` >= '2022-09-09'
AND `product_id` = '1'
ERROR - 2022-09-24 14:33:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:33:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:33:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:33:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:33:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:33:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:33:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:35 --> Query error: Unknown column 'opening_inventory.date' in 'where clause' - Invalid query: SELECT `stock_qty`
FROM `opening_inventory`
WHERE `opening_inventory`.`date` >= '2022-09-07'
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:33:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:33:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:33:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:33:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:33:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:33:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:33:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:33:49 --> Query error: Unknown column 'opening_inventory.date' in 'where clause' - Invalid query: SELECT `stock_qty`
FROM `opening_inventory`
WHERE `opening_inventory`.`date` >= '2022-09-25'
AND `product_id` = 'ABV1234'
ERROR - 2022-09-24 14:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:36:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:36:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:36:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:36:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:36:23 --> Query error: Unknown column 'production.date' in 'where clause' - Invalid query: SELECT SUM(quantity) as pro_qty
FROM `production_goods`
WHERE `production`.`date` >= '2022-09-07'
AND `product_id` = 'ABV1234'
GROUP BY `product_id`
ERROR - 2022-09-24 14:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:38:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:38:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:38:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:38:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:38:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:38:21 --> Query error: Unknown column 'production.date' in 'where clause' - Invalid query: SELECT SUM(usage_qty) as used_qty
FROM `item_usage`
WHERE `production`.`date` >= '2022-09-15'
AND `item_id` = 'ABV1234'
GROUP BY `item_id`
ERROR - 2022-09-24 14:39:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:39:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:39:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:39:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:39:15 --> Query error: Unknown column 'production_goods.pro_id' in 'on clause' - Invalid query: SELECT SUM(usage_qty) as used_qty
FROM `item_usage`
LEFT JOIN `production` ON `production_goods`.`pro_id`=`production`.`pro_id`
WHERE `item_usage`.`item_id` = 'ABV1234'
GROUP BY `item_usage`.`item_id`
ERROR - 2022-09-24 14:40:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:40:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:40:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:40:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:40:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:40:19 --> Query error: Unknown column 'production.item_usage' in 'on clause' - Invalid query: SELECT SUM(usage_qty) as used_qty
FROM `item_usage`
LEFT JOIN `production` ON `item_usage`.`production_id`=`production`.`item_usage`
WHERE `item_usage`.`item_id` = 'ABV1234'
GROUP BY `item_usage`.`item_id`
ERROR - 2022-09-24 14:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:40:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:40:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:40:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:40:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:44:54 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 216
ERROR - 2022-09-24 14:44:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 216
ERROR - 2022-09-24 14:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:45:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 14:45:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 14:45:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 14:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 14:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:31:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:31:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 15:31:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:31:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 15:31:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:31:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 15:33:41 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 401
ERROR - 2022-09-24 15:33:41 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 401
ERROR - 2022-09-24 15:33:41 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 403
ERROR - 2022-09-24 15:33:41 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 403
ERROR - 2022-09-24 15:33:53 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 335
ERROR - 2022-09-24 15:52:58 --> Query error: Unknown column 'stock_taking.date' in 'where clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stid` = `a`.`stid`
WHERE `stock_taking`.`date` >= '2022-09-25'
AND `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = 'ABV1234'
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-24 15:52:58 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 589
ERROR - 2022-09-24 15:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 15:53:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 15:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 15:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 15:53:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 15:53:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 15:53:09 --> Query error: Unknown column 'stock_taking.date' in 'where clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stid` = `a`.`stid`
WHERE `stock_taking`.`date` >= '2022-09-21'
AND `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = 'ABV1234'
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-24 15:53:09 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 589
ERROR - 2022-09-24 15:53:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 15:53:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 15:53:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 15:53:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:53:27 --> Query error: Unknown column 'stock_taking.date' in 'where clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stid` = `a`.`stid`
WHERE `stock_taking`.`date` >= '2022-09-25'
AND `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = 'ABV1234'
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-24 15:54:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:54:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 15:54:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 15:54:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:54:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 15:54:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:54:54 --> Query error: Unknown column 'stock_taking.date' in 'where clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stid` = `a`.`stid`
WHERE `stock_taking`.`date` >= '2022-09-22'
AND `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = 'ABV1234'
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-24 15:56:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:56:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 15:56:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 15:56:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:56:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 15:56:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:07:36 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-24 16:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-24 16:07:36 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-24 16:07:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-24 16:07:59 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 401
ERROR - 2022-09-24 16:07:59 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 401
ERROR - 2022-09-24 16:07:59 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 403
ERROR - 2022-09-24 16:07:59 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 403
ERROR - 2022-09-24 16:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-24 16:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-24 16:22:08 --> Query error: Unknown column 'a.date' in 'where clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stid` = `a`.`stid`
WHERE `a`.`date` <= '2022-09-24'
AND `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = 'ABV1234'
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-24 16:22:08 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 824
ERROR - 2022-09-24 16:53:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:53:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 16:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:53:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 16:53:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:53:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-24 16:53:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:53:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 16:53:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:53:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:53:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 16:53:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 16:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 16:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 16:55:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 16:55:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:55:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 16:55:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:55:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 16:55:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 16:55:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 16:55:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 16:55:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 16:55:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:07:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:07:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:07:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:07:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:07:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:07:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:08:37 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1935
ERROR - 2022-09-24 17:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:09:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:09:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:09:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:09:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:09:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:09:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:09:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:09:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:09:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:10:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:10:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:10:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:10:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:11:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:11:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:11:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:11:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:15:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:15:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:15:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:15:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:15:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:15:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:16:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:16:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:16:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:16:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:16:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:16:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:18:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:18:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-24 17:18:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:18:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-24 17:18:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-24 17:18:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-24 17:18:37 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 401
ERROR - 2022-09-24 17:18:37 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 401
ERROR - 2022-09-24 17:18:37 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 403
ERROR - 2022-09-24 17:18:37 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 403
ERROR - 2022-09-24 17:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve.php 74
ERROR - 2022-09-24 17:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-24 17:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
