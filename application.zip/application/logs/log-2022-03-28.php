<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-28 04:35:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2661
ERROR - 2022-03-28 04:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2661
ERROR - 2022-03-28 04:35:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2728
ERROR - 2022-03-28 04:35:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2728
ERROR - 2022-03-28 04:35:32 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-28 04:44:28 --> 404 Page Not Found: Admin_dashboard/product_purchase_reports_date_wise
ERROR - 2022-03-28 04:45:06 --> Severity: error --> Exception: Too few arguments to function reports::retrieve_product_purchase_report(), 0 passed in C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php on line 1390 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 1622
ERROR - 2022-03-28 04:45:09 --> Severity: error --> Exception: Too few arguments to function reports::retrieve_product_purchase_report(), 0 passed in C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php on line 1390 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 1622
ERROR - 2022-03-28 04:48:44 --> Severity: error --> Exception: Too few arguments to function reports::retrieve_product_purchase_report(), 0 passed in C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php on line 1390 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 1622
ERROR - 2022-03-28 04:51:34 --> Severity: error --> Exception: Too few arguments to function reports::retrieve_product_purchase_report(), 0 passed in C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php on line 1390 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 1622
ERROR - 2022-03-28 04:52:12 --> Severity: error --> Exception: Too few arguments to function reports::retrieve_product_purchase_report(), 0 passed in C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php on line 1390 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 1622
ERROR - 2022-03-28 04:52:14 --> Severity: error --> Exception: Too few arguments to function reports::retrieve_product_purchase_report(), 0 passed in C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php on line 1390 and exactly 2 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 1622
ERROR - 2022-03-28 05:11:50 --> Query error: Unknown column 'c.invoice' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`invoice`, `c`.`date`, `d`.`customer_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `product_purchase_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `product_purchase` `c` ON `c`.`purchase_id` = `a`.`purchase_id`
LEFT JOIN `customer_information` `d` ON `d`.`customer_id` = `c`.`customer_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`date` >= '2022-03-01'
AND `c`.`date` <= '2022-03-28'
ORDER BY `c`.`date` DESC
ERROR - 2022-03-28 05:12:17 --> Query error: Unknown column 'c.date' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`purchase_id`, `c`.`date`, `d`.`customer_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `product_purchase_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `product_purchase` `c` ON `c`.`purchase_id` = `a`.`purchase_id`
LEFT JOIN `customer_information` `d` ON `d`.`customer_id` = `c`.`customer_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`date` >= '2022-03-01'
AND `c`.`date` <= '2022-03-28'
ORDER BY `c`.`date` DESC
ERROR - 2022-03-28 05:14:27 --> Query error: Unknown column 'c.date' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`purchase_id`, `c`.`purchase_date` as `date`, `d`.`customer_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `product_purchase_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `product_purchase` `c` ON `c`.`purchase_id` = `a`.`purchase_id`
LEFT JOIN `customer_information` `d` ON `d`.`customer_id` = `c`.`customer_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`date` >= '2022-03-01'
AND `c`.`date` <= '2022-03-28'
ORDER BY `c`.`date` DESC
ERROR - 2022-03-28 05:14:51 --> Query error: Unknown column 'c.customer_id' in 'on clause' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`purchase_id`, `c`.`purchase_date` as `date`, `d`.`customer_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `product_purchase_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `product_purchase` `c` ON `c`.`purchase_id` = `a`.`purchase_id`
LEFT JOIN `customer_information` `d` ON `d`.`customer_id` = `c`.`customer_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`purchase_date` >= '2022-03-01'
AND `c`.`purchase_date` <= '2022-03-28'
ORDER BY `c`.`purchase_date` DESC
ERROR - 2022-03-28 05:15:29 --> Query error: Unknown column 'd.supplier_nmae' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`purchase_id`, `c`.`purchase_date` as `date`, `d`.`supplier_nmae`, `sz`.`size_name`, `cl`.`color_name`
FROM `product_purchase_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `product_purchase` `c` ON `c`.`purchase_id` = `a`.`purchase_id`
LEFT JOIN `supplier_information` `d` ON `d`.`supplier_id` = `c`.`supplier_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`purchase_date` >= '2022-03-01'
AND `c`.`purchase_date` <= '2022-03-28'
ORDER BY `c`.`purchase_date` DESC
ERROR - 2022-03-28 05:15:41 --> Severity: Notice --> Undefined index: total_price C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1803
ERROR - 2022-03-28 05:17:07 --> Severity: Notice --> Undefined index: date C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1802
ERROR - 2022-03-28 05:17:07 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 5
ERROR - 2022-03-28 05:17:07 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 5
ERROR - 2022-03-28 05:17:07 --> Severity: Notice --> Undefined index: total_price C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1803
ERROR - 2022-03-28 05:17:19 --> Severity: Notice --> Undefined index: date C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1802
ERROR - 2022-03-28 05:17:19 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 5
ERROR - 2022-03-28 05:17:19 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 5
ERROR - 2022-03-28 05:17:19 --> Severity: Notice --> Undefined index: total_price C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1803
ERROR - 2022-03-28 05:42:00 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 202
ERROR - 2022-03-28 05:43:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Production.php 914
ERROR - 2022-03-28 05:43:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 975
ERROR - 2022-03-28 06:00:10 --> Query error: Unknown column 'c.purchase_id' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`purchase_id`, `c`.`date`, `d`.`supplier_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `production_goods` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `production` `c` ON `c`.`pro_id` = `a`.`pro_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`purchase_date` >= '2022-03-28'
AND `c`.`purchase_date` <= '2022-03-28'
ORDER BY `c`.`purchase_date` DESC
ERROR - 2022-03-28 06:01:02 --> Query error: Unknown column 'c.production_id' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`production_id`, `c`.`base_number`, `c`.`date`, `d`.`supplier_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `production_goods` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `production` `c` ON `c`.`pro_id` = `a`.`pro_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`date` >= '2022-03-28'
AND `c`.`date` <= '2022-03-28'
ORDER BY `c`.`purchase_date` DESC
ERROR - 2022-03-28 06:01:14 --> Query error: Unknown column 'd.supplier_name' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`pro_id`, `c`.`base_number`, `c`.`date`, `d`.`supplier_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `production_goods` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `production` `c` ON `c`.`pro_id` = `a`.`pro_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`date` >= '2022-03-28'
AND `c`.`date` <= '2022-03-28'
ORDER BY `c`.`purchase_date` DESC
ERROR - 2022-03-28 06:01:26 --> Query error: Unknown column 'c.purchase_date' in 'order clause' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `c`.`pro_id`, `c`.`base_number`, `c`.`date`, `sz`.`size_name`, `cl`.`color_name`
FROM `production_goods` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `production` `c` ON `c`.`pro_id` = `a`.`pro_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `c`.`date` >= '2022-03-28'
AND `c`.`date` <= '2022-03-28'
ORDER BY `c`.`purchase_date` DESC
ERROR - 2022-03-28 06:11:04 --> Severity: Notice --> Undefined variable: order C:\laragon\www\git\erp_swapon\application\views\order\order_table.php 99
ERROR - 2022-03-28 06:11:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_table.php 99
ERROR - 2022-03-28 06:11:04 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_table.php 99
ERROR - 2022-03-28 06:11:04 --> Severity: Notice --> Undefined variable: order C:\laragon\www\git\erp_swapon\application\views\order\order_table.php 99
ERROR - 2022-03-28 06:11:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_table.php 99
ERROR - 2022-03-28 06:11:04 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_table.php 99
ERROR - 2022-03-28 06:22:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:22:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:22:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:22:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:22:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:22:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:23:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:23:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:23:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:23:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:23:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:23:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 06:23:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 343
ERROR - 2022-03-28 06:26:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-03-28 06:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 344
ERROR - 2022-03-28 06:34:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:34:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:34:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:34:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:34:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:37:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-03-28 06:37:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 344
ERROR - 2022-03-28 06:41:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:41:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:41:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:41:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:41:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:42:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:42:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:42:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:42:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:42:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-03-28 06:42:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 344
ERROR - 2022-03-28 06:44:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:44:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:44:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:44:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:44:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:44:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:46:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:46:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:46:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:46:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:47:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 06:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 06:47:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:47:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:47:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:47:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:47:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:47:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:48:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 06:48:05 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 403
ERROR - 2022-03-28 06:48:05 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 404
ERROR - 2022-03-28 06:49:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:49:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:49:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:49:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:49:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:49:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:49:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 06:49:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 06:54:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:54:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:54:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:54:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:54:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 06:54:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 06:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 06:55:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 06:55:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:55:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 06:55:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 06:56:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 06:56:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:08:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:09:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:09:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:09:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:09:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:09:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:09:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:09:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:09:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:09:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:14:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:14:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:14:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:14:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 07:15:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 07:15:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:15:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 07:15:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:16:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:16:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 07:16:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 07:16:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:16:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:16:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 07:17:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:18:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:18:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 07:18:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 07:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:18:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 07:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 07:19:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:23:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:23:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 07:24:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 07:24:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 08:19:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 08:19:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 08:20:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:20:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 08:20:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 08:20:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:20:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:20:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 08:20:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 08:21:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 345
ERROR - 2022-03-28 08:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:22:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 08:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:22:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 08:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:22:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 08:22:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 291
ERROR - 2022-03-28 08:22:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 351
ERROR - 2022-03-28 08:26:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 291
ERROR - 2022-03-28 08:26:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 351
ERROR - 2022-03-28 08:28:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 303
ERROR - 2022-03-28 08:28:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 366
ERROR - 2022-03-28 08:28:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 08:29:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 08:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:29:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 08:29:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 08:51:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:51:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 08:51:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 08:51:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:52:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:52:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 08:52:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 08:52:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:52:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 08:52:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 08:53:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 285
ERROR - 2022-03-28 08:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 366
ERROR - 2022-03-28 08:56:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 303
ERROR - 2022-03-28 08:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 366
ERROR - 2022-03-28 09:11:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 09:11:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:11:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 09:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 09:11:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:12:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-03-28 09:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:12:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:14:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:14:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:15:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:15:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:18:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:18:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:18:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:18:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 09:18:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 09:18:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:18:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:18:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 09:19:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:22:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:23:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:24:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:24:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:31:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:31:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 09:31:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 09:31:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 09:31:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:31:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:31:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:31:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:32:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:32:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 09:32:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:32:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 09:32:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 09:32:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:33:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:33:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:35:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:35:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:35:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:35:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:35:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:42:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:42:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:42:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 09:42:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 09:42:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:42:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:42:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 09:44:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 283
ERROR - 2022-03-28 09:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 364
ERROR - 2022-03-28 09:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:57:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 09:57:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 09:57:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:57:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 09:57:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 09:58:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 280
ERROR - 2022-03-28 09:58:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-03-28 10:04:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 280
ERROR - 2022-03-28 10:04:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-03-28 10:04:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 280
ERROR - 2022-03-28 10:04:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-03-28 10:04:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 280
ERROR - 2022-03-28 10:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-03-28 10:04:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 10:04:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 10:04:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 10:04:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 10:04:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 10:04:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 10:05:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Order.php 280
ERROR - 2022-03-28 10:05:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-03-28 10:06:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 10:06:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 10:06:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 10:06:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 10:06:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 10:06:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 10:06:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-03-28 10:06:56 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 417
ERROR - 2022-03-28 10:06:56 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 418
ERROR - 2022-03-28 11:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 11:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:15:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 11:15:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 11:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:15:47 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 417
ERROR - 2022-03-28 11:15:47 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 418
ERROR - 2022-03-28 11:16:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:16:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 11:16:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 11:16:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:16:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 11:16:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:16:41 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 417
ERROR - 2022-03-28 11:16:41 --> Severity: Notice --> Undefined variable: total_product C:\laragon\www\git\erp_swapon\application\models\Order.php 418
ERROR - 2022-03-28 11:17:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:17:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-28 11:18:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-28 11:18:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:18:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-28 11:18:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-28 11:50:08 --> Severity: Notice --> Undefined property: stdClass::$y_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 104
