<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-28 04:37:57 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-28 06:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 83
ERROR - 2022-08-28 09:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 83
