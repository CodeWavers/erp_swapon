<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-23 04:58:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-23 04:58:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-23 04:58:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-23 04:58:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-23 04:58:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-23 06:06:35 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-02-23 06:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 293
ERROR - 2022-02-23 06:07:05 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-02-23 06:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 293
ERROR - 2022-02-23 06:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:29:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:29:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:29:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:29:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:30:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:30:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:30:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:30:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:31:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:31:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:31:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:31:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:31:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:31:29 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-02-23 06:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 293
ERROR - 2022-02-23 06:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:32:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:32:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:32:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:32:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:33:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:33:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:33:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:33:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:33:26 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 284
ERROR - 2022-02-23 06:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 293
ERROR - 2022-02-23 06:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:34:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:34:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:34:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:34:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$thumbnail_image C:\laragon\www\git\erp_swapon\application\models\Order.php 301
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 302
ERROR - 2022-02-23 06:34:27 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:35:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:35:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:35:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:35:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:35:45 --> Severity: Notice --> Undefined property: stdClass::$refund C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 06:36:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:36:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:36:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:36:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:41:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:41:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:41:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:41:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:41:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:41:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:44:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:44:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:44:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:44:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:44:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:44:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:48:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:48:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:48:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:55:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 06:55:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 06:55:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:55:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 06:55:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Order.php 309
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$phone C:\laragon\www\git\erp_swapon\application\models\Order.php 310
ERROR - 2022-02-23 06:55:48 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 312
ERROR - 2022-02-23 07:00:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:00:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:01:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:01:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:01:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:01:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:01:06 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:08:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:08:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:08:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:09:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:09:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:10:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:10:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:10:09 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 314
ERROR - 2022-02-23 07:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:12:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:12:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:12:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:12:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:18:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:19:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:19:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:19:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:19:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:20:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:20:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:21:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:21:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:24:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-23 07:24:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-23 07:24:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-23 07:24:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-23 07:24:00 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-23 07:26:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:27:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:27:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:04 --> Severity: Notice --> Undefined property: stdClass::$delivery_status C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-02-23 07:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:27:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:27:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:27:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:28:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:28:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:28:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:28:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:40:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:40:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:40:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:40:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:48:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:48:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:48:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:48:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:24 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\git\erp_swapon\application\models\Order.php 306
ERROR - 2022-02-23 07:48:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:48:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:49:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:49:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:49:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:49:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:49:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:49:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:49:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:49:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:50:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:50:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:22 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\git\erp_swapon\application\models\Order.php 319
ERROR - 2022-02-23 07:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:50:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:50:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:50:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:54:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:54:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:54:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:54:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:55:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:55:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:55:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:55:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:55:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:57:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:57:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 07:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 07:57:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 07:57:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 07:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 08:02:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 08:02:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 08:02:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 08:02:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 08:02:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 08:02:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:00:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:00:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 09:00:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 09:00:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:00:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:00:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:00:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 09:00:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 09:00:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:00:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:00:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:22:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:22:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 09:22:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:22:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:22:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 09:22:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:29:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:29:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 09:29:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:29:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 09:29:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:29:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:35:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:35:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 09:36:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 09:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:36:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:58:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:58:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 09:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 09:58:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 09:58:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:07:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-23 10:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-23 10:07:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-23 10:07:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-23 10:07:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:07:38 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:07:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:07:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:08:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:08:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:08:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:08:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:08:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:08:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-02-23 10:08:20 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:08:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:08:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:09:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:09:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:14 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:09:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:09:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:09:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:09:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:09:45 --> Severity: Notice --> Undefined variable: ad C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:10:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:10:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:10:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:10:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:10:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:11:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:11:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:11:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:11:43 --> Severity: Notice --> Trying to get property 'activated' of non-object C:\laragon\www\git\erp_swapon\application\models\Order.php 341
ERROR - 2022-02-23 10:15:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:15:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:15:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:15:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:15:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:15:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:16:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:16:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:16:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:16:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:17:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:17:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:18:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:18:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:18:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:18:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:18:01 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-02-23 10:20:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:20:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:20:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 10:20:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:20:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:20:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:20:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-02-23 10:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:54:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 10:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 10:54:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 10:54:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:17:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:17:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:17:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:17:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:17:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:17:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:38:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:38:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:39:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:39:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:39:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:39:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:39:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:39:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:40:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:40:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:40:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:40:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:40:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:40:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:40:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:40:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:40:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:42:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:42:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:42:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:42:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:42:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:46:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:46:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:46:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:46:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:46:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:46:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:49:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:49:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-23 11:49:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-23 11:49:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-23 11:49:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-23 11:49:35 --> 404 Page Not Found: Assets/js
