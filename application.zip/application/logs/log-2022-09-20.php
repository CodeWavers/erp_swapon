<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-20 10:48:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-20 10:53:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-20 10:53:49 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '487244755683366', NULL, '9475345555', '16945P', '119', '10', '10', '2022-09-19', '2022-09-20', '1000.00', '', '1000.00', 0, '10000', NULL, '', 1)
ERROR - 2022-09-20 10:54:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-20 10:55:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-20 11:05:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-20 11:05:44 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '882766225451948', NULL, '9549512273', '16945P', '119', '10', '20', '2022-09-19', '2022-09-20', '1000.00', '', '1000.00', 0, '10000', NULL, '', 1)
ERROR - 2022-09-20 11:11:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:11:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:12:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:12:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:12:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:12:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:12:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:12:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:13:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:13:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:13:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:13:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:13:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:13:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:13:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:13:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:14:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:14:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 216
ERROR - 2022-09-20 11:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 75
ERROR - 2022-09-20 11:16:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:16:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 11:16:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 11:16:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 11:16:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 11:16:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 12:40:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-09-20 12:40:29 --> The upload path does not appear to be valid.
ERROR - 2022-09-20 13:09:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 13:09:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:09:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 13:09:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:09:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:09:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 13:10:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 13:10:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 13:10:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:10:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:10:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 13:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 13:10:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 13:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:10:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 13:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 13:13:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 13:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:13:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 13:13:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:16:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:16:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:16:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:16:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:16:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:19:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:19:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:19:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:19:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:19:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:19:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:21:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:21:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:21:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:21:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:21:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:21:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:22:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:22:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:22:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:22:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:22:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:22:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:23:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:23:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:23:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:23:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:23:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:25:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:25:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:25:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:25:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:25:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:25:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:26:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:26:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:26:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:26:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:26:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:26:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:26:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:26:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:26:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:26:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:27:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 14:27:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 14:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 14:27:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 14:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:15:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 15:15:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 15:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 15:23:58 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `rqsn` (`rqsn_id`, `date`, `details`, `from_id`, `to_id`, `user_id`, `status`) VALUES (1598133326, '2022-09-20', 'Requisition', 'VC4C6BTBRLL57PF', 'HK7TGDT69VFMXB7', 'OpSoxJvBbbS8Rws', 1)
ERROR - 2022-09-20 15:33:19 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-20 15:35:04 --> Severity: Compile Error --> Cannot use empty array elements in arrays C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 266
ERROR - 2022-09-20 15:35:10 --> Severity: Compile Error --> Cannot use empty array elements in arrays C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 266
ERROR - 2022-09-20 15:36:13 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `rqsn` (`rqsn_id`, `date`, `details`, `from_id`, `to_id`, `user_id`, `status`) VALUES (1952461748, '2022-09-20', 'Requisition', 'JBK6ZR8HF99SUSB', 'HK7TGDT69VFMXB7', 'OpSoxJvBbbS8Rws', 1)
ERROR - 2022-09-20 15:37:49 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-20 15:38:56 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-20 15:39:10 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-20 15:39:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-20 15:44:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve.php 74
ERROR - 2022-09-20 15:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:51:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 15:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:51:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 15:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 15:51:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:51:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 15:51:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 15:51:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:51:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 15:51:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 16:02:36 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `rqsn` (`rqsn_id`, `date`, `details`, `from_id`, `to_id`, `user_id`, `status`) VALUES (552180134, '2022-09-20', 'Transfer', 'E848KA1E4G9UO2G', 'HK7TGDT69VFMXB7', 'OpSoxJvBbbS8Rws', 1)
ERROR - 2022-09-20 16:04:49 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `rqsn` (`rqsn_id`, `date`, `details`, `from_id`, `to_id`, `user_id`, `status`) VALUES (1059015861, '2022-09-20', 'Transfer', 'E848KA1E4G9UO2G', 'HK7TGDT69VFMXB7', 'OpSoxJvBbbS8Rws', 1)
ERROR - 2022-09-20 16:16:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1512
ERROR - 2022-09-20 16:16:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1512
ERROR - 2022-09-20 16:16:16 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1746
ERROR - 2022-09-20 16:20:06 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `rqsn` (`rqsn_id`, `date`, `details`, `from_id`, `to_id`, `user_id`, `status`) VALUES (456392861, '2022-09-20', 'Transfer', 'E848KA1E4G9UO2G', 'HK7TGDT69VFMXB7', 'OpSoxJvBbbS8Rws', 1)
ERROR - 2022-09-20 16:21:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1513
ERROR - 2022-09-20 16:21:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1513
ERROR - 2022-09-20 16:21:48 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1747
ERROR - 2022-09-20 16:22:06 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1513
ERROR - 2022-09-20 16:22:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1513
ERROR - 2022-09-20 16:22:06 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1747
ERROR - 2022-09-20 16:22:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1513
ERROR - 2022-09-20 16:22:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1513
ERROR - 2022-09-20 16:22:15 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1747
ERROR - 2022-09-20 16:23:11 --> Severity: Notice --> Trying to get property 'outlet_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1370
ERROR - 2022-09-20 16:23:11 --> Severity: Notice --> Trying to get property 'outlet_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1370
ERROR - 2022-09-20 16:43:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 16:43:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 16:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:43:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:43:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 16:44:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 16:44:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 16:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:44:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 16:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:45:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 16:45:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 16:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:45:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 16:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:45:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 16:45:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 16:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 16:45:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 16:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-20 17:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-20 17:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-20 17:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:27:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:27:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:27:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:30:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:30:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:30:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:30:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:30:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:30:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:31:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:31:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:31:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:31:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:31:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:31:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:31:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:31:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:32:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:32:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:32:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:32:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:32:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:32:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:34:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:34:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:34:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:34:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:34:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:34:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:35:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:35:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:35:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:35:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:35:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:35:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:35:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:35:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:37:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:37:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:37:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:37:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:37:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-20 17:37:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:39:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-20 17:39:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:39:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-20 17:39:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-20 17:39:26 --> 404 Page Not Found: Assets/plugins
