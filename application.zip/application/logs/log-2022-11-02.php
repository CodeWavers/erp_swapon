<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-02 11:04:47 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-02 11:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-02 11:08:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:10:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:10:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-02 11:11:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-02 11:11:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:12:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:13:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-02 11:13:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:13:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-02 11:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-02 11:13:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-02 11:13:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-02 11:13:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-02 11:14:42 --> The upload path does not appear to be valid.
ERROR - 2022-11-02 11:14:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-02 11:28:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
