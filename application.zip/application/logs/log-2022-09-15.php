<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-15 10:54:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-15 10:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-15 10:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-15 11:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-15 11:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-15 11:15:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-09-15 11:15:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-09-15 11:26:57 --> The upload path does not appear to be valid.
ERROR - 2022-09-15 11:32:11 --> The upload path does not appear to be valid.
ERROR - 2022-09-15 11:32:11 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8486873622', 'INV-CC', '2022-09-15', NULL, 'Delivery Charge For Invoice No -  1001 Courier  ', '0.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-15 11:32:11', 1)
ERROR - 2022-09-15 11:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-09-15 11:39:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-09-15 11:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-09-15 11:43:34 --> The upload path does not appear to be valid.
ERROR - 2022-09-15 11:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-09-15 11:52:20 --> The upload path does not appear to be valid.
ERROR - 2022-09-15 12:06:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 253
ERROR - 2022-09-15 12:07:42 --> The upload path does not appear to be valid.
ERROR - 2022-09-15 12:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:17:23 --> The upload path does not appear to be valid.
ERROR - 2022-09-15 12:17:23 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1011
ERROR - 2022-09-15 12:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:39:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:39:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 12:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:39:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 12:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:40:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 12:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:42:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:42:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 12:42:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:42:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 12:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 12:42:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:47:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:47:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:47:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 12:47:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 12:47:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 12:47:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 12:53:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 12:53:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 13:20:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 355
ERROR - 2022-09-15 13:20:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 76
ERROR - 2022-09-15 13:22:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 355
ERROR - 2022-09-15 13:22:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 76
ERROR - 2022-09-15 15:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 15:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:16:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 15:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:16:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 15:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 15:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 15:32:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 15:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:32:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 15:32:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 15:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:35:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:35:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 15:35:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:35:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 15:35:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:35:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 15:35:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:35:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 15:35:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 15:35:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 15:35:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 15:35:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 16:20:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 16:26:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 16:27:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 16:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 16:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 16:29:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-15 16:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 16:29:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-15 16:29:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-15 16:29:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-15 17:13:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
ERROR - 2022-09-15 17:24:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 717
