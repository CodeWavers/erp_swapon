<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-03 05:23:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-03 05:23:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-03 05:23:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-03 05:23:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-03 05:23:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
