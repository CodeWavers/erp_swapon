<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-19 04:31:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2820
ERROR - 2022-07-19 04:31:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2820
ERROR - 2022-07-19 04:31:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2887
ERROR - 2022-07-19 04:31:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2887
ERROR - 2022-07-19 04:31:30 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 04:32:00 --> Severity: Notice --> Undefined variable: courier_status C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 144
ERROR - 2022-07-19 04:32:00 --> Severity: Notice --> Undefined variable: courier_status C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 144
ERROR - 2022-07-19 04:32:00 --> Severity: Notice --> Undefined variable: courier_status C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 144
ERROR - 2022-07-19 05:05:54 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 05:06:44 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 05:21:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:21:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:21:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 05:21:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 05:21:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:21:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 05:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:21:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 05:21:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 05:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:21:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 05:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:29:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 05:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:29:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 05:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 05:29:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:32:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:32:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 05:32:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 05:32:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:32:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 05:32:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 05:34:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 08:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:48:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:48:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:49:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:49:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:49:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:49:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:49:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:49:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:49:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:49:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:49:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:49:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:49:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:09 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 08:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:50:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:50:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:50:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:50:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:50:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:50:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:50:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:50:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:50:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:52:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 08:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:52:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:52:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:52:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:49 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 08:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:52:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:52:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 08:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 08:53:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 08:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 08:53:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:20:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-07-19 09:20:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-07-19 09:20:54 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220719092054', 'Purchase', '2022-07-19', NULL, 'Supplier .Factory', 0, '50000.00', 1, 'nDcIfeGpQbtUSrj', '2022-07-19', 1)
ERROR - 2022-07-19 09:20:54 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220719092054', 'Purchase', '2022-07-19', NULL, 'Supplier .Factory (cash in hand) for Purchase Id - 20220719092054', '50000.00', 0, 1, 'nDcIfeGpQbtUSrj', '2022-07-19', 1)
ERROR - 2022-07-19 09:21:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:21:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:21:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:21:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:21:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:21:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:26:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:26:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:26:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:26:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:26:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:32:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:32:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:32:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:32:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:32:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:32:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:35:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:35:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:35:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:35:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:35:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:35:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:35:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:35:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:35:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:35:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:35:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:35:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:36:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:36:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:36:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:36:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:37:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:37:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:37:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:40:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-19 09:48:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:48:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:48:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:48:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:48:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:48:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:49:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:49:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:49:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:49:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:49:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:53:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:53:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 09:53:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 09:53:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 09:53:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 09:53:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:06:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:06:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:06:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:06:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:06:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:06:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:09:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:09:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:09:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:12:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:12:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:12:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:12:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:12:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:12:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:13:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:13:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:13:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:13:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:13:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:13:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:14:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:14:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:14:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:15:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 250
ERROR - 2022-07-19 10:15:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 250
ERROR - 2022-07-19 10:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:15:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:15:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:15:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:17:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 250
ERROR - 2022-07-19 10:17:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 250
ERROR - 2022-07-19 10:17:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:17:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:17:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:17:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:17:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:17:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:22:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:22:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:22:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:22:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:22:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:22:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:23:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:23:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 10:23:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 10:23:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 10:23:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 10:23:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:23:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:23:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:23:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 11:23:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 11:23:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:23:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-19 11:25:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:25:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:25:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-19 11:25:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-19 11:25:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-19 11:25:38 --> 404 Page Not Found: Assets/css
