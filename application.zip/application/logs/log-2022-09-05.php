<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-05 04:50:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 05:16:27 --> Query error: Unknown column 'a.outlet_id' in 'on clause' - Invalid query: SELECT *
FROM `stock_taking_details` `a`
JOIN `stock_taking` `s` ON `s`.`stid`=`a`.`stid`
JOIN `product_information` `b` ON `a`.`product_id`=`b`.`product_id`
LEFT JOIN `outlet_warehouse` `o` ON `o`.`outlet_id`=`a`.`outlet_id`
WHERE `a`.`stid` = '947961342'
ERROR - 2022-09-05 05:16:27 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1142
ERROR - 2022-09-05 05:33:49 --> Severity: Notice --> Trying to get property 'central_warehouse' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 91
ERROR - 2022-09-05 05:51:38 --> Query error: Unknown column 'a.outlet_id' in 'on clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`outlet_id` = `a`.`outlet_id`
WHERE `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = '16945P'
AND `a`.`status` = 1
GROUP BY `b`.`product_id`
ORDER BY `b`.`id` DESC
ERROR - 2022-09-05 05:51:38 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 465
ERROR - 2022-09-05 05:51:51 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-05 05:51:51 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-05 05:51:51 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-05 05:51:51 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-05 05:51:51 --> Query error: Unknown column 'a.outlet_id' in 'on clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`outlet_id` = `a`.`outlet_id`
WHERE `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = '16945P'
AND `a`.`status` = 1
GROUP BY `b`.`product_id`
ORDER BY `b`.`id` DESC
ERROR - 2022-09-05 05:52:27 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-05 05:52:27 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-05 05:52:27 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-05 05:52:27 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-05 05:52:27 --> Query error: Unknown column 'b.product_id' in 'group statement' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stid` = `a`.`stid`
WHERE `b`.`outlet_id` = 'HK7TGDT69VFMXB7'
AND `a`.`product_id` = '16945P'
AND `a`.`status` = 1
GROUP BY `b`.`product_id`
ORDER BY `b`.`id` DESC
ERROR - 2022-09-05 05:52:44 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-05 05:52:44 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 356
ERROR - 2022-09-05 05:52:44 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-05 05:52:44 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 358
ERROR - 2022-09-05 05:55:45 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 05:56:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 05:57:18 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 06:01:46 --> Severity: error --> Exception: Call to a member function get_outlet_user() on null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 125
ERROR - 2022-09-05 06:04:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 06:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 06:24:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 06:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 06:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 06:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 06:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 06:24:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 06:24:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 06:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:24:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 06:24:24 --> Query error: Unknown column 'b.stdid' in 'on clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stdid` = `a`.`stid`
WHERE `b`.`outlet_id` = 'E848KA1E4G9UO2G'
AND `a`.`product_id` IS NULL
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-05 06:26:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 06:26:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 06:26:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:26:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 06:26:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:26:08 --> Query error: Unknown column 'b.stdid' in 'on clause' - Invalid query: SELECT SUM(a.difference) as phy_qty
FROM `stock_taking_details` `a`
JOIN `stock_taking` `b` ON `b`.`stdid` = `a`.`stid`
WHERE `b`.`outlet_id` = 'E848KA1E4G9UO2G'
AND `a`.`product_id` = 'ABV1234'
AND `a`.`status` = 1
GROUP BY `a`.`product_id`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-05 06:26:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:26:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 06:26:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 06:26:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:26:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 06:26:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 06:27:16 --> Query error: Unknown column 'b.product_id' in 'where clause' - Invalid query: SELECT *
FROM `product_information` `d`
WHERE `b`.`product_id` = '16945P'
ERROR - 2022-09-05 06:28:20 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1693
ERROR - 2022-09-05 06:46:46 --> Query error: Unknown column 'b.name' in 'field list' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-09-05 06:46:46 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-09-05 06:55:41 --> Query error: Unknown column 'o.outlet_idleft' in 'on clause' - Invalid query: SELECT `a`.*, `o`.`outlet_name`, `a`.`outlet_id` as `out`
FROM `stock_taking` `a`
JOIN `outlet_warehouse` `o` ON `a`.`outlet_id`=`o`.`outlet_idleft`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-05 06:55:41 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 234
ERROR - 2022-09-05 06:55:50 --> Query error: Unknown column 'o.outlet_idleft' in 'on clause' - Invalid query: SELECT `a`.*, `o`.`outlet_name`, `a`.`outlet_id` as `out`
FROM `stock_taking` `a`
JOIN `outlet_warehouse` `o` ON `a`.`outlet_id`=`o`.`outlet_idleft`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-05 06:55:50 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 234
ERROR - 2022-09-05 06:56:01 --> Query error: Unknown column 'o.outlet_idleft' in 'on clause' - Invalid query: SELECT `a`.*, `o`.`outlet_name`, `a`.`outlet_id` as `out`
FROM `stock_taking` `a`
JOIN `outlet_warehouse` `o` ON `a`.`outlet_id`=`o`.`outlet_idleft`
ORDER BY `a`.`id` DESC
ERROR - 2022-09-05 06:58:34 --> Unable to load the requested class: Warehouse
ERROR - 2022-09-05 06:59:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 179
ERROR - 2022-09-05 06:59:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 179
ERROR - 2022-09-05 07:04:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 179
ERROR - 2022-09-05 07:04:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 179
ERROR - 2022-09-05 07:19:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 08:15:46 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 08:16:30 --> The upload path does not appear to be valid.
ERROR - 2022-09-05 08:17:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 08:23:21 --> The upload path does not appear to be valid.
ERROR - 2022-09-05 08:43:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:43:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:43:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:43:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:43:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:43:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:48:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:48:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:48:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:48:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:48:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:48:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:48:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:48:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:49:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:49:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:49:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:49:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:49:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:49:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:49:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:49:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:49:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:56:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-05 08:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:58:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:58:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:58:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:58:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:59:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-05 08:59:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-05 08:59:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 08:59:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-05 08:59:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-05 09:05:56 --> The upload path does not appear to be valid.
ERROR - 2022-09-05 09:43:17 --> The upload path does not appear to be valid.
ERROR - 2022-09-05 09:44:08 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9537867787', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 9537867787 Customer- ', 0, '', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 09:44:08', 1)
ERROR - 2022-09-05 09:45:16 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9537867787', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 9537867787 Customer- ', 0, '', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 09:45:16', 1)
ERROR - 2022-09-05 09:49:01 --> The upload path does not appear to be valid.
ERROR - 2022-09-05 09:49:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8945196232', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8945196232 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 09:49:01', 1)
ERROR - 2022-09-05 09:49:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `paid_amount` (`invoice_id`, `pay_type`, `amount`, `account`, `pay_date`, `COAID`, `status`) VALUES ('8945196232', '3', '300', '01864598947', '2022-09-05', NULL, 1)
ERROR - 2022-09-05 09:49:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8945196232', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Bkash) for Paid Amount For Customer Invoice ID - 8945196232 Customer- ', 0, '300', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 09:49:01', 1)
ERROR - 2022-09-05 09:49:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8945196232', 'INVOICE', '2022-09-05', NULL, 'Cash in Bkash paid amount for customer  Invoice ID - 8945196232 customer -', '300', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-05 09:49:01', 1)
ERROR - 2022-09-05 09:49:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8945196232', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Bank) for Paid Amount For Customer Invoice ID - 8945196232 Customer- ', 0, '500', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 09:49:01', 1)
ERROR - 2022-09-05 10:13:02 --> The upload path does not appear to be valid.
ERROR - 2022-09-05 10:13:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3789136395', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 3789136395 Customer- ', 0, '100', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 10:13:02', 1)
ERROR - 2022-09-05 10:13:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3789136395', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Bkash) for Paid Amount For Customer Invoice ID - 3789136395 Customer- ', 0, '100', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 10:13:02', 1)
ERROR - 2022-09-05 10:13:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3789136395', 'INV', '2022-09-05', NULL, 'Customer credit (Cash In Bank) for Paid Amount For Customer Invoice ID - 3789136395 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-09-05 10:13:02', 1)
