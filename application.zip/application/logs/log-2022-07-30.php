<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-30 04:36:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 04:36:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:36:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:36:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:36:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:36:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:36:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:49:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 04:49:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:49:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:49:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:49:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:50:28 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 04:50:28 --> Query error: Unknown column 'bank_id' in 'field list' - Invalid query: INSERT INTO `cus_cheque` (`cheque_no`, `invoice_id`, `cheque_id`, `cheque_type`, `bank_id`, `cheque_date`, `amount`, `image`, `status`) VALUES ('432432535', '1713753877', '9545413138', 'ins', '', '2022-07-30', '300', 'https://git.test/erp_swapon/my-assets/image/product.png', 2)
ERROR - 2022-07-30 04:50:28 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1713753877', 'INV', '2022-07-30', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1713753877 Customer- masud rana', 0, '1', 1, 'OpSoxJvBbbS8Rws', '2022-07-30 04:50:28', 1)
ERROR - 2022-07-30 04:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:50:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:50:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:50:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 04:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:52:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:52:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:52:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:52:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:52:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:53:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 04:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:53:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:53:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:53:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:53:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:53:57 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 04:53:57 --> Query error: Unknown column 'bank_id' in 'field list' - Invalid query: INSERT INTO `cus_cheque` (`cheque_no`, `invoice_id`, `cheque_id`, `cheque_type`, `bank_id`, `cheque_date`, `amount`, `image`, `status`) VALUES ('43243242', '8694978584', '7143777317', '432', NULL, '2022-07-30', '12', 'https://git.test/erp_swapon/my-assets/image/product.png', 2)
ERROR - 2022-07-30 04:53:57 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8694978584', 'INV', '2022-07-30', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8694978584 Customer- ArmaN', 0, '1', 1, 'OpSoxJvBbbS8Rws', '2022-07-30 04:53:57', 1)
ERROR - 2022-07-30 04:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:55:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:55:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:55:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 04:55:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:55:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:55:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:55:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 04:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 04:59:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:59:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 04:59:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 04:59:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:59:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 04:59:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:00:44 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 05:00:44 --> Query error: Unknown column 'bank_id' in 'field list' - Invalid query: INSERT INTO `cus_cheque` (`cheque_no`, `invoice_id`, `cheque_id`, `cheque_type`, `bank_id`, `cheque_date`, `amount`, `image`, `status`) VALUES ('3432432423', '1473729194', '5946163258', 'tre', 'EBL Bank', '2022-07-30', '200', 'https://git.test/erp_swapon/my-assets/image/product.png', 2)
ERROR - 2022-07-30 05:00:44 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1473729194', 'INV', '2022-07-30', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1473729194 Customer- MOHAMMAD ARIF UDDIN', 0, '1', 1, 'OpSoxJvBbbS8Rws', '2022-07-30 05:00:44', 1)
ERROR - 2022-07-30 05:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 05:01:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:01:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:01:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:01:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:01:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 05:01:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:01:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:01:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:01:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:01:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:01:59 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 05:01:59 --> Query error: Unknown column 'bank_id' in 'field list' - Invalid query: INSERT INTO `cus_cheque` (`cheque_no`, `invoice_id`, `cheque_id`, `cheque_type`, `bank_id`, `cheque_date`, `amount`, `image`, `status`) VALUES ('32432432', '8512658813', '9829838164', 'trt', 'EBL Bank', '2022-07-30', '23', 'https://git.test/erp_swapon/my-assets/image/product.png', 2)
ERROR - 2022-07-30 05:01:59 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8512658813', 'INV', '2022-07-30', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8512658813 Customer- ', 0, '1', 1, 'OpSoxJvBbbS8Rws', '2022-07-30 05:01:59', 1)
ERROR - 2022-07-30 05:02:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:02:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:02:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:02:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:02:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 05:02:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:02:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:02:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:02:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:02:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:03:31 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 05:03:31 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6591296613', 'INV', '2022-07-30', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6591296613 Customer- Ahmmed marzuk', 0, '1', 1, 'OpSoxJvBbbS8Rws', '2022-07-30 05:03:31', 1)
ERROR - 2022-07-30 05:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 05:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:03:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:03:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:05:01 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 05:05:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9485878424', 'INV', '2022-07-30', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 9485878424 Customer- MOHAMMAD ARIF UDDIN', 0, '1', 1, 'OpSoxJvBbbS8Rws', '2022-07-30 05:05:01', 1)
ERROR - 2022-07-30 05:05:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:05:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:05:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:05:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:05:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:05:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:05:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:05:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:05:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:11:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:11:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:11:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:11:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:11:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:11:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:11:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 05:11:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:11:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:11:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:12:35 --> The upload path does not appear to be valid.
ERROR - 2022-07-30 05:12:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:12:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:12:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:12:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:12:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:12:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:12:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:12:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:12:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:13:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:13:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:13:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:13:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:13:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:13:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:13:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:15:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:16:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:17:20 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:20:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:25:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:25:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:28:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:28:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:28:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:30:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:34:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:36:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:36:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:36:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:37:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:40:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:40:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:40:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:40:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:40:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:40:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:40:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:41:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:41:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:41:17 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:41:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:41:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:41:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:41:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:43:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:43:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:43:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:43:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:43:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:43:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:45:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:45:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:45:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:45:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:45:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:45:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:45:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:45:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:45:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:45:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:45:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:45:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:45:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:46:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:46:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:47:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:48:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:50:14 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:50:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:50:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:50:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:54:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:54:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:54:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:54:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:54:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:54:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:55:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:59:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 05:59:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 05:59:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 05:59:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 05:59:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 05:59:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 06:00:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 06:00:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 06:04:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:07:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:09:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:10:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:11:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:13:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:18:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:18:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:19:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:20:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:23:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:24:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:25:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:26:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:27:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:27:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:28:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:28:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:29:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:29:17 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:30:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:33:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:41:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:42:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:43:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:43:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:45:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:45:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:47:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:47:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:49:12 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:55:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:56:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:57:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:58:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 06:59:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 06:59:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 06:59:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 06:59:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 06:59:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 06:59:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 07:01:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 07:01:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 07:01:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:01:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 07:01:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 07:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:02:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:12:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:13:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:14:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:15:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:18:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:18:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:18:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 07:18:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 07:18:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:18:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:18:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 07:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:20:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 07:20:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 07:20:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 07:20:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:20:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 07:20:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 07:23:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:32:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:34:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:34:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:37:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:37:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:38:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 08:40:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-30 09:08:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-30 09:11:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 331
ERROR - 2022-07-30 09:12:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 09:13:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 09:13:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:13:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:13:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:13:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 09:13:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 09:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 09:15:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:15:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 09:15:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 09:15:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:15:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 09:15:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 09:17:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:17:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 09:17:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 09:17:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:17:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 09:17:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:17:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:17:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-30 09:17:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-30 09:17:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-30 09:17:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:17:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-30 09:19:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-30 10:35:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-07-30 10:35:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-07-30 11:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 178
