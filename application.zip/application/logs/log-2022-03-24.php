<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-24 04:47:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-24 04:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-24 04:47:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-24 04:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-24 04:47:50 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-24 04:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 04:59:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 04:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 04:59:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 04:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 04:59:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 04:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 04:59:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 04:59:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 04:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 04:59:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 04:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:01:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:01:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:01:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:01:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:01:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:05:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:05:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:05:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:05:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:05:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:05:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:06:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:06:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:06:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:06:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:06:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:08:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:08:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:08:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:08:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:08:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:10:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:10:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:33:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:33:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:33:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:34:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:34:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:34:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:34:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:36:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:36:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:36:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:36:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:36:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:38:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:38:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:38:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:38:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:38:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:38:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:39:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:39:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:39:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:39:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:39:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:39:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:42:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:42:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:42:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:42:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:42:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:43:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:43:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:43:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:43:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:46:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:46:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:46:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:46:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:47:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:47:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:47:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:47:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:48:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:48:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:48:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:48:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:48:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:48:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:48:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:48:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:48:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:49:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:49:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:49:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:49:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:49:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:49:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:49:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 313
ERROR - 2022-03-24 05:50:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:50:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:50:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:50:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:50:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:50:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:50:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 313
ERROR - 2022-03-24 05:50:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:50:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:50:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:50:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:50:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:50:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:54:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:54:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:54:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:54:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:54:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:54:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:56:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:56:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:56:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:56:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:56:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:57:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:57:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:57:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:57:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:57:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:58:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:58:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 05:58:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:58:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 05:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 313
ERROR - 2022-03-24 06:00:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:00:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:00:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:00:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:00:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:00:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:01:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:01:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:01:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:01:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:02:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:02:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:02:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:03:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:03:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:03:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 313
ERROR - 2022-03-24 06:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:04:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:04:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:04:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 313
ERROR - 2022-03-24 06:04:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:04:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:04:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:04:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:04:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:04:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:06:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:06:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:06:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:06:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:06:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:06:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:10:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:10:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:10:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:10:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:10:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:10:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:12:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:12:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:13:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:13:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:14:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:14:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:14:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:14:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:14:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:15:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:15:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:15:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:15:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:15:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:15:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:21:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:21:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:21:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:21:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:24:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:24:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:24:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:24:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:25:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:25:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:25:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:25:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:25:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:25:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:27:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:27:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:27:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:27:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:27:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:33:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:34:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:34:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:34:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:34:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:36:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:36:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:37:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:37:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:37:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:37:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:37:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:38:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:38:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:38:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:38:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:38:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:38:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:39:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:40:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:40:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:40:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:40:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:40:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:41:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 315
ERROR - 2022-03-24 06:43:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:43:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:43:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:43:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:43:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:43:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-03-24 06:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:45:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:46:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:46:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-03-24 06:46:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 322
ERROR - 2022-03-24 06:50:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:50:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:51:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:51:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:51:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:51:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:51:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 337
ERROR - 2022-03-24 06:57:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:57:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 06:57:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 06:57:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 06:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 06:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:02:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 338
ERROR - 2022-03-24 07:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 338
ERROR - 2022-03-24 07:11:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 338
ERROR - 2022-03-24 07:29:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:29:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 07:29:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:29:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 07:29:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:29:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 07:30:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:30:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 07:30:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 07:30:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:30:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 07:30:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:33:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 07:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:33:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 07:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 07:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:34:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 07:34:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 07:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 07:34:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 07:34:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 08:35:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `a`.`date` < `IS` `NULL`' at line 4 - Invalid query: SELECT `a`.*, `b`.*
FROM `invoice` `a`
JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
WHERE `a`.`date` > `IS` `NULL`
AND `a`.`date` < `IS` `NULL`
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:47:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:47:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 08:48:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 08:48:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:28 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 390
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 390
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 395
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 395
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 396
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 396
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 397
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 397
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 398
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 398
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 399
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 399
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 400
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 400
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 401
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 401
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 404
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 404
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 405
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 405
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 406
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 406
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 407
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 407
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 409
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 409
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 410
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 410
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 411
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 411
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 413
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 413
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 418
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 418
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 432
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 432
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 433
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 433
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 439
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 439
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:46:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:50:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:50:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:50:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:50:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:50:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:50:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:50:50 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 570
ERROR - 2022-03-24 09:50:50 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 224
ERROR - 2022-03-24 09:50:50 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 570
ERROR - 2022-03-24 09:50:50 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 224
ERROR - 2022-03-24 09:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:51:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:51:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:51:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:51:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:51:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:51:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 390
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 390
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 395
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 395
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 396
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 396
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 397
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 397
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 398
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 398
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 399
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 399
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 400
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 400
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 401
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 401
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 404
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 404
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 405
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 405
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 406
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 406
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 407
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 407
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 409
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 409
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 410
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 410
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 411
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 411
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 413
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 413
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 418
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 418
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 432
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 432
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 433
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 433
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 439
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 439
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-03-24 09:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:51:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:51:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:51:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:51:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:51:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:53:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:53:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:53:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-24 09:53:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 09:53:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 09:53:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:53:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 09:53:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-24 09:53:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 09:53:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 10:20:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-24 10:20:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:20:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:20:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:20:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:20:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:20:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:21:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-24 10:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-24 10:21:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-24 10:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-24 10:21:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-24 10:21:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-24 10:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:22:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:22:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:22:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:22:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:22:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:22:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:22:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:22:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:22:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:22:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:45:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:45:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:45:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:45:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:45:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:45:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:45:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:45:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:45:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:45:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:45:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:46:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:46:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:46:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:46:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:47:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:47:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:47:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:47:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:47:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:47:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:47:34 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-24 10:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-24 10:47:34 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-24 10:47:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-24 10:47:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:47:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:47:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:47:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:47:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:47:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:48:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:48:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:48:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:48:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:48:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:50:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:50:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:50:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:50:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:50:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:50:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:50:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:52:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:52:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:52:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:52:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:54:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:54:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:54:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:55:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:55:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:55:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:55:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:55:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:57:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:57:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:57:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:57:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:57:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:58:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:58:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:58:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:58:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:59:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:59:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 10:59:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 10:59:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 10:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 10:59:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:07:06 --> Query error: Unknown column 'sz.size_name' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`product_model`, `c`.`invoice`, `c`.`date`, `sz`.`size_name`, `cl`.`color_name`
FROM `invoice_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `invoice` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
WHERE `b`.`product_id` = '593'
AND `c`.`date` >= '2022-03-01'
AND `c`.`date` <= '2022-03-24'
ORDER BY `c`.`date` DESC
ERROR - 2022-03-24 11:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:07:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:07:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:07:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:07:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:07:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:14:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:14:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:14:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:14:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:14:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:15:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:15:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:15:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:15:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:16:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:16:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:16:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:16:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:16:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:16:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:17:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:17:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:17:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:17:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:17:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:17:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:18:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:18:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:18:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:18:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:18:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:18:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:18:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `c`.`date` < `IS` `NULL`
ORDER BY `c`.`date` DESC' at line 9 - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`product_model`, `c`.`date`, `d`.`customer_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `invoice_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `invoice` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `customer_information` `d` ON `d`.`customer_id` = `c`.`customer_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `b`.`product_id` IS NULL
AND `c`.`date` > `IS` `NULL`
AND `c`.`date` < `IS` `NULL`
ORDER BY `c`.`date` DESC
ERROR - 2022-03-24 11:18:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `c`.`date` < `IS` `NULL`
ORDER BY `c`.`date` DESC' at line 9 - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`product_model`, `c`.`date`, `d`.`customer_name`, `sz`.`size_name`, `cl`.`color_name`
FROM `invoice_details` `a`
JOIN `product_information` `b` ON `b`.`product_id` = `a`.`product_id`
JOIN `invoice` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `customer_information` `d` ON `d`.`customer_id` = `c`.`customer_id`
LEFT JOIN `size_list` `sz` ON `b`.`size`=`sz`.`size_id`
LEFT JOIN `color_list` `cl` ON `b`.`color`=`cl`.`color_id`
WHERE `b`.`product_id` IS NULL
AND `c`.`date` > `IS` `NULL`
AND `c`.`date` < `IS` `NULL`
ORDER BY `c`.`date` DESC
ERROR - 2022-03-24 11:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:18:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:18:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:18:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:18:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:18:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:18:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:19:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:19:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:19:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:19:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:20:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:20:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:20:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:20:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:20:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:20:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:20:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:21:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:21:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:21:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:21:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:21:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:21:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:22:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:22:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:22:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:22:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:22:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:22:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:24:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:24:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:24:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:25:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:25:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:25:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:25:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:25:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:25:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:25:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:25:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:25:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:25:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:25:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:40:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:40:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:40:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:40:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:40:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:40:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:40:50 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\report\expense_report.php 175
ERROR - 2022-03-24 11:40:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:40:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:40:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:40:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:40:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:40:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:45:46 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\report\expense_report.php 175
ERROR - 2022-03-24 11:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:45:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:45:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:45:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:45:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:45:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-24 11:45:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-24 11:45:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-24 11:45:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-24 11:45:59 --> 404 Page Not Found: Assets/js
