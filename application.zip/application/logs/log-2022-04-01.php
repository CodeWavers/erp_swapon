<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-01 13:31:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\laragon\www\git\erp_swapon\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-04-01 13:31:55 --> Unable to connect to the database
ERROR - 2022-04-01 13:32:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-04-01 13:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:33:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 13:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:33:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 13:33:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 13:56:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 13:56:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:56:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 13:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:56:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 13:56:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 13:56:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:02:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:02:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:02:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:02:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:02:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:02:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:02:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:02:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:02:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:08:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:08:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:08:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:08:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:08:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:08:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:15:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7278769755', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 7278769755 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:15:52', 1)
ERROR - 2022-04-01 14:15:54 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4984531255', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 4984531255 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:15:54', 1)
ERROR - 2022-04-01 14:15:56 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9415653542', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 9415653542 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:15:56', 1)
ERROR - 2022-04-01 14:15:57 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('5399728278', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 5399728278 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:15:57', 1)
ERROR - 2022-04-01 14:16:00 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6562957259', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6562957259 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:16:00', 1)
ERROR - 2022-04-01 14:18:34 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4564866294', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 4564866294 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:34', 1)
ERROR - 2022-04-01 14:18:35 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1942193653', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1942193653 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:35', 1)
ERROR - 2022-04-01 14:18:37 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1321274255', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1321274255 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:37', 1)
ERROR - 2022-04-01 14:18:37 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('2522363327', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 2522363327 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:37', 1)
ERROR - 2022-04-01 14:18:38 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8381844767', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8381844767 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:38', 1)
ERROR - 2022-04-01 14:18:38 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('2816523549', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 2816523549 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:38', 1)
ERROR - 2022-04-01 14:18:39 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('5542877843', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 5542877843 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:39', 1)
ERROR - 2022-04-01 14:18:43 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3959515567', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 3959515567 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:43', 1)
ERROR - 2022-04-01 14:18:44 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('5731929128', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 5731929128 Customer- ', 0, '23', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 14:18:44', 1)
ERROR - 2022-04-01 14:29:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:29:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:40:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:40:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:40:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:40:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:40:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:40:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:40:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:40:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:40:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:40:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:40:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:40:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:42:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:42:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:47:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:47:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:47:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:47:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:47:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:52:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:52:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:52:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:52:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:52:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:52:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 14:59:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 14:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 14:59:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 14:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:00:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:00:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:00:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:00:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:00:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:00:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:04:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:04:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:04:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:04:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:04:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:08:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:08:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:08:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:08:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:09:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:10:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:10:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:10:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:10:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:10:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:10:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:10:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:10:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:12:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:12:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:12:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:12:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:12:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:14:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:14:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:14:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('2437117378', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 2437117378 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 15:14:52', 1)
ERROR - 2022-04-01 15:14:54 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4326461389', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 4326461389 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 15:14:54', 1)
ERROR - 2022-04-01 15:14:58 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8575689227', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8575689227 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 15:14:58', 1)
ERROR - 2022-04-01 15:22:03 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8158898778', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8158898778 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 15:22:03', 1)
ERROR - 2022-04-01 15:22:06 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8919887177', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8919887177 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 15:22:06', 1)
ERROR - 2022-04-01 15:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:22:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:22:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:22:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:23:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:23:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:23:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:23:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:28:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:28:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:28:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:28:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:28:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:28:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:30:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:30:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:30:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:30:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:31:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:32:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:32:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:32:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:32:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:32:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:32:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:36:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:36:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:36:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:36:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:36:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:37:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:37:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:37:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:37:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:37:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:37:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:37:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 15:37:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 15:37:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:37:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 15:37:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 15:47:51 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7138355275', 'INV', '2022-04-01', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 7138355275 Customer- ', 0, '2', 1, 'OpSoxJvBbbS8Rws', '2022-04-01 15:47:51', 1)
ERROR - 2022-04-01 16:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:01:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:01:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:06:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:06:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:06:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:06:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:06:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:11:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:11:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:11:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:11:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:12:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:12:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:12:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:12:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:12:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:12:36 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:12:36 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:12:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:12:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:12:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:12:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:12:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:12:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:13:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:13:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:13:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:13:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:13:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:13:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:19:31 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:19:31 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:20:18 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:20:18 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:20:28 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:20:28 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:20:35 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:20:35 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:21:27 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:21:27 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:23:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:23:01 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:27:02 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `a`.*, `b`.`HeadCode`, ((select ifnull(sum(Debit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit), 0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance
FROM `customer_information` `a`
LEFT JOIN `acc_coa` `b` ON `a`.`customer_id` = `b`.`customer_id`
WHERE `a`.`customer_id` = Array
ERROR - 2022-04-01 16:27:02 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 971
ERROR - 2022-04-01 16:27:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:27:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:27:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:27:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:27:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:27:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:28:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:28:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:28:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:28:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:28:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:28:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:29:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:29:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:34:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-01 16:34:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-04-01 16:34:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-04-01 16:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-01 16:34:55 --> 404 Page Not Found: Assets/js
