<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-03 13:47:19 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-03 13:47:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-03 13:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 13:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 13:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 13:48:19 --> The upload path does not appear to be valid.
ERROR - 2022-11-03 13:48:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-03 13:49:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-03 13:49:28 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-03 13:50:28 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-03 13:51:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-03 13:53:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-03 14:13:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-03 14:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-03 14:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:32:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:32:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:32:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:33:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:34:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:34:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:34:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 14:42:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 14:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 14:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 15:00:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 15:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 15:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 15:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 15:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 15:00:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Test Product', 1, 5655, 5655, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/uploads/products/thumbnail/MZO2oMhCzzFRTjMOw6uX30gfRe4L69q0SrsV28Qd.png', 1, '2022-04-13T05:41:36.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'SARWAR', 1, 2000, 2000, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/uploads/products/thumbnail/sDjS05nQiUy4hWvFJzrIfyVGn2yd5pAOWk8zcLiS.png', 1, '2022-04-16T10:00:19.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '1', '', 'Test Product', 1, 77, 77, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T18:25:40.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Milk', 1, 2, 2, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T18:30:46.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Test Product', 1, 1, 1, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T19:46:02.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '1', '', 'iFOB(25T/Box)', 1, 1, 1, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T19:49:40.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '2', '', 'Milk', 1, 250, 250, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-18T15:31:35.000000Z')
ERROR - 2022-11-03 15:29:51 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Wayne Holloway', 1, 773, 773, 'Pcs', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-19T19:16:05.000000Z')
ERROR - 2022-11-03 15:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 15:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 15:37:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 15:44:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 15:44:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 15:44:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 15:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 15:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 15:45:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 16:02:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 16:02:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 16:02:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 16:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 16:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 16:05:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 16:05:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 16:05:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 16:05:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 16:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 16:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 16:37:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 16:43:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 16:43:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 16:43:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 16:43:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 16:43:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 16:43:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 17:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 17:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 17:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:23:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:23:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:23:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 17:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 17:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 17:23:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:23:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:23:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:23:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:23:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:23:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 17:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 17:25:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 17:25:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:25:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:25:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:25:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:25:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:25:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-03 17:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-03 17:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-03 17:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:26:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:26:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:26:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:26:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:29:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:29:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:29:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:30:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:30:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:30:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:30:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:30:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:30:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:30:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:30:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:30:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:31:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:31:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:31:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:31:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:31:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:31:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:31:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:31:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:32:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:32:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:32:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:32:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:32:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:32:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-03 17:32:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-03 17:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 17:32:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-03 17:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-03 21:54:45 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-03 21:54:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 21:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 21:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 21:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-03 21:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-03 21:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-03 22:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 301
ERROR - 2022-11-03 22:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-03 22:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-03 22:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-03 22:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
