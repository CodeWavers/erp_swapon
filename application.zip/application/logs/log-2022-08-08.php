<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-08 11:34:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-08 11:35:54 --> 404 Page Not Found: My-assets/image
