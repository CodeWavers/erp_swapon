<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-06 04:50:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'erp_swapon' C:\laragon\www\git\erp_swapon\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-06 04:50:34 --> Unable to connect to the database
ERROR - 2022-07-06 04:55:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2820
ERROR - 2022-07-06 04:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2820
ERROR - 2022-07-06 04:55:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2887
ERROR - 2022-07-06 04:55:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2887
ERROR - 2022-07-06 04:55:19 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 413
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 413
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 414
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 414
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 418
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 418
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 419
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 419
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 420
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 420
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 421
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 421
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 422
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 422
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 423
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 423
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 424
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 424
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 427
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 427
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 428
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 428
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 429
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 429
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 430
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 430
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 433
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 433
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 434
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 437
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 437
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 438
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 438
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 445
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 445
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 446
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 446
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 451
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 451
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 452
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 452
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 453
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 453
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 454
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 454
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 455
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 455
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 456
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 456
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 459
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 459
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 69
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 70
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 70
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 71
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 71
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 72
ERROR - 2022-07-06 05:01:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 72
ERROR - 2022-07-06 05:13:44 --> The upload path does not appear to be valid.
ERROR - 2022-07-06 05:13:44 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6629946146', 'INV', '2022-07-06', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6629946146 Customer- Test Customer 2', 0, '2600.05', 1, 'OpSoxJvBbbS8Rws', '2022-07-06 05:13:44', 1)
ERROR - 2022-07-06 05:13:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-06 05:14:21 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6629946146', 'INV', '2022-07-06', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6629946146 Customer- Test Customer 2', 0, '', 1, 'OpSoxJvBbbS8Rws', '2022-07-06 05:14:21', 1)
ERROR - 2022-07-06 05:14:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-06 05:15:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 05:18:15 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 05:20:22 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 05:20:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 05:21:13 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 05:34:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-06 05:34:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-06 05:34:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-06 05:34:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-06 05:34:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-06 05:34:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-06 05:54:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-06 06:17:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 09:20:22 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 09:21:39 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 09:46:06 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 09:46:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 15:51:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-07-06 15:53:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-07-06 10:07:51 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 10:10:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-06 17:42:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-07-06 11:42:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-06 11:42:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
