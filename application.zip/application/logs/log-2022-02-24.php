<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-24 04:29:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-24 04:29:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-24 04:29:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-24 04:29:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-24 04:29:38 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-24 04:48:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-02-24 05:19:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-24 05:19:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-24 05:19:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-24 05:19:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-24 05:19:11 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-24 06:23:54 --> Severity: Notice --> Trying to get property 'order_details' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 66
ERROR - 2022-02-24 06:23:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 71
ERROR - 2022-02-24 06:23:54 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 71
ERROR - 2022-02-24 06:25:30 --> Severity: Notice --> Trying to get property 'order_details' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 70
ERROR - 2022-02-24 06:25:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 75
ERROR - 2022-02-24 06:25:30 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 75
ERROR - 2022-02-24 06:25:39 --> Severity: Notice --> Trying to get property 'order_details' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 70
ERROR - 2022-02-24 06:25:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 75
ERROR - 2022-02-24 06:25:39 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 75
ERROR - 2022-02-24 06:26:20 --> Severity: Notice --> Trying to get property 'order_details' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 70
ERROR - 2022-02-24 06:40:10 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:42:00 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:42:55 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 73
ERROR - 2022-02-24 06:45:39 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:46:21 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:47:19 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:47:29 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:47:32 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 06:48:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 120
ERROR - 2022-02-24 06:49:26 --> Severity: Notice --> Undefined variable: shipping C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 127
ERROR - 2022-02-24 06:49:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 127
ERROR - 2022-02-24 06:58:27 --> Severity: Notice --> Undefined variable: city C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 125
ERROR - 2022-02-24 07:01:59 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 138
ERROR - 2022-02-24 07:02:48 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 150
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'order_details' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 178
ERROR - 2022-02-24 08:40:53 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 178
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'order_details' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 178
ERROR - 2022-02-24 09:28:27 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 178
ERROR - 2022-02-24 10:24:47 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:24:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 10:24:47 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 10:24:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 10:24:47 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 10:25:58 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:25:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 10:25:58 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 10:25:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 10:25:58 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 10:32:59 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:32:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 10:32:59 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 96
ERROR - 2022-02-24 10:32:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 10:32:59 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 97
ERROR - 2022-02-24 10:34:48 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:35:39 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:36:25 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:38:37 --> Severity: Notice --> Undefined property: stdClass::$order_details C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 90
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 91
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 98
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 99
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 100
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 101
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 102
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 103
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 104
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 105
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Undefined variable: payment_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Undefined variable: payment_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Undefined variable: delivery_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Undefined variable: delivery_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 97
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 135
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 143
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 151
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 167
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-24 10:39:24 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-02-24 10:42:12 --> Severity: Notice --> Undefined variable: payment_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-24 10:42:12 --> Severity: Notice --> Undefined variable: payment_status C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 87
ERROR - 2022-02-24 10:48:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 10:48:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:48:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:48:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 10:48:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:48:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 10:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 10:49:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 10:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:49:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 10:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:50:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:50:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 10:50:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 10:50:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 10:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:51:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:51:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 10:51:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:51:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 10:51:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:51:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 10:53:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:53:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 10:53:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 10:53:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:53:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:53:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 10:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:54:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 10:54:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 10:54:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 10:54:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 10:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:00:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:00:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 11:00:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 11:00:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:00:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 11:00:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:03:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-24 11:03:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-24 11:03:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:03:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-24 11:03:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-24 11:52:24 --> Severity: 8192 --> The behavior of unparenthesized expressions containing both '.' and '+'/'-' will change in PHP 8: '+'/'-' will take a higher precedence C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-24 11:52:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-24 11:53:04 --> Severity: 8192 --> The behavior of unparenthesized expressions containing both '.' and '+'/'-' will change in PHP 8: '+'/'-' will take a higher precedence C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-24 11:53:04 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-24 11:53:24 --> Severity: 8192 --> The behavior of unparenthesized expressions containing both '.' and '+'/'-' will change in PHP 8: '+'/'-' will take a higher precedence C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
ERROR - 2022-02-24 11:53:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 370
