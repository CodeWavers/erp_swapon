<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-27 04:48:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-27 05:43:52 --> Query error: Column 'mid' cannot be null - Invalid query: INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-08-27 06:07:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-27 06:07:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-27 06:07:47 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220827060747', 'Purchase', '2022-08-27', NULL, 'Supplier .Factory', 0, '200.00', 1, 'OpSoxJvBbbS8Rws', '2022-08-27', 1)
ERROR - 2022-08-27 06:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-27 06:08:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-27 06:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 06:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 06:08:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-27 06:08:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-27 06:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 06:08:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-27 06:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-27 06:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-27 06:10:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 06:10:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-27 06:10:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-27 06:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 06:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 06:10:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-27 06:10:49 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\laragon\www\git\erp_swapon\application\models\Invoices.php 3584
ERROR - 2022-08-27 06:11:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-27 06:11:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-27 06:11:47 --> Severity: Warning --> Illegal string offset 'central_stock' C:\laragon\www\git\erp_swapon\application\models\Invoices.php 3584
ERROR - 2022-08-27 06:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-08-27 06:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-08-27 07:06:56 --> The upload path does not appear to be valid.
ERROR - 2022-08-27 07:11:52 --> The upload path does not appear to be valid.
ERROR - 2022-08-27 07:45:23 --> 404 Page Not Found: Admin_dashboard/varience_report
ERROR - 2022-08-27 08:42:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 08:42:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-27 08:42:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 08:42:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-27 08:42:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-27 08:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-27 09:28:12 --> Severity: error --> Exception: Call to undefined method Categories::cats() C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1191
ERROR - 2022-08-27 09:37:26 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1216
ERROR - 2022-08-27 09:37:26 --> Severity: Notice --> Trying to get property 'id' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1217
ERROR - 2022-08-27 09:43:07 --> Query error: Column 'mid' cannot be null - Invalid query: INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-08-27 10:02:01 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:02:01 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1141
ERROR - 2022-08-27 10:02:04 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:02:04 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1141
ERROR - 2022-08-27 10:02:34 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:03:34 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:03:34 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:03:35 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:03:35 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:03:35 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:03:35 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:01 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:02 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:02 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:02 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:47 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:48 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:48 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:49 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:49 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:49 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:49 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:49 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:49 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:05:50 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:06:29 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:06:29 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1141
ERROR - 2022-08-27 10:06:30 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:06:30 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1141
ERROR - 2022-08-27 10:06:59 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:06:59 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1141
ERROR - 2022-08-27 10:07:47 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 78
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 81
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 95
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 98
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 108
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 161
ERROR - 2022-08-27 10:08:32 --> Severity: Notice --> Undefined variable: access C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 172
ERROR - 2022-08-27 10:08:55 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2022-08-27 10:08:55 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 1141
ERROR - 2022-08-27 10:15:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1243
ERROR - 2022-08-27 10:15:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 1243
ERROR - 2022-08-27 10:18:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:19:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:21:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:21:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:22:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:23:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:24:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:24:31 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:25:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:26:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:27:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:29:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-27 10:30:30 --> 404 Page Not Found: My-assets/image
