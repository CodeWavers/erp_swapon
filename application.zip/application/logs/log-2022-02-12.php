<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-12 05:32:04 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-12 05:32:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-12 05:32:04 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-12 05:32:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-12 05:32:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-12 05:32:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-12 05:32:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-12 05:32:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-12 05:33:06 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-12 05:33:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-12 05:33:06 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-12 05:33:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-12 05:33:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-12 05:33:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-12 05:33:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-12 05:33:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-12 05:33:15 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 07:36:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 07:40:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 07:40:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 07:40:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 07:40:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 07:40:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 07:40:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 07:40:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 07:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 07:40:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 07:40:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 07:40:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 07:40:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:18:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:18:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:18:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:18:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:21:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:21:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:21:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:21:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:21:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:21:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:21:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:21:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:21:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:22:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:22:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:22:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:27:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:27:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:27:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:27:58 --> Severity: 4096 --> Object of class Products could not be converted to string C:\xampp\htdocs\erp_swapon\application\models\Products.php 119
ERROR - 2022-02-12 08:27:58 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\erp_swapon\application\models\Products.php 119
ERROR - 2022-02-12 08:28:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:28:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:28:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:28:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:29:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:29:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:29:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:29:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:29:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:29:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:30:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:30:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:30:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:30:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:30:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:30:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:32:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:32:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:32:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:32:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:32:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:32:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:34:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:34:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:35:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:35:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:35:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:35:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:35:08 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-12 08:37:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:37:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:37:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:37:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:37:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:37:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:38:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:38:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:40:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:40:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:40:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:40:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:46:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:46:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:46:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:46:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 155
ERROR - 2022-02-12 08:46:31 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:47:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:47:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:47:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:47:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:47:55 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\erp_swapon\application\models\Products.php 176
ERROR - 2022-02-12 08:47:55 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:47:55 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\erp_swapon\application\models\Products.php 176
ERROR - 2022-02-12 08:47:55 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:47:56 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\erp_swapon\application\models\Products.php 176
ERROR - 2022-02-12 08:47:56 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:47:56 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\erp_swapon\application\models\Products.php 176
ERROR - 2022-02-12 08:47:56 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:47:56 --> Severity: Notice --> Undefined variable: supplier C:\xampp\htdocs\erp_swapon\application\models\Products.php 176
ERROR - 2022-02-12 08:47:56 --> Severity: Notice --> Undefined property: stdClass::$supplier_price C:\xampp\htdocs\erp_swapon\application\models\Products.php 178
ERROR - 2022-02-12 08:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:48:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:48:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:48:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:53:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:53:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:53:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:53:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:53:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:54:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:54:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:55:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:55:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:55:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:55:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:57:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 08:57:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 08:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 08:57:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 08:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:00:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:00:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:00:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:00:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:00:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:03:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:03:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:03:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:04:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:04:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:04:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:04:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:04:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:04:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:04:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:04:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:04:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:06:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:06:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:06:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:06:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:06:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined variable: nagad_list C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-02-12 09:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined variable: nagad_list C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-02-12 09:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no_id C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no_id C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no_id C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no_id C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-02-12 09:11:03 --> Severity: Notice --> Undefined index: card_no C:\xampp\htdocs\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-02-12 09:11:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\erp_swapon\application\models\Rqsn.php 1276
ERROR - 2022-02-12 09:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-02-12 09:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:11:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:11:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:11:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:13:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:13:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:13:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:13:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:13:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:13:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:15:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:15:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:15:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:19 --> 404 Page Not Found: -assets/image
ERROR - 2022-02-12 09:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:15:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:15:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:16:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:16:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:16:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:16:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:16:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:17:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:17:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 09:17:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 09:17:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 09:17:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:17:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 09:18:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:19:16 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:19:16 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:24:14 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:24:14 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: outlet_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 76
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bank_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 215
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 215
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bank_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 438
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 438
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bank_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 444
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 444
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bkash_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 464
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 464
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bkash_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 469
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 469
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: nagad_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 483
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 483
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: nagad_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 489
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 489
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bank_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 541
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 541
ERROR - 2022-02-12 09:27:52 --> Severity: Notice --> Undefined variable: bank_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 547
ERROR - 2022-02-12 09:27:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 547
ERROR - 2022-02-12 09:29:32 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-12 09:29:32 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-12 09:31:35 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-02-12 09:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-02-12 09:31:35 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 515
ERROR - 2022-02-12 09:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 515
ERROR - 2022-02-12 09:32:10 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-02-12 09:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-02-12 09:32:10 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 515
ERROR - 2022-02-12 09:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 515
ERROR - 2022-02-12 09:32:34 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:32:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:32:34 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:32:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:33:16 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:33:16 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:33:56 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:33:56 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:36:07 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 507
ERROR - 2022-02-12 09:36:07 --> Severity: Notice --> Undefined variable: card_list C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\views\purchase\add_purchase_form.php 513
ERROR - 2022-02-12 09:40:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:43:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:43:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:44:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:47:19 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:50:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:52:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:53:04 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 09:54:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 09:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 09:54:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 09:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 09:56:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 09:56:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 09:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 09:57:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 10:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:08 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:06:20 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-12 10:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:12:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\erp_swapon\application\libraries\Lproduct.php 126
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:09 --> Severity: Notice --> Undefined index: size_name C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:19:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 192
ERROR - 2022-02-12 10:23:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:24:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:25:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:25:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:25:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:25:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:28:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:31:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:32:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:32:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:32:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:38:56 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 10:39:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:42:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:42:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:49:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:52:16 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:53:06 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:54:18 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 10:55:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 10:55:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:56:52 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 10:59:43 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 11:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:02:08 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 448
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:12:26 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 455
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:43 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:13:44 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 455
ERROR - 2022-02-12 11:14:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:19:23 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 455
ERROR - 2022-02-12 11:21:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:25:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:25:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:25:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:25:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:36:57 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 455
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:37:25 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 455
ERROR - 2022-02-12 11:37:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:39:07 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 455
ERROR - 2022-02-12 11:39:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:39:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:39:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:39:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:41:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1154
ERROR - 2022-02-12 11:41:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 11:42:17 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 470
ERROR - 2022-02-12 11:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:07:48 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 470
ERROR - 2022-02-12 12:07:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-12 12:18:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:24:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-12 12:24:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:24:36 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 470
ERROR - 2022-02-12 12:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:34:59 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 470
ERROR - 2022-02-12 12:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:39:39 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 470
ERROR - 2022-02-12 12:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:41:49 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 472
ERROR - 2022-02-12 12:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:43:12 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 472
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:24 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:44:41 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 12:46:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:47:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:51:16 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 12:53:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:53:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-12 12:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:53:41 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:28 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 12:54:48 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 12:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:04:27 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:10:34 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:18:35 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1197
ERROR - 2022-02-12 13:18:56 --> Severity: Notice --> Undefined index: thumbnail_img C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 262
ERROR - 2022-02-12 13:18:56 --> Severity: Notice --> Undefined variable: image_url C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 327
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:19:38 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:19:52 --> Severity: Notice --> Undefined index: thumbnail_img C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 262
ERROR - 2022-02-12 13:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 13:20:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-12 13:20:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-12 13:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 13:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-12 13:20:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:21:10 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:22:12 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:27:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\erp_swapon\system\database\DB_driver.php 1519
ERROR - 2022-02-12 13:27:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\erp_swapon\system\database\DB_driver.php 1519
ERROR - 2022-02-12 13:27:11 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `product_information` SET `product_name` = 'Mi Mobile', `category_id` = Array, `product_id` = '1203', `brand_id` = '14', `ptype_id` = NULL, `price` = '1234567', `color` = Array, `size` = NULL, `product_code` = NULL, `serial_no` = NULL, `re_order_level` = NULL, `product_model` = NULL, `product_details` = '<p>test</p>\r\n', `unit` = 'Pcs', `trxn_unit` = NULL, `unit_multiplier` = NULL, `finished_raw` = '1', `tax` = 0, `image` = NULL
WHERE `product_id` = '1203'
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:27:42 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:27:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 13:28:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\erp_swapon\system\database\DB_driver.php 1519
ERROR - 2022-02-12 13:28:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\erp_swapon\system\database\DB_driver.php 1519
ERROR - 2022-02-12 13:28:07 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `product_information` SET `product_name` = 'Mi Mobile', `category_id` = Array, `product_id` = '1203', `brand_id` = '14', `ptype_id` = NULL, `price` = '1234567', `color` = Array, `size` = NULL, `product_code` = NULL, `serial_no` = NULL, `re_order_level` = NULL, `product_model` = NULL, `product_details` = '<p>test</p>\r\n', `unit` = 'Pcs', `trxn_unit` = NULL, `unit_multiplier` = NULL, `finished_raw` = '1', `tax` = 0, `image` = NULL
WHERE `product_id` = '1203'
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:29:16 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-12 13:30:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\erp_swapon\system\database\DB_driver.php 1519
ERROR - 2022-02-12 13:30:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\erp_swapon\system\database\DB_driver.php 1519
ERROR - 2022-02-12 13:30:11 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `product_information` SET `product_name` = 'Mi Mobile', `category_id` = Array, `product_id` = '1203', `brand_id` = '14', `ptype_id` = NULL, `price` = '1234567', `color` = Array, `size` = NULL, `product_code` = NULL, `serial_no` = NULL, `re_order_level` = NULL, `product_model` = NULL, `product_details` = '<p>test</p>\r\n', `unit` = 'Pcs', `trxn_unit` = NULL, `unit_multiplier` = NULL, `finished_raw` = '1', `tax` = 0, `image` = NULL
WHERE `product_id` = '1203'
ERROR - 2022-02-12 13:30:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 13:30:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-12 13:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:30:52 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 13:31:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined index: size_id C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-12 13:32:05 --> Severity: Notice --> Undefined variable: attribute C:\xampp\htdocs\erp_swapon\application\views\product\edit_product_form.php 469
ERROR - 2022-02-12 13:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1167
ERROR - 2022-02-12 13:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1153
