<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-22 10:55:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-22 11:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:32:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:32:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:32:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:35:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:35:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:35:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:35:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:35:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:36:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:36:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:36:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:36:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:36:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:37:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:37:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:37:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:37:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:37:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:37:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:38:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:38:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:38:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:41:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:41:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:43:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:43:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:43:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:43:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:43:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:43:34 --> Query error: Unknown column 'b.date' in 'where clause' - Invalid query: SELECT avg(production_cost) as cost
FROM `production_cost` `a`
WHERE `b`.`date` >= '2022-10-22'
AND `a`.`product_id` = '078SP'
ERROR - 2022-10-22 11:44:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:44:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:44:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:44:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:44:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-22 11:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-22 11:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-22 11:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-22 11:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-22 11:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-22 11:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:49:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:49:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:51:32 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 568
ERROR - 2022-10-22 11:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-22 11:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-22 11:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-22 11:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-22 11:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-22 11:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-22 11:51:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:51:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:51:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:51:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:51:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:51:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:52:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:52:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:52:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-22 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-22 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-22 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-22 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-22 11:53:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-22 11:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:53:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:53:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:53:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:53:34 --> The upload path does not appear to be valid.
ERROR - 2022-10-22 11:53:34 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1031
ERROR - 2022-10-22 11:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:53:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-22 11:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:53:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-22 11:53:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-22 11:53:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-22 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 264
ERROR - 2022-10-22 11:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 11:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-22 11:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-22 11:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-22 11:59:26 --> The upload path does not appear to be valid.
ERROR - 2022-10-22 11:59:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1031
ERROR - 2022-10-22 12:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 139
ERROR - 2022-10-22 12:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 166
ERROR - 2022-10-22 12:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-10-22 12:02:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 426
ERROR - 2022-10-22 12:02:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 12:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 12:15:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:28:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:30:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:31:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:32:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:33:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:35:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:35:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:36:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:36:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:37:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:37:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:37:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:38:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:39:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:40:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:41:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:41:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:43:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:44:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:46:49 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 980
ERROR - 2022-10-22 12:47:15 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 980
ERROR - 2022-10-22 12:47:16 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 980
ERROR - 2022-10-22 12:47:45 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 980
ERROR - 2022-10-22 12:48:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:49:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:49:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:49:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:50:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:51:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:53:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:53:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:54:17 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 978
ERROR - 2022-10-22 12:54:31 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:55:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:56:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:57:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:58:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 12:58:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 12:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 12:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 12:59:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:02:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:02:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:02:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:03:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:03:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:15:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:15:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:15:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:15:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:16:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:16:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:16:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:21:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:58:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 13:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 13:59:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 14:13:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-22 14:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual_new.php 324
ERROR - 2022-10-22 14:14:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-22 14:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
