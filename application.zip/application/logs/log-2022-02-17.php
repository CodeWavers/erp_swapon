<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 05:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-17 05:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-17 05:17:58 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-17 05:17:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-17 05:17:58 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-17 05:29:00 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `k`.*
FROM `product_information` `a`
LEFT JOIN `products` `k` ON `k`.`barcode` = `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-17 05:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:29:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 05:29:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 05:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 05:30:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:30:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 05:30:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:30:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:30:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 05:30:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 05:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:37:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 05:37:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 05:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 05:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:55:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 05:55:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 05:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 05:55:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:55:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 05:55:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 05:55:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 05:55:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 05:55:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:29:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-17 08:29:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-17 08:29:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-17 08:29:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-17 08:29:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-17 08:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:35:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:35:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:35:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:36:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:36:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:36:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:36:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:36:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:37:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:37:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:37:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:37:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:37:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:37:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:44:13 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 264
ERROR - 2022-02-17 08:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 08:48:35 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 271
ERROR - 2022-02-17 08:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 280
ERROR - 2022-02-17 08:48:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:48:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:48:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:48:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:48:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:48:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:48:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:48:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:48:51 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 271
ERROR - 2022-02-17 08:48:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 280
ERROR - 2022-02-17 08:49:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:49:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:50:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:50:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:50:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:50:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:50:06 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 271
ERROR - 2022-02-17 08:50:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 280
ERROR - 2022-02-17 08:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:53:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:53:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:53:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:53:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:53:48 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 271
ERROR - 2022-02-17 08:53:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 280
ERROR - 2022-02-17 08:54:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:54:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:54:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:54:44 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 271
ERROR - 2022-02-17 08:54:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 280
ERROR - 2022-02-17 08:58:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:58:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 08:58:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 08:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:58:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 08:58:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 08:58:42 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 08:58:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 08:58:44 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 08:58:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 08:58:45 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 08:58:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 09:00:34 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 09:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 09:00:36 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 09:00:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 09:00:37 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 09:00:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 09:00:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 09:00:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 09:00:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 09:00:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 09:00:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 09:00:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 09:00:52 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 245
ERROR - 2022-02-17 09:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 273
ERROR - 2022-02-17 09:02:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 09:02:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-17 09:02:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 09:02:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-17 09:02:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-17 09:02:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-17 09:34:34 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 259
ERROR - 2022-02-17 09:34:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Products.php 268
