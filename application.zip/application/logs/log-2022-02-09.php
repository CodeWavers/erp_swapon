<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-09 04:52:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-09 04:52:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-09 04:52:39 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-09 04:52:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-09 04:52:39 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-09 05:41:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 911
ERROR - 2022-02-09 05:41:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 911
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1410
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 05:41:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 05:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:42:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 05:42:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 05:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 05:42:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:43:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 05:43:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 05:43:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:43:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 05:43:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:46:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:46:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 05:46:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:46:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:46:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 05:46:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 05:47:33 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:47:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:47:33 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:47:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:48:54 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:48:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:48:54 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:48:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:49:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-09 05:50:45 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:50:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:50:45 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:50:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:51:36 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:51:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:51:36 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:51:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:53:18 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:53:18 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:53:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:54:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 05:54:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:54:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:54:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 05:54:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:54:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 05:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 05:55:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 05:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 05:55:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:55:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:59:53 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:59:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:59:53 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:59:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 05:59:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 05:59:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:59:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 05:59:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 05:59:59 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 05:59:59 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 05:59:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 06:00:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:00:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:00:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:00:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:00:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:04:32 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 06:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 06:04:32 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 06:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 06:04:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:04:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:04:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:04:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:04:45 --> Severity: Notice --> Undefined index: color_name C:\laragon\www\git\erp_swapon\application\controllers\Cpurchase.php 190
ERROR - 2022-02-09 06:04:45 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\controllers\Cpurchase.php 190
ERROR - 2022-02-09 06:04:48 --> Severity: Notice --> Undefined index: color_name C:\laragon\www\git\erp_swapon\application\controllers\Cpurchase.php 190
ERROR - 2022-02-09 06:04:48 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\controllers\Cpurchase.php 190
ERROR - 2022-02-09 06:04:56 --> Severity: Notice --> Undefined index: color_name C:\laragon\www\git\erp_swapon\application\controllers\Cpurchase.php 190
ERROR - 2022-02-09 06:04:56 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\controllers\Cpurchase.php 190
ERROR - 2022-02-09 06:05:17 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 06:05:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 06:05:17 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 06:05:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 06:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:05:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:05:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:05:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:05:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:05:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:05:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:06:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:06:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:07:01 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 911
ERROR - 2022-02-09 06:07:01 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 911
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 06:07:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 06:09:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:09:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:09:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:09:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:09:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:09:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:09:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:09:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:09:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:09:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 06:12:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 06:12:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-09 06:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-09 06:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:12:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:12:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:12:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:12:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:12:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:36:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:36:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:36:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:36:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:36:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:36:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 06:36:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 06:36:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 06:36:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 06:36:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 08:47:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 08:47:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-09 08:47:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 08:55:14 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 08:55:15 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 08:55:15 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 08:55:15 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 08:55:15 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 08:55:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 08:55:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:04:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:09:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:13:29 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:16:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 905
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:16:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:16:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:16:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:16:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:16:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:16:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:17:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:17:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:17:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:17:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:17:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:17:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:18:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:18:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:18:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:18:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:18:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:18:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:20:26 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 896
ERROR - 2022-02-09 09:20:26 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 898
ERROR - 2022-02-09 09:20:26 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 899
ERROR - 2022-02-09 09:20:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 905
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:20:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:21:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:21:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:21:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:21:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:21:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:22:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 905
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:24:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:24:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:25:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:25:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:25:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:25:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:25:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:25:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:26:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 09:26:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-09 09:26:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-09 09:26:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:26:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:26:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:26:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:26:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:26:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:26:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:26:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 09:26:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 09:26:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 09:26:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 09:26:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:10:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:10:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:10:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:10:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:39:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:39:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:39:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:39:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:39:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:46:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:46:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:46:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:46:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:46:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:47:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:47:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:47:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:47:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:47:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:47:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 896
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 898
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 899
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 10:47:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 10:48:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:48:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:48:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:48:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:48:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:48:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:48:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:48:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 10:49:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 10:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:49:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:49:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:49:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:55:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:55:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 10:55:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 10:55:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 10:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 10:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:14:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:14:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:14:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:14:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:14:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:18:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:18:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:18:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:18:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:22:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:22:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:22:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:22:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 11:22:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-09 11:22:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:22:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:22:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:46:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:46:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:46:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:46:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:46:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:46:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-09 11:47:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:47:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:47:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:47:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:47:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:38 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:47:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:47:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:47:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:47:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:48:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:48:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:48:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:48:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:30 --> Severity: Notice --> Undefined index: size_name C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 190
ERROR - 2022-02-09 11:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:49:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:49:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:49:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:49:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:49:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:49:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:49:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1168
ERROR - 2022-02-09 11:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:50:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:50:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:50:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:51:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:51:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:51:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:51:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:51:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:51:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:51:07 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 505
ERROR - 2022-02-09 11:51:07 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 11:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 511
ERROR - 2022-02-09 11:51:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:51:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:51:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:51:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:51:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:51:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:52:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:52:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:52:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:14 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 427
ERROR - 2022-02-09 11:52:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 427
ERROR - 2022-02-09 11:52:14 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 433
ERROR - 2022-02-09 11:52:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 433
ERROR - 2022-02-09 11:52:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:52:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:52:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:53:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:53:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:53:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:53:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:53:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:53:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:53:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-09 11:53:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-09 11:53:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-09 11:53:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-09 11:53:33 --> 404 Page Not Found: Assets/js
