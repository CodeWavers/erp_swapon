<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-29 14:10:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3312
ERROR - 2022-10-29 14:10:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3312
ERROR - 2022-10-29 14:10:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3379
ERROR - 2022-10-29 14:10:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3379
ERROR - 2022-10-29 14:10:09 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-29 14:10:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-29 14:10:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-29 14:10:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-29 14:10:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-29 14:10:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-29 14:10:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-29 14:10:44 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 714
ERROR - 2022-10-29 14:10:44 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 714
ERROR - 2022-10-29 14:10:44 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 720
ERROR - 2022-10-29 14:10:44 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 720
ERROR - 2022-10-29 14:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-29 14:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-10-29 14:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-10-29 14:13:37 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-10-29 14:13:37 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-10-29 14:13:37 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-10-29 14:13:37 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-10-29 14:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-29 14:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-29 14:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-29 14:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-29 14:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-29 14:15:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-29 14:17:25 --> Severity: Notice --> Undefined index: percentage C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 794
ERROR - 2022-10-29 14:17:25 --> Severity: Notice --> Undefined index: percentage C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 794
ERROR - 2022-10-29 14:17:37 --> Severity: Notice --> Undefined index: percentage C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 794
ERROR - 2022-10-29 14:17:37 --> Severity: Notice --> Undefined index: percentage C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 794
ERROR - 2022-10-29 14:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:18:41 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 42
ERROR - 2022-10-29 14:18:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-29 14:18:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-29 14:18:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-29 14:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-29 14:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-10-29 14:20:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-10-29 14:20:20 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-10-29 14:20:20 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-10-29 14:20:20 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-10-29 14:20:20 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-10-29 14:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-29 14:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-10-29 14:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-10-29 14:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-29 14:21:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-10-29 14:21:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-10-29 14:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-29 14:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-10-29 14:22:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-10-29 14:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-29 14:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-29 14:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-29 14:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:39:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:39:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-29 14:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-29 14:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-29 14:40:33 --> The upload path does not appear to be valid.
ERROR - 2022-10-29 14:40:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:40:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:40:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:42:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 168
ERROR - 2022-10-29 14:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 740
ERROR - 2022-10-29 14:43:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 746
ERROR - 2022-10-29 14:49:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:49:20 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:50:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:50:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:51:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:51:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-29 14:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-29 14:51:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 168
ERROR - 2022-10-29 14:51:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 740
ERROR - 2022-10-29 14:51:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 746
