<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-03 07:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-08-03 07:12:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-08-03 07:12:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 07:12:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 07:12:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 07:12:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 07:12:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 07:12:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 07:27:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-08-03 07:27:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-08-03 07:27:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 07:27:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 07:27:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 07:27:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 07:27:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 07:27:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 07:41:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 07:42:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 07:48:52 --> Severity: error --> Exception: syntax error, unexpected end of file C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 1032
ERROR - 2022-08-03 07:52:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 07:52:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 07:53:31 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 07:58:24 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 328
ERROR - 2022-08-03 07:58:24 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 328
ERROR - 2022-08-03 07:58:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 08:30:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 15:41:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-03 15:41:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-03 10:05:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:06:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:07:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:08:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:08:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:08:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:08:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 10:08:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:08:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 10:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 10:12:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:13:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:13:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:40:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:40:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 10:40:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 10:40:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:40:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:40:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:40:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 10:42:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:42:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 10:42:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:42:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 10:42:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:42:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 10:42:28 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:42:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:42:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 10:42:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:42:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:42:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 10:42:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 10:44:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:44:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:44:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:44:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 10:44:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 10:44:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 10:44:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 10:52:31 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 10:53:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-03 14:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:42:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 14:42:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 14:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:42:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 14:42:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:42:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 14:42:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:42:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:42:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 14:42:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 14:49:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:49:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 14:49:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 14:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:49:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 14:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:59:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 14:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 14:59:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 14:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 15:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 15:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-03 15:03:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-03 15:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-03 15:03:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-03 15:03:17 --> 404 Page Not Found: Assets/js
