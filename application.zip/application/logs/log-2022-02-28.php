<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-28 05:42:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-28 05:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-28 05:42:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-28 05:42:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-28 05:42:32 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-28 05:45:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:45:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:45:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:45:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:45:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:45:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:49:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:49:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:49:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:49:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:49:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:49:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:51:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:51:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:51:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:51:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:53:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:53:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:53:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:54:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:54:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:54:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:54:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:55:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:55:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:55:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:55:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:55:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:56:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:56:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:56:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:56:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:56:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:56:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:57:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:57:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 05:57:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 05:57:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 05:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 05:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:09:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:09:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:09:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:09:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:09:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:09:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:10:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:10:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:10:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:10:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:10:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:13:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:13:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:13:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:13:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:13:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:13:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:16:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:16:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:16:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:16:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:16:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:22:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:22:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:22:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:22:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:22:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:22:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:23:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:23:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:23:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:23:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:24:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:24:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:24:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:25:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:25:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:26:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:26:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:26:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:26:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:26:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:26:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:29:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:29:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:29:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:29:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:29:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:29:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:29:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:29:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:29:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:29:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:29:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:29:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:30:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:30:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:30:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:30:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:30:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:30:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:30:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:30:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:30:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:31:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:31:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:31:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:38:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:38:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:38:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:38:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:38:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:38:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:40:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:40:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:40:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:40:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:40:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:41:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:41:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:41:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:41:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:41:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:41:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:41:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:41:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:41:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:41:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:41:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:45:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:45:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:45:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:45:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:45:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:45:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:46:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:46:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:46:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:46:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:46:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:46:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:46:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:46:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:46:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:46:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:46:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:46:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:47:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:47:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:47:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:47:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:47:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:47:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:47:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:47:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:47:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:47:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:48:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:48:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:48:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:48:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:48:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:48:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:48:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:48:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:48:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:48:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:48:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 06:50:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 06:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 06:50:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 06:50:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:03:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:03:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 07:03:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 07:03:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:03:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 07:03:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:23:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:23:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 07:23:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 07:23:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:23:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 07:23:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 07:25:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 07:25:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 07:25:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 07:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:25:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 07:25:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 07:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 07:26:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:26:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 07:26:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 07:26:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:26:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:26:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 07:26:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 07:26:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:26:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 07:26:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 07:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 406
ERROR - 2022-02-28 07:40:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 406
ERROR - 2022-02-28 08:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:37:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:37:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:37:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:37:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:37:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:37:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:37:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:37:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:37:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:38:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:38:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:38:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:38:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:50:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:50:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:50:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:50:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:50:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:50:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:50:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:50:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:03 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 08:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:51:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:51:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:51:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:21 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 08:51:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:51:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 08:51:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:51:41 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 08:51:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 08:51:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 08:51:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 08:51:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:03:48 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:03:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:03:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:03:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:03:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:03:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:03:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:04:44 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:04:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:04:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:05:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:05:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:06:29 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:06:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:06:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:07:09 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:07:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:07:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:14:34 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:14:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:14:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:14:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:14:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:14:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:14:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:14:54 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:14:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:15:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:15:06 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:15:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:15:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:15:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:15:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:15:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:15:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:17:25 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:17:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:17:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:17:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:17:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:17:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:17:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:18:14 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:18:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:18:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:18:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:18:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:18:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:18:56 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 09:18:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:18:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 09:18:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 09:18:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 09:18:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 09:18:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:50:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-28 14:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-28 14:50:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-28 14:50:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-28 14:50:49 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-28 14:51:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:51:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 14:51:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:51:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 14:51:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 14:51:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:52:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:52:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 14:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:52:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 14:52:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 14:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 14:53:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 14:53:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:53:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 14:53:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:54:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 14:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:54:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 14:54:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 14:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:55:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 14:55:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 14:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 14:55:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:57:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 14:57:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 14:57:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 14:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 14:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:00:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:00:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:00:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:00:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:03:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:03:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:03:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:03:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:03:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:04:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:04:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:04:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:04:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:04:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:04:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:04:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:04:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:04:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:04:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:05:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:05:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:05:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:05:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:05:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:05:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:07:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:07:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:07:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:07:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:20:10 --> Severity: Notice --> Trying to get property 'orderDetails' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 291
ERROR - 2022-02-28 15:20:10 --> Severity: error --> Exception: Call to a member function where() on null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 291
ERROR - 2022-02-28 15:21:29 --> Severity: error --> Exception: Call to a member function where() on array C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 291
ERROR - 2022-02-28 15:31:49 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-02-28 15:33:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:33:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:33:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:33:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:33:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:33:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:34:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:34:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:34:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:34:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:34:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:34:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:34:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:34:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:55:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:55:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:55:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:55:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:55:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:55:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:56:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:56:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:56:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:56:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:57:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:57:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:57:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:57:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:57:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:57:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:58:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:58:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 15:58:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 15:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 15:58:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 15:58:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:00:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:00:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:00:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:00:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:00:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:00:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:01:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:01:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:03:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:03:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:03:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:03:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:03:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:03:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:07:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:07:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:07:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:07:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:07:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:07:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:12:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:12:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:12:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-28 16:12:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-28 16:12:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-28 16:12:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 124
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 124
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 131
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 132
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 133
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 134
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 135
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 137
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 139
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 181
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 181
ERROR - 2022-02-28 16:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 220
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-02-28 16:41:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-02-28 16:41:18 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-02-28 16:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 410
ERROR - 2022-02-28 16:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 443
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-02-28 16:41:18 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 124
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 124
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 131
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 132
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 133
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 134
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 135
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 136
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 137
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 138
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 139
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 164
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 172
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 181
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 181
ERROR - 2022-02-28 16:41:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 220
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 269
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 270
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 274
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 278
ERROR - 2022-02-28 16:41:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-02-28 16:41:50 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 299
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 307
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 317
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 324
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 339
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 383
ERROR - 2022-02-28 16:41:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 410
ERROR - 2022-02-28 16:41:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 443
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
ERROR - 2022-02-28 16:41:50 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 483
