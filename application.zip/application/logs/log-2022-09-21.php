<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-21 10:11:19 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 10:12:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:12:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:12:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:12:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:12:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:12:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:12:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:13:58 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 10:14:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:14:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:14:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:15:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:15:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:15:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:15:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:15:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:15:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:18:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:19:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:19:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:19:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:19:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:19:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:19:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:19:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:19:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:20:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:20:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:20:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:20:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:20:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:22:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:22:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:22:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:22:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:22:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:22:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:23:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:23:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:23:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:23:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:25:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:25:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:25:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:25:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:26:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:26:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:26:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:26:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:26:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:26:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:26:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:26:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:26:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:26:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:27:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:27:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:27:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:27:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:27:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:27:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:29:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:29:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:29:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:29:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:29:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 10:29:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 10:29:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 10:29:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 10:29:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 11:17:04 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 11:41:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 11:42:41 --> Query error: Column 'mid' cannot be null - Invalid query: INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-09-21 11:45:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 11:45:28 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 11:45:44 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 11:48:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 11:56:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 11:56:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 11:56:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 11:56:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 11:56:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 11:56:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 11:56:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 12:10:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:10:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:11:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:18:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:18:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 20
ERROR - 2022-09-21 12:25:03 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 13:02:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 13:03:12 --> Query error: Unknown column 'b.supplier_price' in 'field list' - Invalid query: SELECT *, `b`.`supplier_price`
FROM `product_information` `a`
ORDER BY `a`.`id`
ERROR - 2022-09-21 13:03:12 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1483
ERROR - 2022-09-21 13:07:05 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 13:17:12 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-21 14:16:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 144
ERROR - 2022-09-21 14:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 144
ERROR - 2022-09-21 14:48:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 224
ERROR - 2022-09-21 14:48:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-21 14:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 224
ERROR - 2022-09-21 14:48:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-21 14:49:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 224
ERROR - 2022-09-21 14:49:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-21 15:27:56 --> Query error: Column 'mid' cannot be null - Invalid query: INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-09-21 16:15:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 975
ERROR - 2022-09-21 16:22:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 975
ERROR - 2022-09-21 16:23:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 16:23:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 16:23:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 16:23:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 16:23:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 16:23:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 16:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 16:44:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-21 16:44:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 16:44:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-21 16:44:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-21 16:44:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-21 16:59:51 --> Query error: Unknown column 'b.product_name' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `b`.`unit`
FROM `pr_rqsn_details` `a`
JOIN `pr_rqsn_details` `b` ON `a`.`product_id`=`b`.`product_id`
ERROR - 2022-09-21 16:59:51 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Production.php 495
ERROR - 2022-09-21 17:00:07 --> Query error: Unknown column 'b.product_name' in 'field list' - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`sku`, `b`.`unit`
FROM `pr_rqsn_details` `a`
JOIN `pr_rqsn_details` `b` ON `a`.`product_id`=`b`.`product_id`
ERROR - 2022-09-21 17:03:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-09-21 17:03:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-09-21 17:03:57 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1750
ERROR - 2022-09-21 17:04:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-09-21 17:04:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-09-21 17:04:09 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1750
ERROR - 2022-09-21 17:04:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-09-21 17:04:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-09-21 17:04:18 --> Severity: Notice --> Undefined variable: draw C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1750
ERROR - 2022-09-21 17:04:22 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 312
ERROR - 2022-09-21 17:04:22 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 312
ERROR - 2022-09-21 17:04:22 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 312
ERROR - 2022-09-21 17:19:38 --> Severity: Notice --> Undefined property: Lproduction::$db C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 318
ERROR - 2022-09-21 17:19:38 --> Severity: error --> Exception: Call to a member function select() on null C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 318
ERROR - 2022-09-21 17:19:57 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 239
ERROR - 2022-09-21 17:20:20 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 239
ERROR - 2022-09-21 17:20:27 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\system\libraries\Parser.php 239
ERROR - 2022-09-21 17:44:05 --> Severity: error --> Exception: syntax error, unexpected '}' C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 328
