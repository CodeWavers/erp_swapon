<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-29 05:03:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-29 05:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-29 05:03:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-29 05:03:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-29 05:03:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 212
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 212
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 213
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 213
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-29 05:03:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-29 05:03:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-29 05:03:15 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-29 05:09:29 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 303
ERROR - 2022-03-29 05:09:29 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 303
ERROR - 2022-03-29 05:09:29 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 305
ERROR - 2022-03-29 05:09:29 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 305
ERROR - 2022-03-29 09:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-29 09:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-29 09:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-29 09:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-29 09:47:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:47:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:47:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:47:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:49:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:49:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:49:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:49:29 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-29 09:49:29 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-29 09:49:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:49:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:49:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-29 09:49:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:49:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:49:46 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-29 09:49:46 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-29 09:49:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:49:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:49:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-29 09:51:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:51:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:51:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:51:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:51:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:51:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to get property 'customer_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 880
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 882
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to get property 'customer_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 883
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-03-29 09:51:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-03-29 09:52:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:52:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:52:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:52:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:52:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:52:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:52:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-29 09:53:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:53:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:53:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:53:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:53:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:53:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:53:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:53:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:54:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-29 09:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-29 09:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-29 09:54:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-29 09:54:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
