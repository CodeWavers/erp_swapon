<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-21 04:37:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-21 04:37:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-21 04:37:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-21 04:37:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-21 04:37:51 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-21 05:13:52 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-21 05:13:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-21 05:13:52 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-21 05:13:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-21 05:13:52 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-21 05:13:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-21 05:14:12 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 05:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 05:14:12 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 05:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 118
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 118
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 140
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 140
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 147
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 148
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 149
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 150
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 154
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 155
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 157
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 157
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 166
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 166
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 174
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 174
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 222
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 282
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 282
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 283
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 283
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 287
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 287
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 291
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 291
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 304
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 306
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 306
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 313
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 313
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 321
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 321
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 331
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 338
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 338
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 345
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 345
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 346
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 346
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 354
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 354
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 355
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 355
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 366
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 366
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 379
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 379
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 400
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 400
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 401
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 401
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 430
ERROR - 2022-03-21 06:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 463
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 503
ERROR - 2022-03-21 06:13:30 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 503
ERROR - 2022-03-21 06:23:26 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 06:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 06:23:26 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:27:02 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 06:27:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 06:27:02 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:27:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:28:12 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 06:28:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-21 06:28:12 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:28:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-21 06:49:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 06:49:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 06:49:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 06:49:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 06:49:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 06:49:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 06:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 06:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 06:52:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 06:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 06:52:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 06:52:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:05:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:05:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:05:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:05:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:05:12 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 07:05:12 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 07:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:05:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:05:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:05:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:05:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:08:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:08:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:08:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:08:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:08:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:08:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:09:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:09:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:09:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:09:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:09:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:10:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:10:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:11:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:11:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:11:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:11:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:11:32 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 07:11:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:11:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:11:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:11:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:15:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:15:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:15:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:15:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:15:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:16:02 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 07:16:02 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 07:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 07:16:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 07:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 07:16:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 07:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:22:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:22:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:22:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:22:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:23:27 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 08:23:27 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 209
ERROR - 2022-03-21 08:23:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:23:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:23:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:23:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:28:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:28:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:28:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:28:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:28:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:28:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:28:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:28:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:43:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:43:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:43:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:43:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:43:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:43:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:44:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:44:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:44:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:44:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:44:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:44:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:46:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:46:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:46:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:49:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:49:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:49:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:49:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:49:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:49:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:49:36 --> 404 Page Not Found: Crqsn/item_finalize
ERROR - 2022-03-21 08:50:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:50:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:50:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:50:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:50:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:50:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:51:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:51:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:51:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:51:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:51:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:51:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:53:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:53:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:53:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:53:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:53:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:54:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:54:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:54:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:54:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:54:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:56:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:56:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:56:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:56:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:56:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:56:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:57:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:57:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:57:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:57:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:57:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:57:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:57:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:57:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 08:57:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 08:57:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 08:57:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 08:57:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:01:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:01:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:01:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:01:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:01:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:02:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:02:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:02:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:02:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:02:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:03:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:03:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:03:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:03:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:03:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:05:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:05:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:05:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:05:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:05:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:05:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:05:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:05:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:05:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:05:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:07:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:07:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:07:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:07:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:07:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:07:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:07:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:10:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:11:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:11:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:11:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:11:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:14:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:14:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:14:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:14:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:15:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:15:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:15:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:15:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:17:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:17:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:17:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:17:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:17:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:17:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:17:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:17:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:17:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:19:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-21 09:19:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-21 09:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 375
ERROR - 2022-03-21 09:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\item_finalize.php 70
ERROR - 2022-03-21 09:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:27:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:27:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:27:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:28:18 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 211
ERROR - 2022-03-21 09:28:18 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 211
ERROR - 2022-03-21 09:28:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:28:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:28:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:28:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:28:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:28:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:29:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:29:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:29:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:29:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:29:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:29:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:33:46 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 09:33:46 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 09:33:46 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 09:34:22 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 09:34:22 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 09:34:22 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 09:34:23 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 259
ERROR - 2022-03-21 09:34:23 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 211
ERROR - 2022-03-21 09:34:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:34:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:34:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:37:07 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 09:37:07 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 09:37:07 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 09:37:26 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 09:37:26 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 09:37:26 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 09:37:42 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 259
ERROR - 2022-03-21 09:37:42 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 211
ERROR - 2022-03-21 09:37:49 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 09:37:49 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 09:37:49 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 09:38:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:38:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:38:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:38:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:38:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:38:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:38:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:38:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:38:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:38:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:38:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:38:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:40:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:40:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:40:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:40:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 09:40:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:41:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:41:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 09:41:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 09:41:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:41:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 09:41:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:01:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:01:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:01:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:05:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:05:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:05:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:05:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:05:42 --> Severity: Notice --> Undefined index: variation C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 703
ERROR - 2022-03-21 10:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:05:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:05:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:05:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:05:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:28:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:28:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:28:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:28:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:28:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:28:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:28:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:28:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:28:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:28:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:28:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:29:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:29:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:29:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:29:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:29:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:29:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:30:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:30:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:30:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:30:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:30:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:30:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:31:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:31:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:31:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:31:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:35:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:35:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:35:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:37:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:37:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:38:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:38:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:38:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:58:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:58:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:59:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:59:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:59:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:59:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:59:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 10:59:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 10:59:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 10:59:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 10:59:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:00:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:00:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:00:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:00:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:00:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:08:28 --> Severity: Notice --> Undefined index: variation C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 703
ERROR - 2022-03-21 11:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:50:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:50:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:50:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:50:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:50:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:50:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:50:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:50:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:50:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:50:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:50:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:51:25 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 11:51:25 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 11:51:25 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 11:51:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:51:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:51:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:51:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:51:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:51:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:52:16 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 11:52:16 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 11:52:16 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 11:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:52:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:52:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:52:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:47 --> Severity: Notice --> Undefined property: stdClass::$thana C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-21 11:52:47 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-21 11:52:47 --> Severity: Notice --> Undefined property: stdClass::$district C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-21 11:52:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:52:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:52:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:52:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-21 11:52:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-21 11:52:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-21 11:52:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-21 11:52:59 --> 404 Page Not Found: Assets/js
