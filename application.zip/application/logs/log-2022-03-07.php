<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-07 05:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:32:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:32:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:32:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:32:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:32:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-07 05:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-07 05:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-07 05:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-07 05:32:15 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-07 05:32:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:32:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:37:49 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 05:37:49 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 05:37:49 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 05:37:49 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 300
ERROR - 2022-03-07 05:40:01 --> Severity: Notice --> Undefined variable: closing_inventory C:\laragon\www\git\erp_swapon\application\models\Reports.php 428
ERROR - 2022-03-07 05:40:14 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:40:14 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:43:16 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:43:16 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:43:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:43:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:43:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:43:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:43:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:43:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:43:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:46:31 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:46:31 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:46:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:46:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:46:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:46:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:51:15 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:51:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:51:15 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:51:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:51:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:51:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:51:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:51:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:51:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:51:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:55:24 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:55:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:55:24 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:55:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:55:36 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\git\erp_swapon\application\models\Suppliers.php 254
ERROR - 2022-03-07 05:55:37 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\git\erp_swapon\application\models\Suppliers.php 254
ERROR - 2022-03-07 05:55:38 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\git\erp_swapon\application\models\Suppliers.php 254
ERROR - 2022-03-07 05:55:40 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\git\erp_swapon\application\models\Suppliers.php 254
ERROR - 2022-03-07 05:55:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:55:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:55:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:55:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:55:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:55:49 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\git\erp_swapon\application\models\Suppliers.php 254
ERROR - 2022-03-07 05:55:50 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::num_rows() C:\laragon\www\git\erp_swapon\application\models\Suppliers.php 254
ERROR - 2022-03-07 05:56:57 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Purchases.php 370
ERROR - 2022-03-07 05:56:57 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220307055655', 'Purchase', '2022-03-07', NULL, 'Supplier .Factory', 0, '10000.00', 1, 'OpSoxJvBbbS8Rws', '2022-03-07', 1)
ERROR - 2022-03-07 05:59:10 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:59:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:59:10 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:59:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:59:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:59:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:59:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:59:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:59:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:59:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:59:13 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:59:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 05:59:13 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:59:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 05:59:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 05:59:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 05:59:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:59:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 05:59:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 05:59:42 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Purchases.php 370
ERROR - 2022-03-07 05:59:42 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220307055942', 'Purchase', '2022-03-07', NULL, 'Supplier .Imported', 0, '100.00', 1, 'OpSoxJvBbbS8Rws', '2022-03-07', 1)
ERROR - 2022-03-07 06:02:01 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 06:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 06:02:01 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 06:02:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 06:03:00 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:03:00 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:03:00 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:03:00 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 300
ERROR - 2022-03-07 06:03:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:03:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:03:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:03:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:03:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:03:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:03:11 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:03:11 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:03:11 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:03:11 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 300
ERROR - 2022-03-07 06:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:03:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:03:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:03:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:03:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:04:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:04:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:04:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:04:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:04:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:04:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:05:03 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:05:03 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:05:03 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:05:03 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 300
ERROR - 2022-03-07 06:05:10 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:05:10 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 290
ERROR - 2022-03-07 06:05:10 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:05:10 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 300
ERROR - 2022-03-07 06:05:10 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 303
ERROR - 2022-03-07 06:05:10 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 307
ERROR - 2022-03-07 06:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:07:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:07:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:07:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:07:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:14:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:14:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:14:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:14:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:14:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:15:33 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:15:33 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:15:33 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 294
ERROR - 2022-03-07 06:23:37 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:23:37 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 292
ERROR - 2022-03-07 06:23:37 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 294
ERROR - 2022-03-07 06:23:37 --> Severity: Notice --> Undefined variable: rcv_qty C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 294
ERROR - 2022-03-07 06:23:37 --> Severity: Notice --> Trying to get property 'rc_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 294
ERROR - 2022-03-07 06:26:32 --> Severity: Notice --> Undefined variable: quantity C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 301
ERROR - 2022-03-07 06:26:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:26:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:27:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:27:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:27:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:27:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:28:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:28:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:28:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:28:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:30:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:30:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:30:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:30:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:30:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:30:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:31:20 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 294
ERROR - 2022-03-07 06:32:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:32:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:32:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:32:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:32:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:32:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:32:21 --> Severity: Notice --> Undefined variable: quantity C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 304
ERROR - 2022-03-07 06:33:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:33:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:34:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:34:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:34:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Production.php 1159
ERROR - 2022-03-07 06:34:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:34:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:34:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:34:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:34:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:37:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:37:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:37:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:37:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:37:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:37:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-07 06:37:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-07 06:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-07 06:37:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-07 06:44:48 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 201
ERROR - 2022-03-07 08:29:23 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 201
ERROR - 2022-03-07 08:33:12 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 201
ERROR - 2022-03-07 10:12:17 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 10:12:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-07 10:12:17 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 10:12:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-07 11:52:30 --> Severity: error --> Exception: Too few arguments to function CI_DB_result::custom_result_object(), 0 passed in C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php on line 345 and exactly 1 expected C:\laragon\www\git\erp_swapon\system\database\DB_result.php 178
ERROR - 2022-03-07 11:53:18 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:53:20 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:00 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:01 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:01 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:01 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:01 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:02 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:02 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:02 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:55:02 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:56:34 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 308
ERROR - 2022-03-07 11:56:34 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 312
ERROR - 2022-03-07 11:57:20 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
ERROR - 2022-03-07 11:57:56 --> Severity: error --> Exception: Call to a member function custom_result_object() on array C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 346
