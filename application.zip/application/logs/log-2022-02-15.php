<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-15 06:53:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-15 06:53:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-15 06:53:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-15 06:53:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-15 06:53:47 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-15 07:28:43 --> 404 Page Not Found: Cproduct/manage_finished_product
ERROR - 2022-02-15 08:47:57 --> Severity: error --> Exception: Call to undefined function api_url() C:\laragon\www\git\erp_swapon\application\views\product\finished_product.php 97
ERROR - 2022-02-15 08:52:00 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:01 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:02 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:02 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:02 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:02 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:03 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:03 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:03 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:03 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:03 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:03 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:04 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:04 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:04 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:04 --> Severity: error --> Exception: Call to undefined method CI_Config::api() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:13 --> Severity: error --> Exception: Call to undefined method CI_Config::api_url() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:14 --> Severity: error --> Exception: Call to undefined method CI_Config::api_url() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:14 --> Severity: error --> Exception: Call to undefined method CI_Config::api_url() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:14 --> Severity: error --> Exception: Call to undefined method CI_Config::api_url() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:15 --> Severity: error --> Exception: Call to undefined method CI_Config::api_url() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 08:52:18 --> Severity: error --> Exception: Call to undefined method CI_Config::api_url() C:\laragon\www\git\erp_swapon\system\helpers\url_helper.php 91
ERROR - 2022-02-15 11:08:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-15 11:08:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-15 11:08:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-15 11:08:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-15 11:08:15 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-15 11:16:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:16:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:16:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:16:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:16:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:16:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:16:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:16:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:16:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:17:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:17:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:17:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:17:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:17:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:17:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:20:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:20:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:20:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:20:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:20:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:20:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:35:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:47 --> Severity: Warning --> Use of undefined constant data - assumed 'data' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\models\Products.php 332
ERROR - 2022-02-15 11:35:47 --> Severity: Warning --> Illegal string offset 'data' C:\laragon\www\git\erp_swapon\application\models\Products.php 332
ERROR - 2022-02-15 11:35:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:35:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:35:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:35:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:35:58 --> Severity: Warning --> Illegal string offset 'data' C:\laragon\www\git\erp_swapon\application\models\Products.php 332
ERROR - 2022-02-15 11:36:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:36:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:36:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:36:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:37:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:37:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:37:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:37:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:40:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:40:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:40:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:40:18 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 333
ERROR - 2022-02-15 11:40:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:40:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:41:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:41:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:41:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:41:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:41:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:41:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:42:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:42:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:42:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:42:19 --> Severity: Notice --> Trying to get property 'data' of non-object C:\laragon\www\git\erp_swapon\application\models\Products.php 333
ERROR - 2022-02-15 11:42:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Products.php 333
ERROR - 2022-02-15 11:42:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:42:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:42:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:42:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:42:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:43:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:43:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:43:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:47:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:47:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:47:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:47:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:47:57 --> Query error: Unknown column 'name' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `a`.`finished_raw`, `a`.`image`, `c`.`supplier_price`, `c`.`supplier_id`, `m`.`supplier_name`, `k`.`color_name`, `l`.`size_name`, `x`.`category_name`, `d`.*
FROM `product_information` `a`
LEFT JOIN `supplier_product` `c` ON `c`.`product_id` = `a`.`product_id`
LEFT JOIN `product_category` `x` ON `x`.`category_id` = `a`.`category_id`
LEFT JOIN `product_type` `d` ON `d`.`ptype_id` = `a`.`ptype_id`
LEFT JOIN `color_list` `k` ON `k`.`color_id` = `a`.`color`
LEFT JOIN `size_list` `l` ON `l`.`size_id` = `a`.`size`
LEFT JOIN `supplier_information` `m` ON `m`.`supplier_id` = `c`.`supplier_id`
ORDER BY `name` ASC
 LIMIT 10
ERROR - 2022-02-15 11:49:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:49:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:49:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:49:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:49:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:49:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:49:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:49:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:49:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-15 11:49:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:49:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:49:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:50:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:50:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-15 11:50:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:50:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-15 11:50:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-15 11:50:24 --> 404 Page Not Found: Assets/plugins
