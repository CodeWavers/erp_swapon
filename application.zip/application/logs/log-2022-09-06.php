<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-06 05:56:18 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-06 06:37:06 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-06 06:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 191
ERROR - 2022-09-06 06:37:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-06 06:38:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 191
ERROR - 2022-09-06 06:38:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-06 06:38:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 191
ERROR - 2022-09-06 06:38:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-06 06:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 188
ERROR - 2022-09-06 06:39:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 71
ERROR - 2022-09-06 06:39:37 --> Severity: error --> Exception: Too few arguments to function reports::manage_stock_taking(), 0 passed in C:\laragon\www\git\erp_swapon\application\controllers\Creport.php on line 181 and exactly 1 expected C:\laragon\www\git\erp_swapon\application\models\Reports.php 226
ERROR - 2022-09-06 06:40:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-06 06:41:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-06 06:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:43:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:43:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:44:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:44:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:44:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:44:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:44:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:44:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:44:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:44:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:44:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:44:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:44:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:44:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:44:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:51:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:51:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:51:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:52:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:52:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:52:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:52:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:52:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:52:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:53:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:53:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:53:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:53:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:53:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:53:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:54:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:54:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:54:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:54:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:54:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:54:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:54:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:54:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:54:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:54:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:55:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:55:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:55:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:55:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:56:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:56:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:56:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:56:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:56:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:56:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:57:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:57:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:57:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:57:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:57:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:57:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:58:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 06:58:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 06:58:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 06:58:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 06:58:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 08:13:52 --> The upload path does not appear to be valid.
ERROR - 2022-09-06 08:13:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `paid_amount` (`invoice_id`, `pay_type`, `amount`, `account`, `COAID`, `pay_date`, `status`) VALUES ('7719335978', '4', '300', 'Jabah bank', NULL, '2022-09-06', 1)
ERROR - 2022-09-06 08:13:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7719335978', 'INVOICE', '2022-09-06', NULL, 'Paid amount for customer  Invoice ID - 7719335978 customer -Md Arman Ullah', '300', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-06 08:13:52', 1)
ERROR - 2022-09-06 08:13:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `paid_amount` (`invoice_id`, `pay_type`, `amount`, `pay_date`, `account`, `COAID`, `status`) VALUES ('7719335978', '5', '500', '2022-09-06', '01881239392', NULL, 1)
ERROR - 2022-09-06 08:13:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7719335978', 'INVOICE', '2022-09-06', NULL, 'Cash in Nagad paid amount for customer  Invoice ID - 7719335978 customer -Md Arman Ullah', '500', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-06 08:13:52', 1)
ERROR - 2022-09-06 08:13:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `paid_amount` (`invoice_id`, `pay_type`, `amount`, `account`, `pay_date`, `COAID`, `status`) VALUES ('7719335978', '6', '600', NULL, '2022-09-06', NULL, 1)
ERROR - 2022-09-06 08:13:52 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7719335978', 'INVOICE', '2022-09-06', NULL, 'Paid amount for customer in card -   Invoice ID - 7719335978 customer -Md Arman Ullah', 600, 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-06 08:13:52', 1)
ERROR - 2022-09-06 08:13:56 --> 404 Page Not Found: Cinvoice/Cinvoice
ERROR - 2022-09-06 08:28:36 --> The upload path does not appear to be valid.
ERROR - 2022-09-06 08:37:05 --> The upload path does not appear to be valid.
ERROR - 2022-09-06 09:40:32 --> The upload path does not appear to be valid.
ERROR - 2022-09-06 15:45:08 --> The upload path does not appear to be valid.
ERROR - 2022-09-06 16:05:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:05:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 16:05:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:05:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 16:05:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:05:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 16:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 16:07:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 16:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:07:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 16:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:07:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 16:07:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 16:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:07:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:07:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 16:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:11:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 16:11:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 16:11:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:11:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:11:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 16:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:31:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-06 16:31:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-06 16:31:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-06 16:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-06 16:45:39 --> The upload path does not appear to be valid.
ERROR - 2022-09-06 16:54:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\git\erp_swapon\application\views\invoice\pos_dell_arte_invoice_html_manual.php 373
ERROR - 2022-09-06 17:05:23 --> The upload path does not appear to be valid.
