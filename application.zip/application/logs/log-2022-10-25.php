<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-25 22:33:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3312
ERROR - 2022-10-25 22:33:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3312
ERROR - 2022-10-25 22:33:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3379
ERROR - 2022-10-25 22:33:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3379
ERROR - 2022-10-25 22:33:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-25 22:46:18 --> Severity: error --> Exception: syntax error, unexpected 'sl' (T_STRING), expecting ';' or ',' C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 793
ERROR - 2022-10-25 22:46:43 --> Severity: error --> Exception: syntax error, unexpected 'rds' (T_STRING), expecting ']' C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 798
ERROR - 2022-10-25 22:46:45 --> Severity: error --> Exception: syntax error, unexpected 'rds' (T_STRING), expecting ']' C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 798
ERROR - 2022-10-25 22:48:00 --> Severity: error --> Exception: syntax error, unexpected 'rds' (T_STRING), expecting ']' C:\laragon\www\git\erp_swapon\application\libraries\Lsettings.php 798
