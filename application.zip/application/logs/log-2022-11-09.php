<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-09 10:42:08 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 11:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-09 11:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-09 11:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-09 11:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-09 12:16:25 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-11-09 12:16:25 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES (21934410, 'Stock Taking', '2022-11-09', 201, 'Stock Taking For STID -  21934410', Array, 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09', 1)
ERROR - 2022-11-09 12:17:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 216
ERROR - 2022-11-09 12:17:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 216
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1447
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1447
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Undefined variable: arr_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1579
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1580
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1581
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1229
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 327
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 328
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 329
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 330
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 330
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 330
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 331
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 332
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 332
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 332
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-11-09 12:28:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 333
ERROR - 2022-11-09 12:46:13 --> Severity: Error --> Allowed memory size of 536870912 bytes exhausted (tried to allocate 2097160 bytes) C:\laragon\www\git\erp_swapon\application\models\Reports.php 857
ERROR - 2022-11-09 12:47:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 139
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 166
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 195
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 283
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 325
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 378
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 402
ERROR - 2022-11-09 12:48:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 426
ERROR - 2022-11-09 12:48:45 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 13:18:16 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 13:19:20 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 13:20:48 --> 404 Page Not Found: Csettings/rocket
ERROR - 2022-11-09 14:40:34 --> Severity: error --> Exception: Call to undefined method Lsettings::bkash_rocket_by_id() C:\laragon\www\git\erp_swapon\application\controllers\Csettings.php 941
ERROR - 2022-11-09 14:41:40 --> 404 Page Not Found: Csettings/rocket_transaction
ERROR - 2022-11-09 14:47:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('65465465', 'Rocket Transaction', '2022-11-09', NULL, '', '2000', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 14:47:02', 1)
ERROR - 2022-11-09 14:50:55 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('45654654', 'Rocket Transaction', '2022-11-09', NULL, '', '6788', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 14:50:55', 1)
ERROR - 2022-11-09 15:12:15 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('23432432423', 'Rocket Transaction', '2022-11-09', NULL, '44', '4000', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 15:12:15', 1)
ERROR - 2022-11-09 15:20:43 --> 404 Page Not Found: Csettings/rocket_ledger
ERROR - 2022-11-09 15:29:12 --> 404 Page Not Found: Csettings/rocket_ledger
ERROR - 2022-11-09 15:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\settings\rocket_ledger.php 45
ERROR - 2022-11-09 15:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\settings\rocket_ledger.php 45
ERROR - 2022-11-09 15:44:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-09 15:44:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-09 15:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 15:50:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 15:57:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 15:57:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 15:57:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 745
ERROR - 2022-11-09 15:57:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 15:57:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 15:57:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 745
ERROR - 2022-11-09 15:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 15:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 15:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 745
ERROR - 2022-11-09 15:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 15:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 15:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 745
ERROR - 2022-11-09 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:00:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 745
ERROR - 2022-11-09 16:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:03:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:11:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:11:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:21:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:21:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:22:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1307
ERROR - 2022-11-09 16:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1307
ERROR - 2022-11-09 16:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-09 16:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-09 16:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-09 16:22:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-09 16:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:26:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 16:28:27 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 16:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 516
ERROR - 2022-11-09 16:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 522
ERROR - 2022-11-09 16:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 538
ERROR - 2022-11-09 16:28:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 544
ERROR - 2022-11-09 16:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:30:16 --> The upload path does not appear to be valid.
ERROR - 2022-11-09 16:30:16 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8461762537', 'INVOICE', '2022-11-09', NULL, 'Cash in Nagad paid amount for customer  Invoice ID - 8461762537 customer -Walking Customer', '200', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 16:30:16', 1)
ERROR - 2022-11-09 16:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 16:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:34:47 --> The upload path does not appear to be valid.
ERROR - 2022-11-09 16:34:47 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4758781684', 'INVOICE', '2022-11-09', NULL, 'Cash in Rocket  paid amount for customer  Invoice ID - 4758781684 customer -Walking Customer', '1000', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 16:34:47', 1)
ERROR - 2022-11-09 16:34:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 16:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:37:26 --> The upload path does not appear to be valid.
ERROR - 2022-11-09 16:37:26 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4137176186', 'INVOICE', '2022-11-09', NULL, 'Cash in Rocket  paid amount for customer  Invoice ID - 4137176186 customer -Walking Customer', '400', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 16:37:26', 1)
ERROR - 2022-11-09 16:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 16:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:40:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:41:03 --> The upload path does not appear to be valid.
ERROR - 2022-11-09 16:41:03 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3642861644', 'INVOICE', '2022-11-09', NULL, 'Cash in Bkash paid amount for customer  Invoice ID - 3642861644 customer -Walking Customer', '132', 0, 1, 'OpSoxJvBbbS8Rws', '2022-11-09 16:41:03', 1)
ERROR - 2022-11-09 16:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 16:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:45:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:45:57 --> The upload path does not appear to be valid.
ERROR - 2022-11-09 16:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 16:48:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 16:49:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 742
ERROR - 2022-11-09 16:49:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 748
ERROR - 2022-11-09 16:49:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 742
ERROR - 2022-11-09 16:49:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 748
ERROR - 2022-11-09 16:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 743
ERROR - 2022-11-09 16:50:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 749
ERROR - 2022-11-09 16:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 683
ERROR - 2022-11-09 16:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 689
ERROR - 2022-11-09 16:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-11-09 16:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-11-09 16:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 723
ERROR - 2022-11-09 16:53:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 729
ERROR - 2022-11-09 16:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 683
ERROR - 2022-11-09 16:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 689
ERROR - 2022-11-09 16:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-11-09 16:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-11-09 16:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-09 16:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-09 16:54:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-09 16:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-09 16:54:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-09 16:54:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-09 16:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 683
ERROR - 2022-11-09 16:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 689
ERROR - 2022-11-09 16:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-11-09 16:54:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-11-09 16:54:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-09 16:54:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-09 16:54:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-09 16:54:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-09 16:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-09 16:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-09 17:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 683
ERROR - 2022-11-09 17:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 689
ERROR - 2022-11-09 17:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 705
ERROR - 2022-11-09 17:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 711
ERROR - 2022-11-09 17:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 691
ERROR - 2022-11-09 17:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 697
ERROR - 2022-11-09 17:20:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 624
ERROR - 2022-11-09 17:20:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 630
ERROR - 2022-11-09 17:20:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 713
ERROR - 2022-11-09 17:20:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 719
ERROR - 2022-11-09 17:24:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 713
ERROR - 2022-11-09 17:24:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 719
ERROR - 2022-11-09 17:24:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 17:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 17:24:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-09 17:24:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-09 17:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 283
ERROR - 2022-11-09 17:35:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 283
ERROR - 2022-11-09 17:38:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 283
ERROR - 2022-11-09 17:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-11-09 17:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-11-09 17:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-11-09 22:39:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-09 22:42:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 283
ERROR - 2022-11-09 22:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-11-09 22:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-11-09 22:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-11-09 22:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-11-09 22:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-11-09 22:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-11-09 22:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-11-09 22:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-11-09 22:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-11-09 22:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-11-09 22:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-11-09 22:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-11-09 22:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-11-09 22:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-11-09 22:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
