<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-31 04:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:56:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 04:56:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 04:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 04:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 04:57:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 04:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:57:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:57:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 04:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 04:58:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:58:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 04:58:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:58:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 04:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 04:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:59:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 04:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 04:59:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 05:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 05:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 05:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 05:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 05:02:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 05:02:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 05:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-31 05:15:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 05:15:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 05:18:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-31 05:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-31 05:21:52 --> The upload path does not appear to be valid.
ERROR - 2022-07-31 05:25:35 --> The upload path does not appear to be valid.
ERROR - 2022-07-31 05:25:36 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV-CC', '2022-07-31', NULL, 'Courier Debit For Invoice No -  1018 Courier  Karanfuli Paribahan', 0, 3390, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 05:25:35', 1)
ERROR - 2022-07-31 05:25:36 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV-CC', '2022-07-31', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1018 Courier  Karanfuli Paribahan', 200, 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 05:25:35', 1)
ERROR - 2022-07-31 05:33:29 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `total_tax`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '779546745756853', '8214671674', NULL, '8', NULL, NULL, '2022-07-31', '2022-07-31', NULL, NULL, '0.00', '', NULL, '349.00', '', 1)
ERROR - 2022-07-31 05:33:29 --> Query error: Column 'shipping_cost' cannot be null - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `agg_id`, `date`, `total_amount`, `invoice`, `paid_amount`, `due_amount`, `shipping_cost`, `sale_type`, `courier_condtion`, `sales_by`, `status`, `payment_type`, `delivery_type`, `courier_id`, `branch_id`, `outlet_id`, `reciever_id`, `receiver_number`, `courier_status`) VALUES ('4561828431', '8', NULL, '2022-07-31', '349.00', 1019, '349', '0.00', NULL, '2', '1', 'OpSoxJvBbbS8Rws', 2, 1, '2', 'PHL6O5EC63EP3BM', NULL, 'HK7TGDT69VFMXB7', NULL, '01829229932', '1')
ERROR - 2022-07-31 05:33:29 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('4561828431', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 4561828431 Customer- ', 0, '349', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 05:33:29', 1)
ERROR - 2022-07-31 05:33:29 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1019 Courier  Karanfuli Paribahan', 0, '349.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 05:33:29', 1)
ERROR - 2022-07-31 05:33:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 05:34:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 06:33:58 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1018 Courier  Karanfuli Paribahan', '100', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:33:58', 1)
ERROR - 2022-07-31 06:33:58 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV', '2022-07-31', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID - 1018 Customer- Ahmmed marzuk', '249.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:33:58', 1)
ERROR - 2022-07-31 06:38:58 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1534341427', 'INV', '2022-07-31', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID - 1017 Customer- Zobaer Hosen Rifat', '349.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:38:58', 1)
ERROR - 2022-07-31 06:40:42 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1534341427', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1534341427 Customer- Zobaer Hosen Rifat', 0, '', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:40:42', 1)
ERROR - 2022-07-31 06:41:35 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1534341427', 'INV', '2022-07-31', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID -  Customer- Zobaer Hosen Rifat', '349.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:41:35', 1)
ERROR - 2022-07-31 06:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:47:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 06:47:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 06:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 06:47:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:47:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 06:47:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:47:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:47:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 06:47:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 06:49:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:49:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 06:49:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 06:49:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:49:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 06:49:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 06:50:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1534341427', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -   Courier  ', '200', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:50:02', 1)
ERROR - 2022-07-31 06:50:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1534341427', 'INV', '2022-07-31', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID -  Customer- Zobaer Hosen Rifat', '149.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:50:02', 1)
ERROR - 2022-07-31 06:57:01 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8255856497', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8255856497 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 06:57:01', 1)
ERROR - 2022-07-31 06:57:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 06:59:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 07:00:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 07:00:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 07:06:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:17:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:18:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:25:27 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('5321615538', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 5321615538 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 08:25:27', 1)
ERROR - 2022-07-31 08:25:27 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1020 Courier  Karanfuli Paribahan', 0, '149.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 08:25:27', 1)
ERROR - 2022-07-31 08:28:27 --> The upload path does not appear to be valid.
ERROR - 2022-07-31 08:28:27 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Courier Debit For Invoice No -  1021 Courier  Karanfuli Paribahan', 0, 1745, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 08:28:27', 1)
ERROR - 2022-07-31 08:28:27 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1021 Courier  Karanfuli Paribahan', NULL, 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 08:28:27', 1)
ERROR - 2022-07-31 08:28:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:28:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:29:22 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8212121312', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8212121312 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 08:29:22', 1)
ERROR - 2022-07-31 08:29:22 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1022 Courier  Karanfuli Paribahan', 0, '347.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 08:29:22', 1)
ERROR - 2022-07-31 08:29:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:30:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:31:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:31:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:32:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:33:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:34:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:34:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:37:41 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:37:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:38:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:38:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:39:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:39:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:39:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:39:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:39:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:40:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:42:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:42:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:43:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:43:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:43:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:43:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:43:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:43:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:43:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:43:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:43:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:43:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:43:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:43:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:43:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:44:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:44:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:44:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:44:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:44:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:44:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:44:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:44:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:44:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:44:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:44:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:44:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:44:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:45:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:45:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:45:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:45:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:45:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:45:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:45:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:45:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:45:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:46:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 08:46:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:46:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:46:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:46:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 08:47:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:47:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-31 08:47:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-31 08:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:47:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-31 08:47:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-31 09:02:21 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1021 Courier  Karanfuli Paribahan', '100', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:02:21', 1)
ERROR - 2022-07-31 09:02:21 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV', '2022-07-31', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID - 1021 Customer- Test Customer 2', '349.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:02:21', 1)
ERROR - 2022-07-31 09:04:46 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8539436713', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8539436713 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:04:46', 1)
ERROR - 2022-07-31 09:04:46 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1023 Courier  Karanfuli Paribahan', 0, '249.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:04:46', 1)
ERROR - 2022-07-31 09:04:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 09:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-07-31 09:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 100
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 100
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 101
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 101
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 103
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 103
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 104
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 104
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-07-31 09:34:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 100
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 100
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 101
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 101
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 103
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 103
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 104
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 104
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-07-31 09:36:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-07-31 09:36:41 --> Query error: Unknown table 'b' - Invalid query: SELECT `c`.*, `a`.*, `b`.*, `a`.`product_id`, `d`.`product_name`, `d`.`product_model`
FROM `product_purchase` `c`
JOIN `product_purchase_details` `a` ON `a`.`purchase_id` = `c`.`purchase_id`
JOIN `product_information` `d` ON `d`.`product_id` = `a`.`product_id`
WHERE `c`.`purchase_id` = ' 20220719092054'
GROUP BY `d`.`product_id`
ERROR - 2022-07-31 09:36:50 --> Severity: Notice --> Undefined index: supplier_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 100
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 100
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 101
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 101
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 103
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 103
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 104
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 104
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-07-31 09:37:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 105
ERROR - 2022-07-31 09:39:09 --> Severity: Notice --> Undefined index: supplier_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 102
ERROR - 2022-07-31 09:39:53 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 974
ERROR - 2022-07-31 09:39:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1001
ERROR - 2022-07-31 09:39:53 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220719092054', 'Return', '2022-07-31', NULL, 'Supplier Return to .Factory', '1000.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31', 1)
ERROR - 2022-07-31 09:40:22 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 974
ERROR - 2022-07-31 09:40:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1001
ERROR - 2022-07-31 09:40:22 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220719092054', 'Return', '2022-07-31', NULL, 'Supplier Return to .Factory', '1000.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31', 1)
ERROR - 2022-07-31 09:40:40 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('20220719092054', 'Return', '2022-07-31', NULL, 'Supplier Return to .Factory', '1000.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-31', 1)
ERROR - 2022-07-31 09:41:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-07-31 09:41:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-07-31 09:41:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-07-31 09:41:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-07-31 09:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-07-31 09:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-07-31 09:53:59 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6216675483', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6216675483 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:53:59', 1)
ERROR - 2022-07-31 09:53:59 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1024 Courier  Karanfuli Paribahan', 0, '337.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:53:59', 1)
ERROR - 2022-07-31 09:54:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 09:56:00 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7942546292', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 7942546292 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:55:59', 1)
ERROR - 2022-07-31 09:56:00 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8748221213', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1025 Courier  Karanfuli Paribahan', 0, '347.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 09:55:59', 1)
ERROR - 2022-07-31 09:56:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-07-31 10:01:37 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6488746838', 'INV', '2022-07-31', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 6488746838 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 10:01:37', 1)
ERROR - 2022-07-31 10:01:37 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8214671674', 'INV-CC', '2022-07-31', NULL, 'Courier Credit For Invoice No -  1026 Courier  Karanfuli Paribahan', 0, '347.00', 1, 'OpSoxJvBbbS8Rws', '2022-07-31 10:01:37', 1)
ERROR - 2022-07-31 10:22:11 --> Severity: error --> Exception: Too few arguments to function CI_DB_query_builder::join(), 1 passed in C:\laragon\www\git\erp_swapon\application\views\return\return_invoice_html.php on line 195 and at least 2 expected C:\laragon\www\git\erp_swapon\system\database\DB_query_builder.php 526
ERROR - 2022-07-31 10:22:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`product_id,b`.`product_id`)
WHERE `invoice_id` = '6488746838'' at line 3 - Invalid query: SELECT `a`.*, `b`.`product_name`, `b`.`product_model`
FROM `invoice_details` `a`
JOIN `product_information` `b` USING (`a`.`product_id,b`.`product_id`)
WHERE `invoice_id` = '6488746838'
ERROR - 2022-07-31 10:22:36 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\views\return\return_invoice_html.php 196
ERROR - 2022-07-31 10:27:25 --> Severity: Warning --> Illegal string offset 'invoice_id_new' C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 226
ERROR - 2022-07-31 10:27:37 --> Severity: Warning --> Illegal string offset 'invoice_id_new' C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 226
