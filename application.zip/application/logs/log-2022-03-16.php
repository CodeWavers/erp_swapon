<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-16 04:41:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-16 04:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-16 04:41:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-16 04:41:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-16 04:41:32 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-16 04:52:23 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 111
ERROR - 2022-03-16 04:52:54 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 111
ERROR - 2022-03-16 04:54:36 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-16 04:55:20 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 275
ERROR - 2022-03-16 05:02:16 --> Severity: Notice --> Undefined variable: response C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 288
ERROR - 2022-03-16 05:15:00 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 308
ERROR - 2022-03-16 05:15:00 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 310
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:14 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:41:15 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 05:41:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'thumbnail_img' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 281
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 284
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'variation' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 285
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 288
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:42:35 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 293
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'unit_price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 294
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 297
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:42:35 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:42:35 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 05:42:35 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 05:42:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 05:43:58 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:43:58 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:43:58 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:43:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 05:44:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 05:50:09 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 05:50:09 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 05:50:09 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 05:50:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 05:51:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-16 05:51:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-16 05:51:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-16 05:51:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-16 05:51:32 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-16 05:53:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 05:54:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:00:42 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 06:00:42 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 06:00:42 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 06:00:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:05:52 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 06:05:52 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 06:05:52 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 06:05:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:06:48 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 06:06:48 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 06:06:48 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 06:06:48 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 231
ERROR - 2022-03-16 06:06:48 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 232
ERROR - 2022-03-16 06:06:48 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 233
ERROR - 2022-03-16 06:06:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:07:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:09:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:10:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 06:12:38 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 06:12:38 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 320
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Undefined variable: order_details C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 326
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 332
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 341
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 06:12:38 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 06:12:38 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 354
ERROR - 2022-03-16 06:12:38 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 06:12:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:15:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 06:15:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:15:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 06:15:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:16:08 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 314
ERROR - 2022-03-16 06:16:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:16:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 367
ERROR - 2022-03-16 06:16:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:17:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:25:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:37:28 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:39:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:39:41 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:39:48 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:39:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:39:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:39:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:41:09 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:41:17 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:41:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:41:17 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:41:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-16 06:44:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-16 06:46:17 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:46:24 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:46:24 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:46:24 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:46:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:48:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:51:51 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:51:58 --> Severity: Notice --> Undefined variable: offline_payment C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:51:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:51:58 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-16 06:51:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:56:01 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:56:13 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:58:35 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:58:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 06:58:59 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:59:13 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:59:23 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:59:34 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 06:59:59 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 07:00:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:00:22 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 07:00:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:00:58 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 177
ERROR - 2022-03-16 07:01:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:02:10 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-16 07:02:10 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-16 07:02:10 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-16 07:02:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-16 07:02:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:02:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:06:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:07:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:08:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:14:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:15:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:16:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:17:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:17:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:17:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:18:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:18:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:21:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:21:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:22:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:23:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:24:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:25:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:26:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:27:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:27:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:31:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:32:14 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:32:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:37:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:39:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:40:13 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:41:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:44:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 07:46:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 08:35:14 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 08:36:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 08:38:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-16 08:43:56 --> 404 Page Not Found: My-assets/image
