<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-02 04:59:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 04:59:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 04:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 04:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 04:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 04:59:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:02:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:02:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:02:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:02:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:02:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:04:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:04:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:04:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:04:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:05:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:05:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:05:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:05:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:06:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:06:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:06:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:06:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:06:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:06:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:07:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:07:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:07:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:07:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:17:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:17:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:17:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:17:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:17:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:17:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:17:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:17:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:17:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:18:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:18:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:18:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:18:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:18:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:18:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:19:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:19:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:19:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:19:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:19:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:19:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:19:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:19:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:21:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:21:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:21:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:21:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:27:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:27:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:27:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:27:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:27:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:41:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:41:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:41:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:41:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:41:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:41:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:41:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:41:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:41:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:45:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:45:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:45:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:45:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:48:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-02 05:48:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-02 05:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 05:48:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-02 05:48:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-02 22:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-02 16:45:15 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:15 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 22:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-02 16:45:16 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:16 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 22:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-02 16:45:16 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:16 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 22:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-02 16:45:16 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:16 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 22:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 359
ERROR - 2022-08-02 16:45:18 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:18 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 22:45:21 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `web_setting`
ERROR - 2022-08-02 22:45:21 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\helpers\lang_helper.php 16
ERROR - 2022-08-02 16:45:21 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:21 --> Query error: MySQL server has gone away - Invalid query: SET SESSION sql_mode = ""
ERROR - 2022-08-02 16:45:21 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `company_information`
 LIMIT 1
ERROR - 2022-08-02 16:45:21 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Products.php 482
