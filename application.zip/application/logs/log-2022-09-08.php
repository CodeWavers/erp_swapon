<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-08 10:39:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-08 10:40:23 --> The upload path does not appear to be valid.
ERROR - 2022-09-08 10:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:41:33 --> The upload path does not appear to be valid.
ERROR - 2022-09-08 10:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:47:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:47:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:50:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:53:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:53:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:53:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 10:53:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:53:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 10:53:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 10:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:54:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:54:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 10:54:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 10:54:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:54:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 10:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:54:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:54:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:54:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 10:54:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:54:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 10:54:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 10:54:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:57:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:57:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:57:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 10:57:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 10:57:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:57:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 10:57:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:59:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 10:59:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:59:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 10:59:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 10:59:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 10:59:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 10:59:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:00:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:00:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:00:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:00:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:00:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:03:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:04:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:04:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:04:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:04:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:04:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:04:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:04:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:04:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:04:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:04:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:04:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:04:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:04:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:04:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:06:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:07:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:08:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:10:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:10:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:10:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:10:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:10:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:10:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:10:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:10:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:10:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:14:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:17:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:17:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:17:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:18:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:18:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:18:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:18:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:18:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:18:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:18:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:18:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:18:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:18:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:18:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:18:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:22:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:22:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:22:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 11:22:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 11:22:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 11:22:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 11:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:22:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:23:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:24:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:24:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:24:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:24:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:28:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:28:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:28:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:29:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:29:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:38:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:50:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:50:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 11:53:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 12:17:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 12:17:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 12:18:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 701
ERROR - 2022-09-08 12:20:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:22:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:24:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:26:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:30:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:30:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:31:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:33:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:35:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:35:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:36:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:37:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:38:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:40:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:41:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:42:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:44:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:45:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:51:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:51:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 12:51:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:51:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:51:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 12:51:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 12:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 12:57:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 12:57:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 12:57:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 12:57:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:16 --> Query error: Unknown column 'cash_refund' in 'field list' - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `date`, `agg_id`, `total_amount`, `invoice`, `sale_type`, `sales_return`, `total_discount`, `cash_refund`, `customer_ac`, `sales_by`, `status`, `payment_type`) VALUES ('6874777394', '34', '2022-09-08', NULL, '0', 1007, NULL, '40.00', '10.00', '20', '20.00', 'OpSoxJvBbbS8Rws', 2, 1)
ERROR - 2022-09-08 12:57:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 12:57:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 12:57:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 12:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 12:57:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 12:57:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 12:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 12:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:02:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:07:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:07:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:08:13 --> Query error: Unknown column 'cash_refund' in 'field list' - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `date`, `agg_id`, `total_amount`, `invoice`, `sale_type`, `sales_return`, `total_discount`, `cash_refund`, `customer_ac`, `sales_by`, `status`, `payment_type`) VALUES ('6721228779', '34', '2022-09-08', NULL, '0', 1007, '2', '40.00', '10.00', '20', '20.00', 'OpSoxJvBbbS8Rws', 2, 1)
ERROR - 2022-09-08 13:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:12:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:12:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:12:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:12:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:13:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:13:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:13:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:13:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:13:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:14:17 --> The upload path does not appear to be valid.
ERROR - 2022-09-08 13:14:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:14:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:14:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:14:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:14:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:14:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:14:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:14:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:14:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:14:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:14:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:18:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:19:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:19:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:19:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:19:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:19:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:19:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:21:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:21:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:21:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:21:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:22:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lcourier.php 219
ERROR - 2022-09-08 13:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 75
ERROR - 2022-09-08 13:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:23:24 --> Query error: Unknown column 'cash_refund' in 'field list' - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `date`, `agg_id`, `total_amount`, `invoice`, `sale_type`, `sales_return`, `total_discount`, `cash_refund`, `customer_ac`, `sales_by`, `status`, `payment_type`) VALUES ('1121365251', '34', '2022-09-08', NULL, '0', 1001, '2', '123.50', '19.00', '50', '73.50', 'OpSoxJvBbbS8Rws', 2, 1)
ERROR - 2022-09-08 13:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:29:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:30:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:30:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:30:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:30:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:30:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:30:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:30:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:30:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:31:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:31:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:31:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:31:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:31:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:31:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:31:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:31:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:31:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:31:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:31:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:31:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:32:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:32:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:32:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 13:32:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 13:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 13:32:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 13:32:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 13:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:13:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:13:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 14:13:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:13:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 14:13:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 14:13:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:20:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:20:32 --> Severity: Notice --> Undefined variable: agg_name C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 67
ERROR - 2022-09-08 14:20:32 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 70
ERROR - 2022-09-08 14:20:32 --> Severity: Notice --> Undefined variable: taxes C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:20:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:20:51 --> Severity: Notice --> Trying to get property 'id' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 470
ERROR - 2022-09-08 14:20:51 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 470
ERROR - 2022-09-08 14:20:51 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 472
ERROR - 2022-09-08 14:20:51 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 473
ERROR - 2022-09-08 14:20:51 --> Query error: Unknown column 'cash_refund' in 'field list' - Invalid query: INSERT INTO `invoice` (`invoice_id`, `customer_id`, `date`, `agg_id`, `total_amount`, `invoice`, `sale_type`, `sales_return`, `total_discount`, `cash_refund`, `customer_ac`, `sales_by`, `status`, `payment_type`) VALUES ('7524727823', '34', '2022-09-08', NULL, '0', 1001, '2', '123.50', '19.00', '100', '23.50', 'OpSoxJvBbbS8Rws', 2, 1)
ERROR - 2022-09-08 14:28:22 --> Severity: Notice --> Trying to get property 'id' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 470
ERROR - 2022-09-08 14:28:22 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 470
ERROR - 2022-09-08 14:28:22 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 472
ERROR - 2022-09-08 14:28:22 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Returnse.php 473
ERROR - 2022-09-08 14:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:41:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 14:41:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 14:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:41:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 14:42:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:42:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:42:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-08 14:42:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-08 14:42:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:42:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-08 14:42:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-08 14:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:47:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:48:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:53:19 --> The upload path does not appear to be valid.
ERROR - 2022-09-08 14:53:19 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('8199335999', 'INV', '2022-09-08', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 8199335999 Customer- ', 0, '200', 1, 'OpSoxJvBbbS8Rws', '2022-09-08 14:53:19', 1)
ERROR - 2022-09-08 14:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 14:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 15:02:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 15:03:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 15:04:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-08 15:04:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
