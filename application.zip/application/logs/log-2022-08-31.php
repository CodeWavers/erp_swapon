<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-31 04:46:33 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-31 04:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 04:51:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:04:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:09:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:09:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:09:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:10:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:14:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 707
ERROR - 2022-08-31 05:14:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 05:18:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:24:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:29:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:30:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:30:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 06:41:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-31 06:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 06:41:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-31 06:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 06:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-31 06:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 690
ERROR - 2022-08-31 06:43:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 06:43:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-31 06:43:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-31 06:43:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 06:43:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 06:43:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-31 07:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 691
ERROR - 2022-08-31 07:28:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 691
ERROR - 2022-08-31 07:29:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 691
ERROR - 2022-08-31 08:42:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:39:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 09:39:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-31 09:39:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 09:39:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 09:39:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-31 09:39:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-31 09:41:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:41:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 09:41:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-31 09:41:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-31 09:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 09:41:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-31 09:41:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-31 09:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:57:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 09:59:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:07:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:11:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:15:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:15:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-08-31 10:36:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
