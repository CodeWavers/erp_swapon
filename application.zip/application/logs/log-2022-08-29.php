<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-29 04:32:04 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-29 05:06:37 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 355
ERROR - 2022-08-29 05:06:37 --> Severity: Warning --> Division by zero C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual_all.php 355
ERROR - 2022-08-29 05:06:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:08:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:09:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:10:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:12:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:15:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:15:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:15:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:15:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:15:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:15:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:16:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:16:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:16:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:16:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:16:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:18:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:19:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:19:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:19:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:19:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:19:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:20:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:20:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:20:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:20:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:20:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:20:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:20:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:20:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:20:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:20:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:22:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:22:14 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:22:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:22:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:22:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:22:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:27:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:27:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:27:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:27:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:27:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:27:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:28:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:28:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:28:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:28:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:28:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:28:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:31:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:31:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:31:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:31:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:31:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:31:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:35:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:35:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:35:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:35:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:35:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:35:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:35:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:36:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:36:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:36:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:36:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:36:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:36:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:37:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:37:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:37:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:37:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:37:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:37:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:37:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:38:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:38:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:38:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:38:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:39:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:40:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:40:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:40:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:40:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:40:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:41:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:41:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:41:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 05:41:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:41:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:41:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:41:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:42:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:42:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:42:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:49:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:49:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:49:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:49:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:49:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:49:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:49:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:49:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:49:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:50:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:50:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:50:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:50:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:50:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:50:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:50:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:51:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:51:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:54:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:54:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:54:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:54:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:54:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:54:48 --> Query error: Unknown column 'sl' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
LEFT JOIN `cats` `b` ON `a`.`category_id`=`b`.`id`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `sl` ASC
 LIMIT 10
ERROR - 2022-08-29 05:54:48 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-08-29 05:54:51 --> Query error: Unknown column 'sl' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
LEFT JOIN `cats` `b` ON `a`.`category_id`=`b`.`id`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `sl` DESC
 LIMIT 10
ERROR - 2022-08-29 05:54:51 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-08-29 05:55:01 --> Query error: Unknown column 'category' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
LEFT JOIN `cats` `b` ON `a`.`category_id`=`b`.`id`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `category` ASC
 LIMIT 10
ERROR - 2022-08-29 05:55:01 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-08-29 05:56:16 --> Query error: Unknown column 'category' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
LEFT JOIN `cats` `b` ON `a`.`category_id`=`b`.`id`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `category` DESC
 LIMIT 10
ERROR - 2022-08-29 05:56:16 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-08-29 05:56:51 --> Query error: Unknown column 'sales_price' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
LEFT JOIN `cats` `b` ON `a`.`category_id`=`b`.`id`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `sales_price` ASC
 LIMIT 10
ERROR - 2022-08-29 05:56:51 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-08-29 05:57:34 --> Query error: Unknown column 'sales_price' in 'order clause' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
LEFT JOIN `cats` `b` ON `a`.`category_id`=`b`.`id`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `sales_price` ASC
 LIMIT 10
ERROR - 2022-08-29 05:57:34 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 388
ERROR - 2022-08-29 05:58:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:58:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:58:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:58:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:58:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:58:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:58:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 05:58:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 05:58:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 05:58:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 05:58:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:04:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:04:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:04:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:06:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:06:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:06:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:06:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:06:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:06:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:16:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:16:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:16:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Test Product', 1, 5655, 0, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/uploads/products/thumbnail/MZO2oMhCzzFRTjMOw6uX30gfRe4L69q0SrsV28Qd.png', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'SARWAR', 1, 2000, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/uploads/products/thumbnail/sDjS05nQiUy4hWvFJzrIfyVGn2yd5pAOWk8zcLiS.png', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '1', '', 'Test Product', 1, 77, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Milk', 1, 2, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Test Product', 1, 1, 0, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '1', '', 'iFOB(25T/Box)', 1, 1, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '2', '', 'Milk', 1, 250, 0, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, NULL)
ERROR - 2022-08-29 06:16:48 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Wayne Holloway', 1, 773, 0, 'Pcs', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, NULL)
ERROR - 2022-08-29 06:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:16:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:16:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:19:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:19:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Test Product', 1, 5655, 0, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/uploads/products/thumbnail/MZO2oMhCzzFRTjMOw6uX30gfRe4L69q0SrsV28Qd.png', 1, '2022-04-13T05:41:36.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'SARWAR', 1, 2000, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/uploads/products/thumbnail/sDjS05nQiUy4hWvFJzrIfyVGn2yd5pAOWk8zcLiS.png', 1, '2022-04-16T10:00:19.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '1', '', 'Test Product', 1, 77, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T18:25:40.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Milk', 1, 2, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T18:30:46.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Test Product', 1, 1, 0, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T19:46:02.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '1', '', 'iFOB(25T/Box)', 1, 1, 0, NULL, NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-16T19:49:40.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, '2', '', 'Milk', 1, 250, 0, 'Dozen', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-18T15:31:35.000000Z')
ERROR - 2022-08-29 06:19:56 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `product_information` (`product_id`, `category_id`, `brand_id`, `product_name`, `finished_raw`, `price`, `purchase_price`, `unit`, `sku`, `tax`, `product_details`, `image`, `status`, `created_date`) VALUES (NULL, NULL, '', 'Wayne Holloway', 1, 773, 0, 'Pcs', NULL, 0, '', 'https://dev.swaponsworld.com/public/', 1, '2022-04-19T19:16:05.000000Z')
ERROR - 2022-08-29 06:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:19:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:19:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:24:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:24:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:24:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:25:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:25:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:25:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 06:25:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:25:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:25:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:25:57 --> Severity: error --> Exception: Call to a member function dateConvert() on null C:\laragon\www\git\erp_swapon\application\models\Products.php 159
ERROR - 2022-08-29 06:27:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:27:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 06:27:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:27:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 06:27:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 06:27:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 07:09:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 08:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:37:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 08:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:37:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 08:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:37:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 08:37:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:37:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 08:37:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:37:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 08:37:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:37:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 08:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:45:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 08:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:45:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 08:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 08:45:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 10:05:01 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-29 10:05:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-29 10:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 10:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 10:31:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 10:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 10:55:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 10:56:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 11:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 11:18:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 11:22:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 639
ERROR - 2022-08-29 11:26:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 11:26:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 11:26:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:26:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:26:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 11:38:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-29 11:38:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:38:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 11:38:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 11:38:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:38:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 11:38:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:41:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-29 11:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-29 11:41:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-29 11:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:41:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-29 11:41:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-29 11:46:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-29 11:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-29 11:50:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
ERROR - 2022-08-29 11:51:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 637
