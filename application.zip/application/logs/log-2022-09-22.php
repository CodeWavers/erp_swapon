<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-22 10:59:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2931
ERROR - 2022-09-22 10:59:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2931
ERROR - 2022-09-22 10:59:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2998
ERROR - 2022-09-22 10:59:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2998
ERROR - 2022-09-22 10:59:34 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Undefined variable: product_list C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 331
ERROR - 2022-09-22 11:09:21 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 331
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Undefined variable: product_list C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Undefined offset: 2 C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Undefined offset: 3 C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:09:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 314
ERROR - 2022-09-22 11:14:52 --> Severity: Notice --> Undefined variable: filtered_arr C:\laragon\www\git\erp_swapon\application\libraries\Lproduction.php 341
ERROR - 2022-09-22 11:26:21 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1388
ERROR - 2022-09-22 11:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-22 11:28:25 --> Severity: Notice --> Undefined variable: data C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1388
ERROR - 2022-09-22 11:28:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\rqsn\rqsn_approve_outlet.php 73
ERROR - 2022-09-22 12:15:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:15:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:15:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:15:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:15:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:15:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:16:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:16:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:16:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:16:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:16:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:16:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:17:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:17:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:17:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:17:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:17:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:17:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:18:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:18:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:19:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:19:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:19:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:19:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:23:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:23:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:23:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:27:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:27:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:27:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:27:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:27:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:27:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:28:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:28:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:28:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:28:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:28:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:28:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:28:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:28:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:28:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:28:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:29:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:29:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:29:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:29:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:29:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:29:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:30:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:30:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 12:30:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 12:30:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:30:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 12:30:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 12:50:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 921
ERROR - 2022-09-22 12:50:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 12:54:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 921
ERROR - 2022-09-22 12:54:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 12:56:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 921
ERROR - 2022-09-22 12:56:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 12:57:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 921
ERROR - 2022-09-22 12:57:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 13:01:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Production.php 925
ERROR - 2022-09-22 13:01:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Production.php 925
ERROR - 2022-09-22 13:01:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 13:12:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 13:13:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 13:13:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 982
ERROR - 2022-09-22 13:20:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 378
ERROR - 2022-09-22 13:20:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\item_finalize.php 73
ERROR - 2022-09-22 13:20:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 378
ERROR - 2022-09-22 13:20:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\item_finalize.php 73
ERROR - 2022-09-22 14:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:44:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:44:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:45:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:45:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:45:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:45:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:45:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:45:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:45:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:45:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:46:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:46:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:46:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:49:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:49:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:49:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:49:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:49:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:49:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:51:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:51:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:51:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:52:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:52:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:52:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:52:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:52:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:52:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:52:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:52:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:52:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:52:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:52:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:55:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:55:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:55:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:55:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:55:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:55:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:55:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:55:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:55:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:56:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:56:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:56:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:56:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:56:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:57:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:57:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 14:57:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 14:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 14:57:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 14:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 355
ERROR - 2022-09-22 14:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 76
ERROR - 2022-09-22 16:25:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 16:25:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 16:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 16:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 16:25:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 16:25:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 16:31:10 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-22 17:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:23:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 17:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:23:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 17:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:23:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 17:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 17:28:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 17:28:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:28:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 17:28:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:28:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:28:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-22 17:28:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-22 17:28:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-22 17:28:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-22 17:28:40 --> 404 Page Not Found: Assets/js
