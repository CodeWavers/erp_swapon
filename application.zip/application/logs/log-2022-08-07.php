<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-07 05:18:43 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('1421759175', 'INV', '2022-08-07', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 1421759175 Customer- ', 0, '0', 1, 'OpSoxJvBbbS8Rws', '2022-08-07 05:18:43', 1)
ERROR - 2022-08-07 05:18:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-07 05:26:00 --> Severity: error --> Exception: Too few arguments to function Cretrun_m::invoice_inserted_data(), 0 passed in C:\laragon\www\git\erp_swapon\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 291
ERROR - 2022-08-07 05:31:45 --> Severity: error --> Exception: Too few arguments to function Cretrun_m::invoice_inserted_data(), 0 passed in C:\laragon\www\git\erp_swapon\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 291
ERROR - 2022-08-07 05:47:56 --> Severity: Notice --> Undefined variable: subTotal_ammount C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 243
ERROR - 2022-08-07 09:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2821
ERROR - 2022-08-07 09:11:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2821
ERROR - 2022-08-07 09:11:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2888
ERROR - 2022-08-07 09:11:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2888
ERROR - 2022-08-07 09:19:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-08-07 09:19:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-08-07 09:19:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-08-07 09:19:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-08-07 09:19:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-08-07 09:19:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-08-07 10:15:27 --> The upload path does not appear to be valid.
ERROR - 2022-08-07 10:32:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-07 10:32:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-07 10:32:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:32:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:32:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:32:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-07 10:44:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-07 10:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:44:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:44:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-07 10:44:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-07 10:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-07 10:45:21 --> 404 Page Not Found: Assets/css
