<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-07 10:49:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 10:50:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\aggre\aggre_ledger_report.php 77
ERROR - 2022-11-07 10:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-07 10:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-07 10:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-07 10:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 482
ERROR - 2022-11-07 10:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 488
ERROR - 2022-11-07 10:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-11-07 10:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-11-07 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-07 10:55:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-07 10:55:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-07 10:56:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 10:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 482
ERROR - 2022-11-07 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 488
ERROR - 2022-11-07 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-11-07 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-11-07 11:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 482
ERROR - 2022-11-07 11:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 488
ERROR - 2022-11-07 11:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 504
ERROR - 2022-11-07 11:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 510
ERROR - 2022-11-07 11:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 421
ERROR - 2022-11-07 11:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 427
ERROR - 2022-11-07 11:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 443
ERROR - 2022-11-07 11:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 449
ERROR - 2022-11-07 11:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-07 11:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-07 11:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-07 11:01:53 --> The upload path does not appear to be valid.
ERROR - 2022-11-07 11:01:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 11:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 11:39:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcustomer.php 164
ERROR - 2022-11-07 11:39:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcustomer.php 164
ERROR - 2022-11-07 11:39:09 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lcustomer.php 165
ERROR - 2022-11-07 11:39:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lcustomer.php 165
ERROR - 2022-11-07 11:58:19 --> 404 Page Not Found: Ccustomer/aggre_ledgerData
ERROR - 2022-11-07 14:12:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3312
ERROR - 2022-11-07 14:12:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3312
ERROR - 2022-11-07 14:12:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3379
ERROR - 2022-11-07 14:12:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3379
ERROR - 2022-11-07 14:12:33 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 14:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-07 14:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-07 14:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-07 14:12:57 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 407
ERROR - 2022-11-07 14:12:57 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 407
ERROR - 2022-11-07 14:12:57 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 409
ERROR - 2022-11-07 14:12:57 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 409
ERROR - 2022-11-07 14:13:33 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 407
ERROR - 2022-11-07 14:13:33 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 407
ERROR - 2022-11-07 14:13:33 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 409
ERROR - 2022-11-07 14:13:33 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 409
ERROR - 2022-11-07 14:15:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 14:15:04 --> Severity: Notice --> Trying to get property 'type' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 42
ERROR - 2022-11-07 14:15:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 14:15:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 14:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 14:15:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-07 14:15:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-07 14:15:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-07 14:16:29 --> The upload path does not appear to be valid.
ERROR - 2022-11-07 14:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 14:44:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 14:44:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 14:44:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 15:37:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 168
ERROR - 2022-11-07 15:37:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 740
ERROR - 2022-11-07 15:37:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 746
ERROR - 2022-11-07 15:37:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:37:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:37:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:42:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:42:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:42:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:43:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:43:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:43:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 15:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 15:44:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 15:44:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 15:44:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 15:44:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 15:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:45:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 15:45:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 15:45:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 15:45:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 15:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 15:45:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 15:45:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 15:45:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 15:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 15:46:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 15:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:48:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:51:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:52:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 15:56:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-07 15:56:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-07 15:56:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-07 18:15:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 18:15:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 18:15:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 18:15:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 18:16:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 18:16:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 18:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 19:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 19:19:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 19:21:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-11-07 19:25:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-11-07 19:39:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-07 19:39:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-07 19:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-07 19:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-07 19:42:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-07 19:42:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-07 19:42:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-11-07 19:42:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-11-07 19:52:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 19:53:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 19:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 19:58:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 19:58:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 19:58:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 19:58:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 19:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 19:58:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 19:59:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 19:59:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:00:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3313
ERROR - 2022-11-07 20:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3313
ERROR - 2022-11-07 20:00:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3380
ERROR - 2022-11-07 20:00:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3380
ERROR - 2022-11-07 20:00:49 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:01:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:01:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:01:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:01:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:01:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:01:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:01:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:01:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3313
ERROR - 2022-11-07 20:01:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3313
ERROR - 2022-11-07 20:01:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3380
ERROR - 2022-11-07 20:01:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3380
ERROR - 2022-11-07 20:01:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:04:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:04:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:04:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:05:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3314
ERROR - 2022-11-07 20:05:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3314
ERROR - 2022-11-07 20:05:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3381
ERROR - 2022-11-07 20:05:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3381
ERROR - 2022-11-07 20:05:41 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:07:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3316
ERROR - 2022-11-07 20:07:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3316
ERROR - 2022-11-07 20:07:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3383
ERROR - 2022-11-07 20:07:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3383
ERROR - 2022-11-07 20:07:31 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:08:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:08:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:08:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:08:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:08:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:11:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:11:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:11:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:12:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:15:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:15:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:16:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:16:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:16:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:21:39 --> Query error: Unknown column 'b.name' in 'field list' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-11-07 20:24:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:24:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:24:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:24:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:24:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:26:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3319
ERROR - 2022-11-07 20:26:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3319
ERROR - 2022-11-07 20:26:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3386
ERROR - 2022-11-07 20:26:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3386
ERROR - 2022-11-07 20:26:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:27:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3319
ERROR - 2022-11-07 20:27:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3319
ERROR - 2022-11-07 20:27:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3386
ERROR - 2022-11-07 20:27:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3386
ERROR - 2022-11-07 20:27:00 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:28:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:28:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:28:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:31:13 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3319
ERROR - 2022-11-07 20:31:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3319
ERROR - 2022-11-07 20:31:13 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 3386
ERROR - 2022-11-07 20:31:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 3386
ERROR - 2022-11-07 20:31:13 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-07 20:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:31:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:31:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:31:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:31:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:31:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:31:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:31:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:09 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\git\erp_swapon\application\libraries\Occational.php 6
ERROR - 2022-11-07 20:36:59 --> Query error: Unknown column 'b.name' in 'field list' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-11-07 20:36:59 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 441
ERROR - 2022-11-07 20:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:37:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:37:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:37:12 --> Query error: Unknown column 'b.name' in 'field list' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-11-07 20:37:12 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 441
ERROR - 2022-11-07 20:37:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:37:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:37:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:37:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:37:17 --> Query error: Unknown column 'b.name' in 'field list' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `b`.`name`
FROM `product_information` `a`
WHERE `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-11-07 20:37:17 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 441
ERROR - 2022-11-07 20:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:38:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-07 20:38:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-07 20:38:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-07 20:38:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-07 20:38:12 --> 404 Page Not Found: Assets/js
