<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-04 05:41:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-04 05:41:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-04 05:41:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-04 05:41:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-04 05:41:44 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-04 05:42:30 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-04 05:42:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-04 05:42:30 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-04 05:42:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-04 05:42:39 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-03-04 05:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 406
ERROR - 2022-03-04 05:42:39 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-03-04 05:42:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\edit_purchase_form.php 412
ERROR - 2022-03-04 05:42:46 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-04 05:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-04 05:42:46 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-04 05:42:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:30 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:44:50 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
ERROR - 2022-03-04 05:45:14 --> Severity: Notice --> Undefined index: size_id C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 189
