<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-08 05:03:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:03:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:03:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:03:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:03:00 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-08 05:04:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:04:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:04:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:04:56 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-08 05:05:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:05:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:05:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:05:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:05:46 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-08 05:06:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:06:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 05:06:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:06:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 05:06:43 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-08 05:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:33:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:33:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:33:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:33:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 05:35:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:35:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 05:35:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:35:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:35:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:36:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:36:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 05:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:36:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:36:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:37:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:37:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 05:37:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:37:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:37:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:37:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:45:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:45:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 05:45:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:45:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:45:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:45:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:45:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:45:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 05:46:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:46:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:46:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:46:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:55:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 05:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:55:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 05:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 05:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:00:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:00:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:00:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:00:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:00:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:00:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:00:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:00:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:00:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:00:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:00:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:00:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:02:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:02:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:02:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:02:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:18:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:18:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:18:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:19:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:19:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:19:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:19:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:19:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:19:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:19:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:19:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:19:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:19:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:21:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:21:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:21:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:21:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:21:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:21:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:25:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:25:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:25:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:25:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:25:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:25:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:25:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:25:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:25:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:25:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:25:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:26:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:26:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:26:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:26:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:26:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:27:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:27:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:27:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:27:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:27:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:27:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:27:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:27:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:27:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:27:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:28:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:28:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:32:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:32:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 06:32:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 06:32:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 06:32:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 06:32:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 07:03:01 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 77
ERROR - 2022-02-08 07:04:22 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 77
ERROR - 2022-02-08 07:05:08 --> Severity: Notice --> Undefined variable: courier_condition C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 97
ERROR - 2022-02-08 07:05:08 --> Severity: Notice --> Undefined variable: courier_condition C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 97
ERROR - 2022-02-08 07:05:08 --> Severity: Notice --> Undefined variable: courier_condition C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 97
ERROR - 2022-02-08 07:05:08 --> Severity: Notice --> Undefined variable: courier_condition C:\laragon\www\git\erp_swapon\application\views\courier\courier_status.php 97
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 660
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: rq_d_id C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 663
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: cutting C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 667
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: printing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 668
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: sewing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 669
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: finishing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 670
ERROR - 2022-02-08 07:19:44 --> Severity: Notice --> Undefined index: finishing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 671
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: product_id C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 660
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: rq_d_id C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Trying to get property 'finished_qty' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 663
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: cutting C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 667
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: printing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 668
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: sewing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 669
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: finishing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 670
ERROR - 2022-02-08 07:19:57 --> Severity: Notice --> Undefined index: finishing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 671
ERROR - 2022-02-08 08:02:43 --> Severity: Notice --> Undefined index: invoice_no C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 397
ERROR - 2022-02-08 08:02:43 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 410
ERROR - 2022-02-08 08:02:43 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 412
ERROR - 2022-02-08 08:02:43 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 413
ERROR - 2022-02-08 08:02:43 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3424116928', 'INV', '2022-02-08', NULL, 'Courier debit For Invoice No -   Courier  ', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-08 08:02:43', 1)
ERROR - 2022-02-08 08:02:47 --> Severity: Notice --> Undefined index: invoice_no C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 397
ERROR - 2022-02-08 08:02:47 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 410
ERROR - 2022-02-08 08:02:47 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 412
ERROR - 2022-02-08 08:02:47 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 413
ERROR - 2022-02-08 08:02:47 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3424116928', 'INV', '2022-02-08', NULL, 'Courier debit For Invoice No -   Courier  ', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-08 08:02:47', 1)
ERROR - 2022-02-08 08:02:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:02:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:02:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:02:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:02:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:02:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:02:56 --> Severity: Notice --> Undefined index: invoice_no C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 397
ERROR - 2022-02-08 08:02:56 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 410
ERROR - 2022-02-08 08:02:56 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 412
ERROR - 2022-02-08 08:02:56 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 413
ERROR - 2022-02-08 08:02:56 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3424116928', 'INV', '2022-02-08', NULL, 'Courier debit For Invoice No -   Courier  ', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-08 08:02:56', 1)
ERROR - 2022-02-08 08:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:03:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:03:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:03:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:03:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:04:02 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 410
ERROR - 2022-02-08 08:04:02 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 412
ERROR - 2022-02-08 08:04:02 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 413
ERROR - 2022-02-08 08:04:02 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('3424116928', 'INV', '2022-02-08', NULL, 'Courier debit For Invoice No -  1000 Courier  ', 350, 0, 1, 'OpSoxJvBbbS8Rws', '2022-02-08 08:04:02', 1)
ERROR - 2022-02-08 08:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:05:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:05:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:05:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:08:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:08:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:08:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:08:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:08:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:08:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:09:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:09:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:09:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:09:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:09:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:10:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:10:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:10:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:10:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:11:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:11:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:11:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:11:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:11:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:11:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 08:56:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:56:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-08 08:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-08 08:56:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-08 08:56:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-08 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:17:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:18:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:18:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:18:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:18:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:18:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:18:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:18:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 38
ERROR - 2022-02-08 09:18:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:18:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 39
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Undefined property: stdClass::$invoice_id C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 50
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:21:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:22:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:22:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:22:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:22:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:28:42 --> Severity: error --> Exception: Too few arguments to function Cretrun_m::invoice_return_form(), 0 passed in C:\laragon\www\git\erp_swapon\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 31
ERROR - 2022-02-08 09:28:53 --> Severity: error --> Exception: Too few arguments to function Cretrun_m::invoice_return_form(), 0 passed in C:\laragon\www\git\erp_swapon\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\laragon\www\git\erp_swapon\application\controllers\Cretrun_m.php 31
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:30:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:30:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:30:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 45
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 46
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 47
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 48
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 49
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 50
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 51
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 52
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 53
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 54
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:32:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 09:32:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreturn.php 57
ERROR - 2022-02-08 15:10:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-08 15:10:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-02-08 15:10:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-08 15:10:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-02-08 15:10:37 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 15:10:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-08 15:10:37 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 15:10:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-08 15:10:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
