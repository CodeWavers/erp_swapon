<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-23 05:07:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-23 05:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 355
ERROR - 2022-08-23 05:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 76
ERROR - 2022-08-23 05:20:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\libraries\Lrqsn.php 355
ERROR - 2022-08-23 05:20:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 76
ERROR - 2022-08-23 06:12:40 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-23 06:13:36 --> The upload path does not appear to be valid.
ERROR - 2022-08-23 06:13:39 --> 404 Page Not Found: Assets/custom
ERROR - 2022-08-23 06:17:54 --> 404 Page Not Found: Cquotation/invoice_inserted_data
ERROR - 2022-08-23 06:28:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-08-23 06:47:59 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-08-23 07:58:02 --> Query error: Unknown column 'a.finsihed_raw' in 'where clause' - Invalid query: SELECT *
FROM `product_information` `a`
WHERE `a`.`finsihed_raw` = 1
ERROR - 2022-08-23 07:58:02 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 50
ERROR - 2022-08-23 08:22:08 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\report\stock_taking.php 63
ERROR - 2022-08-23 09:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:13:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:13:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:13:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:13:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:14:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:14:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:14:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:14:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:14:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:15:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:15:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:15:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:15:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:16:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:16:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:16:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:16:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:16:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:16:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:16:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:16:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:16:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:16:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:16:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:16:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:18:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:18:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:18:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:18:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:18:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:18:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 09:19:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 09:19:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 09:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 09:19:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:10:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:10:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:10:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:10:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:10:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:10:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:10:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:10:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:10:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:11:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:11:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:11:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:11:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:11:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:11:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:11:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:11:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:11:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:13:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:13:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:13:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:13:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:13:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:14:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:14:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:14:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:14:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:14:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:14:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:17:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:17:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-08-23 10:17:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-08-23 10:17:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:17:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-08-23 10:17:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-08-23 10:33:03 --> Severity: error --> Exception: Call to a member function manage_stock_taking() on null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 75
ERROR - 2022-08-23 10:34:07 --> Severity: error --> Exception: Call to a member function manage_stock_taking() on null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 75
ERROR - 2022-08-23 10:34:19 --> Severity: Notice --> Undefined property: Creport::$model C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 75
ERROR - 2022-08-23 10:34:19 --> Severity: Notice --> Trying to get property 'Reports' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 75
ERROR - 2022-08-23 10:34:19 --> Severity: error --> Exception: Call to a member function manage_stock_taking() on null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 75
ERROR - 2022-08-23 10:35:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 78
ERROR - 2022-08-23 10:36:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 78
ERROR - 2022-08-23 10:37:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 81
ERROR - 2022-08-23 10:37:50 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 81
ERROR - 2022-08-23 10:45:14 --> Severity: error --> Exception: syntax error, unexpected '$res' (T_VARIABLE), expecting ';' or ',' C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:46:19 --> Severity: error --> Exception: syntax error, unexpected '$res' (T_VARIABLE), expecting ';' or ',' C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:39 --> Severity: Notice --> Undefined property: CI_Loader::$occational C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:39 --> Severity: Notice --> Trying to get property 'dateConvert' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:39 --> Severity: Notice --> Undefined property: CI_Loader::$occational C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:39 --> Severity: Notice --> Trying to get property 'dateConvert' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Undefined variable: CI C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Trying to get property 'occational' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Trying to get property 'dateConvert' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Undefined variable: CI C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Trying to get property 'occational' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Trying to get property 'dateConvert' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:47:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 73
ERROR - 2022-08-23 10:48:32 --> Severity: Notice --> Undefined property: Creport::$occational C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 76
ERROR - 2022-08-23 10:48:32 --> Severity: Notice --> Trying to get property 'dateConvert' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 76
ERROR - 2022-08-23 10:48:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 76
ERROR - 2022-08-23 10:48:32 --> Severity: Notice --> Undefined property: Creport::$occational C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 76
ERROR - 2022-08-23 10:48:32 --> Severity: Notice --> Trying to get property 'dateConvert' of non-object C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 76
ERROR - 2022-08-23 10:48:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\report\manage_stock_taking.php 76
ERROR - 2022-08-23 10:50:07 --> Severity: Notice --> Undefined property: Creport::$occational C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 82
ERROR - 2022-08-23 10:50:07 --> Severity: error --> Exception: Call to a member function dateConvert() on null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 82
ERROR - 2022-08-23 10:50:09 --> Severity: Notice --> Undefined property: Creport::$occational C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 82
ERROR - 2022-08-23 10:50:09 --> Severity: error --> Exception: Call to a member function dateConvert() on null C:\laragon\www\git\erp_swapon\application\controllers\Creport.php 82
