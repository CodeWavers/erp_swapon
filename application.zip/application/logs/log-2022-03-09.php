<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-09 06:06:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-09 06:06:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-09 06:06:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-09 06:06:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-09 06:06:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-09 06:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:12:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 06:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:12:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 06:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 06:12:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:12:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 06:12:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 06:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:12:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 06:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:27:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:27:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 06:27:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 06:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 06:27:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 06:27:56 --> Query error: Unknown column 'a.sku' in 'where clause' - Invalid query: SELECT count(*) as allcount
FROM `product_information` `a`
WHERE (a.product_name like '%d%' or `a`.`product_model` like '%d%' or `a`.`sku` like '%d%'  or `a`.`product_id` like '%d%')
AND `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ERROR - 2022-03-09 06:27:58 --> Query error: Unknown column 'a.sku' in 'where clause' - Invalid query: SELECT count(*) as allcount
FROM `product_information` `a`
WHERE (a.product_name like '%dd%' or `a`.`product_model` like '%dd%' or `a`.`sku` like '%dd%'  or `a`.`product_id` like '%dd%')
AND `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ERROR - 2022-03-09 06:39:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2648
ERROR - 2022-03-09 06:39:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2648
ERROR - 2022-03-09 06:39:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2715
ERROR - 2022-03-09 06:39:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2715
ERROR - 2022-03-09 06:39:20 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-09 06:40:07 --> Severity: error --> Exception: Too few arguments to function CI_Input::server(), 0 passed in C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php on line 33 and at least 1 expected C:\laragon\www\git\erp_swapon\system\core\Input.php 314
ERROR - 2022-03-09 06:42:37 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 35
ERROR - 2022-03-09 06:51:37 --> Severity: error --> Exception: Too few arguments to function CI_Input::server(), 0 passed in C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php on line 33 and at least 1 expected C:\laragon\www\git\erp_swapon\system\core\Input.php 314
ERROR - 2022-03-09 07:20:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:20:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 07:20:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 07:20:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 07:20:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:20:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:20:22 --> Query error: Unknown column 'b.name' in 'where clause' - Invalid query: SELECT count(*) as allcount
FROM `product_information` `a`
WHERE (a.product_name like '%m%' or `a`.`product_model` like '%m%' or `a`.`sku` like '%m%' or `b`.`name` like '%m%'  or `a`.`product_id` like '%m%')
AND `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ERROR - 2022-03-09 07:20:25 --> Query error: Unknown column 'b.name' in 'where clause' - Invalid query: SELECT count(*) as allcount
FROM `product_information` `a`
WHERE (a.product_name like '%men%' or `a`.`product_model` like '%men%' or `a`.`sku` like '%men%' or `b`.`name` like '%men%'  or `a`.`product_id` like '%men%')
AND `a`.`finished_raw` = '1'
GROUP BY `a`.`product_id`
ERROR - 2022-03-09 07:22:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:22:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 07:22:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 07:22:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 07:22:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:22:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:23:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:23:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 07:23:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 07:23:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:23:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:23:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 07:27:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:27:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 07:27:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 07:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:27:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 07:27:54 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-03-09 07:27:54 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-03-09 07:27:54 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-03-09 07:27:54 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-03-09 07:27:54 --> Severity: Notice --> Undefined property: stdClass::$name C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-03-09 07:29:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:29:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 07:29:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 07:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 07:29:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 07:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 08:30:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 08:30:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 08:30:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 08:30:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 08:30:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 08:30:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 08:30:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 08:30:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 08:30:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 08:30:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 08:30:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 08:30:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 08:41:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1213
ERROR - 2022-03-09 08:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 1199
ERROR - 2022-03-09 08:44:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 08:44:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 08:44:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 08:44:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 08:44:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 08:44:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:23:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 10:23:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 10:23:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 10:23:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 10:23:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:23:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:23:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:23:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:23:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:23:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:24:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 10:24:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 10:24:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 10:24:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 10:24:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:24:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:24:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:24:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:24:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:24:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:24:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:24:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:27:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 10:27:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-09 10:27:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 10:27:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-09 10:27:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:27:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-09 10:27:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:27:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:27:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:27:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:27:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:27:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:28:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:28:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:28:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:28:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:31:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:31:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:31:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:31:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:31:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:32:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:32:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:32:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:32:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:32:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:32:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:32:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:32:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:32:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:32:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:33:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:33:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:33:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:33:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:33:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:33:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:33:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:33:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:33:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:33:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:33:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:45:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:45:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:45:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:45:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:45:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:46:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:46:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:46:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:46:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:46:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:46:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:49:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:49:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:50:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:50:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:50:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:50:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:51:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:51:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:51:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:56:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:56:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:56:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:56:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:59:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:59:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 10:59:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 10:59:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 10:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 10:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:02:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 11:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:02:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 11:02:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 11:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 11:03:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 11:03:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:03:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:03:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 11:22:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:22:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 11:22:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:22:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 11:22:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 11:22:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-09 11:30:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-09 11:30:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:30:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-09 11:30:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-09 11:41:27 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
