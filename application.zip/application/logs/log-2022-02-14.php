<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-14 08:53:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-14 08:55:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-14 09:00:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:00:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:00:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:00:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:00:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:00:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:00:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:00:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:00:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:00:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:01:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:01:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:41 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:41 --> Severity: Notice --> Trying to get property 'product_status' of non-object C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:41 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:41 --> Severity: Notice --> Trying to get property 'product_status' of non-object C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:01:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:01:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:01:59 --> Severity: Notice --> Undefined property: stdClass::$product_status C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:01:59 --> Severity: Notice --> Undefined property: stdClass::$product_status C:\xampp\htdocs\erp_swapon\application\models\Products.php 175
ERROR - 2022-02-14 09:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:02:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:02:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:02:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:02:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:02:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:02:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:02:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:03:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:03:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:03:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:03:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:03:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:03:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:05:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:05:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:05:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:05:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:06:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\erp_swapon\application\controllers\Cproduct.php 1186
ERROR - 2022-02-14 09:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:07:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:07:26 --> Query error: Unknown table 'erp_swapon.x' - Invalid query: SELECT `a`.*, `k`.`color_name`, `l`.`size_name`, `x`.*, `d`.*
FROM `product_information` `a`
LEFT JOIN `product_type` `d` ON `d`.`ptype_id` = `a`.`ptype_id`
LEFT JOIN `color_list` `k` ON `k`.`color_id` = `a`.`color`
LEFT JOIN `size_list` `l` ON `l`.`size_id` = `a`.`size`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 09:07:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:07:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:07:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:07:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:11:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:11:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:11:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:11:29 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*
FROM `product_information` `a`
LEFT JOIN `products` `b` ON `a`.`product_id` = `b`.`barcode`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 09:15:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:15:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:15:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:15:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:15:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:15:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:15:08 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `b`.*
FROM `product_information` `a`
JOIN `products` `b` ON `b`.`barcode` = `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 09:18:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:18:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:18:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:18:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:18:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:18:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:18:35 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `product_information`.*, `products`.*
FROM `product_information`
LEFT JOIN `products` ON `product_information`.`product_id` = `products`.`barcode`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 09:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:22:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:22:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:22:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:22:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:22:10 --> Query error: Unknown column 'product_information.product_id`products.barcode' in 'on clause' - Invalid query: SELECT `product_information`.*, `products`.*
FROM `product_information`
LEFT JOIN `products` ON `product_information`.`product_id``products`.`barcode`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 09:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:22:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:22:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:22:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:22:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:22:47 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `product_information`.*, `products`.*
FROM `product_information`
LEFT JOIN `products` ON `product_information`.`product_id` = `products`.`barcode`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 09:25:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:25:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:25:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:25:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:25:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:25:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:25:46 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT *
FROM `product_information` `a`
LEFT JOIN `products` `p` ON `p`.`barcode` = `a`.`product_id`
ERROR - 2022-02-14 09:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:30:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:30:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:30:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:30:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:30:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:30:24 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT *
FROM `product_information` `a`
LEFT JOIN `products` `p` ON `p`.`barcode` = `a`.`product_id`
ERROR - 2022-02-14 09:37:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:37:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:37:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:37:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:37:49 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT *
FROM `product_information` `a`
LEFT JOIN `products` `p` ON `p`.`barcode` = `a`.`product_id`
ERROR - 2022-02-14 09:43:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:43:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:43:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:43:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:43:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:43:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:45:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:45:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:45:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:45:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:45:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:54:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:54:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:54:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:54:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:54:27 --> Query error: Illegal mix of collations (utf8_unicode_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.*, `a`.`product_name`, `a`.`product_id`, `a`.`product_model`, `a`.`finished_raw`, `a`.`image`
FROM `product_information` `a`
LEFT JOIN `products` `k` ON `k`.`barcode` = `a`.`product_id`
ORDER BY `product_name` ASC
 LIMIT 10
ERROR - 2022-02-14 14:55:12 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.`unit`, `a`.`product_name`, `a`.`product_id`, `a`.`price`, `a`.`product_model`, (select sum(quantity) from invoice_details where product_id= `a`.`product_id`) as 'totalSalesQnty', (select sum(quantity) from product_purchase_details where product_id= `a`.`product_id`) as 'totalBuyQnty'
FROM `product_information` `a`
WHERE `a`.`status` = 1
GROUP BY `a`.`product_id`
ERROR - 2022-02-14 09:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 14:55:25 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.`unit`, `a`.`product_name`, `a`.`product_id`, `a`.`price`, `a`.`product_model`, (select sum(quantity) from invoice_details where product_id= `a`.`product_id`) as 'totalSalesQnty', (select sum(quantity) from product_purchase_details where product_id= `a`.`product_id`) as 'totalBuyQnty'
FROM `product_information` `a`
WHERE `a`.`status` = 1
GROUP BY `a`.`product_id`
ERROR - 2022-02-14 09:55:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:55:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 14:55:41 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.`unit`, `a`.`product_name`, `a`.`product_id`, `a`.`price`, `a`.`product_model`, (select sum(quantity) from invoice_details where product_id= `a`.`product_id`) as 'totalSalesQnty', (select sum(quantity) from product_purchase_details where product_id= `a`.`product_id`) as 'totalBuyQnty'
FROM `product_information` `a`
WHERE `a`.`status` = 1
GROUP BY `a`.`product_id`
ERROR - 2022-02-14 09:55:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 14:55:53 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.`unit`, `a`.`product_name`, `a`.`product_id`, `a`.`price`, `a`.`product_model`, (select sum(quantity) from invoice_details where product_id= `a`.`product_id`) as 'totalSalesQnty', (select sum(quantity) from product_purchase_details where product_id= `a`.`product_id`) as 'totalBuyQnty'
FROM `product_information` `a`
WHERE `a`.`status` = 1
GROUP BY `a`.`product_id`
ERROR - 2022-02-14 09:55:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:55:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 14:55:56 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.`unit`, `a`.`product_name`, `a`.`product_id`, `a`.`price`, `a`.`product_model`, (select sum(quantity) from invoice_details where product_id= `a`.`product_id`) as 'totalSalesQnty', (select sum(quantity) from product_purchase_details where product_id= `a`.`product_id`) as 'totalBuyQnty'
FROM `product_information` `a`
WHERE `a`.`status` = 1
GROUP BY `a`.`product_id`
ERROR - 2022-02-14 14:56:58 --> Query error: Illegal mix of collations (utf8_general_ci,IMPLICIT) and (utf8_unicode_ci,IMPLICIT) for operation '=' - Invalid query: SELECT `a`.`unit`, `a`.`product_name`, `a`.`product_id`, `a`.`price`, `a`.`product_model`, (select sum(quantity) from invoice_details where product_id= `a`.`product_id`) as 'totalSalesQnty', (select sum(quantity) from product_purchase_details where product_id= `a`.`product_id`) as 'totalBuyQnty'
FROM `product_information` `a`
WHERE `a`.`status` = 1
GROUP BY `a`.`product_id`
ERROR - 2022-02-14 09:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:58:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:58:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:58:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:58:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:58:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:58:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:58:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:59:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 166
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 167
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 169
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 166
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 167
ERROR - 2022-02-14 09:59:03 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 169
ERROR - 2022-02-14 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:59:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:59:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:59:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 09:59:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 09:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 09:59:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 166
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 167
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 169
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$category_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 166
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 167
ERROR - 2022-02-14 09:59:26 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 169
ERROR - 2022-02-14 10:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 10:00:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 10:00:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 10:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:00:31 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 161
ERROR - 2022-02-14 10:00:31 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 162
ERROR - 2022-02-14 10:00:31 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 10:00:31 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 161
ERROR - 2022-02-14 10:00:31 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 162
ERROR - 2022-02-14 10:00:31 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 10:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 10:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:01:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 10:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:01:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 10:01:37 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 161
ERROR - 2022-02-14 10:01:37 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 162
ERROR - 2022-02-14 10:01:37 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 10:01:37 --> Severity: Notice --> Undefined property: stdClass::$ptype_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 161
ERROR - 2022-02-14 10:01:37 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 162
ERROR - 2022-02-14 10:01:37 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\xampp\htdocs\erp_swapon\application\models\Products.php 164
ERROR - 2022-02-14 10:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:02:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-14 10:02:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-14 10:02:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-14 10:02:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-14 10:02:11 --> 404 Page Not Found: Assets/js
