<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-19 10:45:42 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-19 10:47:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:50:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:50:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:51:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:52:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:53:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:53:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 10:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:53:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 10:53:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 10:56:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:56:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 10:56:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 10:56:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:56:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 10:56:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:56:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:56:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 10:56:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:56:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 10:56:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 10:56:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 10:57:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 10:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:57:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:57:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 10:57:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 10:57:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:57:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 10:57:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 10:57:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 10:57:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 10:57:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:00:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 11:00:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:00:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 11:00:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:00:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 11:00:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 11:00:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 11:01:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:01:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 11:01:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 11:01:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:01:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 11:01:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:03:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 11:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:03:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 11:03:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 11:03:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:03:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 11:03:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 11:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 11:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:03:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 11:03:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 11:03:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 11:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:04:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 11:04:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 11:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:04:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 11:04:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 11:04:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 11:35:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 12:23:59 --> The upload path does not appear to be valid.
ERROR - 2022-09-19 12:23:59 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7979341263', 'INV-CC', '2022-09-19', NULL, 'Customer debit For Invoice No -  1015 Customer ', '21216.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-19 12:23:59', 1)
ERROR - 2022-09-19 12:23:59 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 994
ERROR - 2022-09-19 12:24:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 12:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 12:26:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 12:31:08 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '341735362585752', NULL, '7612865995', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 1)
ERROR - 2022-09-19 12:31:08 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '355136733722944', NULL, '7612865995', '16954P', '119', '2', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '5400', NULL, '', 1)
ERROR - 2022-09-19 12:47:21 --> The upload path does not appear to be valid.
ERROR - 2022-09-19 12:47:21 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 994
ERROR - 2022-09-19 12:55:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 12:58:35 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '491134815441788', NULL, '2632538872', '16945P', '119', '5', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '18400', NULL, '', 1)
ERROR - 2022-09-19 12:58:35 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '861685683554383', NULL, '2632538872', '16954P', '119', '4', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '10800', NULL, '', 1)
ERROR - 2022-09-19 13:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 747
ERROR - 2022-09-19 13:28:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 13:33:38 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '984531979126654', NULL, '9256743974', '16945P', '119', '5', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '18400', NULL, '', 1)
ERROR - 2022-09-19 13:33:38 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '668955364629341', NULL, '9256743974', '16954P', '119', '4', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '10800', NULL, '', 1)
ERROR - 2022-09-19 13:34:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 13:34:55 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '131528298384996', NULL, '2932386932', '16945P', '119', '5', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '18400', NULL, '', 1)
ERROR - 2022-09-19 13:34:55 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '728398324526372', NULL, '2932386932', '16954P', '119', '4', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '10800', NULL, '', 1)
ERROR - 2022-09-19 13:35:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:28:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:29:05 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '952214763613685', NULL, '5421688952', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 1)
ERROR - 2022-09-19 14:29:05 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '888359613323728', NULL, '5421688952', '16954P', '119', '2', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '5400', NULL, '', 1)
ERROR - 2022-09-19 14:35:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:35:24 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '228569347884766', NULL, '8283668617', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 1)
ERROR - 2022-09-19 14:35:24 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '417838125281431', NULL, '8283668617', '16954P', '119', '2', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '5400', NULL, '', 1)
ERROR - 2022-09-19 14:35:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:36:19 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '667612362174956', NULL, '3599314255', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 1)
ERROR - 2022-09-19 14:36:19 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '534352571697568', NULL, '3599314255', '16954P', '119', '2', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '5400', NULL, '', 1)
ERROR - 2022-09-19 14:36:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:37:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 14:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 14:37:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 14:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 14:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 14:37:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 14:37:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:37:51 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '143948652717357', NULL, '3326735953', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 1)
ERROR - 2022-09-19 14:37:51 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '215455844593648', NULL, '3326735953', '16954P', '119', '2', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '5400', NULL, '', 1)
ERROR - 2022-09-19 14:50:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 14:51:34 --> Query error: Table 'erp_swapon.return' doesn't exist - Invalid query: SELECT MAX(`Return`) AS `Return`
FROM `Return`
ERROR - 2022-09-19 14:51:34 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1484
ERROR - 2022-09-19 14:51:59 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 14:51:59 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '466745312653836', NULL, '4837129766', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 2)
ERROR - 2022-09-19 14:51:59 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 14:51:59 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '281847746341842', NULL, '4837129766', '16954P', '119', '2', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '5400', NULL, '', 2)
ERROR - 2022-09-19 15:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:27:18 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 15:27:18 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '349174657569119', NULL, '6368319581', '16945P', '119', '3', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '11040', NULL, '', 2)
ERROR - 2022-09-19 15:33:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:33:49 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 15:33:49 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '476814319413174', NULL, '3796217878', '16945P', '119', '5', '5', '2022-09-19', '2022-09-19', '4000.00', '1', '3784.00', 0, '18400', NULL, '', 2)
ERROR - 2022-09-19 15:33:49 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 15:33:49 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '714992695955898', NULL, '3796217878', '16954P', '119', '4', '4', '2022-09-19', '2022-09-19', '3000.00', '0', '3784.00', 0, '10800', NULL, '', 2)
ERROR - 2022-09-19 15:37:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:37:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:37:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:37:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:37:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:37:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:37:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:38:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:38:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:38:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:38:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:38:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:38:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:42:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:42:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:42:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:42:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:43:41 --> The upload path does not appear to be valid.
ERROR - 2022-09-19 15:43:41 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6966148291', 'INV-CC', '2022-09-19', NULL, 'Customer debit For Invoice No -  1028 Customer ', '9000.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-09-19 15:43:41', 1)
ERROR - 2022-09-19 15:43:41 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 994
ERROR - 2022-09-19 15:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:43:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:43:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:43:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:43:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:43:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:43:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:43:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:43:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:43:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:44:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:44:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:44:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:44:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:44:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:44:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:44:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:44:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:44:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:44:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:45:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:45:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:45:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:45:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:45:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:45:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:46:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:46:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:46:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:46:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:46:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:46:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:46:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:46:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:46:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:46:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:46:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:46:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:46:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:52:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:52:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:52:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:54:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:54:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:54:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 15:56:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:56:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:56:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:56:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:56:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 15:56:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:57:56 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 15:57:56 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '444749514554219', NULL, '6975162623', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 15:57:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:57:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 15:57:58 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 15:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:57:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 15:57:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:01:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:01:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:01:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:01:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:01:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:01:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:01:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:01:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:01:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:01:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:01:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:06:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:06:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:06:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:06:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:06:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:06:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:06:59 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 964
ERROR - 2022-09-19 16:06:59 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '392187728625171', NULL, '9261768124', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 16:26:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:26:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:32:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:32:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:32:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:32:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:32:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:33:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:33:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:33:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:33:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:33:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:33:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:34:32 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:34:32 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '219852139379951', NULL, '5795673171', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:34:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1116
ERROR - 2022-09-19 16:34:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:34:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:34:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:34:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:34:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:34:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:34:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:34:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:34:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:34:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:34:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:36:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:36:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:36:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:36:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:36:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:37:04 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:37:04 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '391439223229839', NULL, '4486247496', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:37:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1116
ERROR - 2022-09-19 16:37:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:37:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:37:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:37:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:37:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:37:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:38:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:38:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:38:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:39:18 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:39:18 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '268395616656516', NULL, '4493499117', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:39:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1104
ERROR - 2022-09-19 16:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:39:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:39:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:39:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:45:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:45:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:45:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:45:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:45:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:47:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:47:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:47:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:47:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:47:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:47:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:47:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:47:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:47:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:47:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:47:50 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:47:50 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '324947952215691', NULL, '2135641198', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:48:11 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:48:11 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '164153682267488', NULL, '7529515516', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:49:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:49:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:49:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:49:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:49:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:49:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:49:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:49:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:49:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:53:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:53:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:53:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:53:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:53:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:53:26 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:53:26 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '454858944897487', NULL, '7363788724', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:53:43 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:53:43 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '466696171612977', NULL, '1939689527', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:53:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Returnse.php 1107
ERROR - 2022-09-19 16:53:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:53:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:55:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:55:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:55:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 16:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:57:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:57:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:51 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 16:57:51 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '678415512341851', NULL, '4125856816', '16945P', '119', '5', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '5000', NULL, '', 2)
ERROR - 2022-09-19 16:57:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:57:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 16:57:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 16:57:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 16:57:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 16:57:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:01:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:01:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:01:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:01:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:01:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:01:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:01:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:03:30 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 17:03:30 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '843266123699177', NULL, '6575357436', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 17:03:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:03:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:03:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:03:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:03:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:03:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:03:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:03:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:03:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:07:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:07:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:07:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:07:55 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 17:07:55 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '276494769323852', NULL, '7692312297', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 17:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:07:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:07:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:08:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:08:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:08:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:08:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:08:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:08:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:08:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:09:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:09:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:09:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:09:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:09:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:09:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:09:36 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 17:09:36 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '589888973675821', NULL, '8793281251', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 17:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:09:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:10:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:10:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:10:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:10:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:10:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:10:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:10:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:10:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:10:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:10:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:10:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:10:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:10:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:11:15 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 17:11:15 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '995759345882959', NULL, '9154283427', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 17:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:11:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:11:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:11:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:11:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:11:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:11:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:11:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:11:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:11:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:11:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:12:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:12:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:12:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:12:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:12:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:12:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:12:30 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 17:12:30 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '882991437468272', NULL, '5354544668', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
ERROR - 2022-09-19 17:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:12:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:12:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:12:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:12:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:17:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:17:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:17:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:17:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:17:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:17:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:17:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:17:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-19 17:17:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 748
ERROR - 2022-09-19 17:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:21:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-19 17:21:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-19 17:21:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-19 17:22:07 --> Severity: Warning --> Illegal string offset 'supplier_price' C:\laragon\www\git\erp_swapon\application\models\Returnse.php 966
ERROR - 2022-09-19 17:22:07 --> Query error: Column 'invoice_id' cannot be null - Invalid query: INSERT INTO `product_return` (`outlet_id`, `return_id`, `invoice_id`, `invoice_id_new`, `product_id`, `customer_id`, `ret_qty`, `byy_qty`, `date_purchase`, `date_return`, `product_rate`, `deduction`, `total_deduct`, `delivery_charge`, `total_ret_amount`, `net_total_amount`, `reason`, `usablity`) VALUES ('HK7TGDT69VFMXB7', '523847865965928', NULL, '5412295191', '16945P', '119', '10', '10', '2022-09-19', '2022-09-19', '1000.00', '', '1000.00', 0, '10000', NULL, '', 2)
