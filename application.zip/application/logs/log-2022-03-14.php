<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-14 05:22:02 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-14 05:22:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:23:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:23:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:31:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:32:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:35:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:35:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:35:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:36:20 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:37:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:37:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:38:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:38:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:40:13 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:40:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:41:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:41:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:42:31 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:42:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:43:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:46:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:48:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:48:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:51:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:53:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 05:56:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:00:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:00:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:00:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:01:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:05:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:05:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:06:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:06:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:07:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:08:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:09:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:13:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:14:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:14:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:14:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:15:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:20:13 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:20:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:20:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:21:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:21:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:26:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:26:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:27:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:28:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:29:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:29:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:31:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:31:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:32:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:35:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:35:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:36:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:37:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:38:02 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:38:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:38:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:39:12 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:39:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:40:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:40:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:40:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:42:37 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:44:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:45:14 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:46:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:50:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:51:06 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:51:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:51:42 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:51:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:52:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:52:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:53:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:53:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:53:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:54:18 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 06:55:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:02:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:06:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:08:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:10:13 --> 404 Page Not Found: Cinvoice/add_new_sales
ERROR - 2022-03-14 07:11:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:13:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:30:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:31:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:31:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:31:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:32:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:32:40 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:33:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:34:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:34:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:35:16 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:35:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:36:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:37:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:37:58 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:38:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:39:30 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:39:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:40:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:40:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:41:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:41:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:43:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:44:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:45:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:45:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:46:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:46:53 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:48:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:49:15 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:49:45 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:50:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:50:15 --> 404 Page Not Found: Cinvoice/add_new_sales
ERROR - 2022-03-14 07:50:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:51:05 --> 404 Page Not Found: Cinvoice/manage_sale
ERROR - 2022-03-14 07:51:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:52:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:53:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:55:47 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:58:08 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:58:56 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:59:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 07:59:44 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:00:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:01:12 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:01:33 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:04:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-14 08:05:10 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:06:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:07:32 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 08:08:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 12:40:53 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-14 12:47:19 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-14 13:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:03:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 13:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:03:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 13:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 13:04:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:04:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 13:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:04:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 13:04:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 13:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:27:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 13:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:27:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 13:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:27:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 13:27:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:27:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 13:27:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 13:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:27:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 13:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 13:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 13:53:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:01:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:03:26 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:17:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 350
ERROR - 2022-03-14 14:17:52 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 350
ERROR - 2022-03-14 14:17:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:19:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 358
ERROR - 2022-03-14 14:19:11 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 358
ERROR - 2022-03-14 14:19:11 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:19:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 358
ERROR - 2022-03-14 14:19:48 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 358
ERROR - 2022-03-14 14:19:49 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:20:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 354
ERROR - 2022-03-14 14:20:18 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 354
ERROR - 2022-03-14 14:20:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:21:25 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 354
ERROR - 2022-03-14 14:21:25 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 354
ERROR - 2022-03-14 14:21:26 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:23:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:23:20 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:23:21 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:23:45 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:23:45 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:23:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:24:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:24:03 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:24:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:25:22 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:25:22 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:25:22 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:55:05 --> Severity: error --> Exception: Object of class stdClass could not be converted to string C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 116
ERROR - 2022-03-14 14:57:54 --> 404 Page Not Found: Corder/Corder
ERROR - 2022-03-14 14:58:37 --> 404 Page Not Found: Corder/C
ERROR - 2022-03-14 14:59:22 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:59:22 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:59:23 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 14:59:42 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:59:42 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 14:59:43 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 15:19:55 --> Query error: Not unique table/alias: 'c' - Invalid query: SELECT `a`.*, `cr`.*, `br`.*, `a`.`due_amount` as `due_amnt`, `a`.`paid_amount` as `p_amnt`, sum(c.quantity) as sum_quantity, `a`.`total_tax` as `taxs`, `a`. `prevous_due`, `b`.`customer_name`, `c`.*, `c`.`tax` as `total_tax`, `c`.`product_id`, `d`.`product_name`, `d`.`product_model`, `d`.`tax`, `d`.`unit`, `d`.*
FROM `invoice` `a`
JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `courier_name` `cr` ON `cr`.`courier_id` = `a`.`courier_id`
LEFT JOIN `branch_name` `br` ON `br`.`branch_id` = `a`.`branch_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
JOIN `product_information` `d` ON `d`.`product_id` = `c`.`product_id`
WHERE `a`.`invoice_id` = '2981954887'
GROUP BY `d`.`product_id`
ERROR - 2022-03-14 15:19:55 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1590
ERROR - 2022-03-14 15:20:05 --> Query error: Not unique table/alias: 'c' - Invalid query: SELECT `a`.*, `cr`.*, `br`.*, `a`.`due_amount` as `due_amnt`, `a`.`paid_amount` as `p_amnt`, sum(c.quantity) as sum_quantity, `a`.`total_tax` as `taxs`, `a`. `prevous_due`, `b`.`customer_name`, `c`.*, `c`.`tax` as `total_tax`, `c`.`product_id`, `d`.`product_name`, `d`.`product_model`, `d`.`tax`, `d`.`unit`, `d`.*
FROM `invoice` `a`
JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `courier_name` `cr` ON `cr`.`courier_id` = `a`.`courier_id`
LEFT JOIN `branch_name` `br` ON `br`.`branch_id` = `a`.`branch_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
JOIN `product_information` `d` ON `d`.`product_id` = `c`.`product_id`
WHERE `a`.`invoice_id` = '2981954887'
GROUP BY `d`.`product_id`
ERROR - 2022-03-14 15:20:05 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1590
ERROR - 2022-03-14 15:20:52 --> Query error: Not unique table/alias: 'c' - Invalid query: SELECT `a`.*, `cr`.*, `br`.*, `a`.`due_amount` as `due_amnt`, `a`.`paid_amount` as `p_amnt`, sum(c.quantity) as sum_quantity, `a`.`total_tax` as `taxs`, `a`. `prevous_due`, `b`.`customer_name`, `c`.*, `c`.`tax` as `total_tax`, `c`.`product_id`, `d`.`product_name`, `d`.`product_model`, `d`.`tax`, `d`.`unit`, `d`.*
FROM `invoice` `a`
JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `courier_name` `cr` ON `cr`.`courier_id` = `a`.`courier_id`
LEFT JOIN `branch_name` `br` ON `br`.`branch_id` = `a`.`branch_id`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
JOIN `product_information` `d` ON `d`.`product_id` = `c`.`product_id`
WHERE `a`.`invoice_id` = '2981954887'
GROUP BY `d`.`product_id`
ERROR - 2022-03-14 15:20:52 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1590
ERROR - 2022-03-14 15:26:23 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 15:26:23 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\invoice_html_manual.php 353
ERROR - 2022-03-14 15:26:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 15:35:05 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-14 15:59:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-14 16:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:00:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 16:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:00:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 16:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 16:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 16:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:00:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 16:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:00:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 16:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-14 16:03:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:03:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 16:04:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-14 16:04:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:04:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-14 16:04:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
ERROR - 2022-03-14 16:04:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:04:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 16:10:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:10:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 16:10:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-14 16:10:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-14 16:18:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\models\Order.php 307
