<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-02 04:54:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-02 04:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-02 04:54:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-02 04:54:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-02 04:54:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-02 07:33:23 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 294
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:15 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:28 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:43:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:54:16 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:54:16 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 07:54:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `customer_information` (0) VALUES (Array)
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:49 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:58:55 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php 315
ERROR - 2022-03-02 07:59:47 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 07:59:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `customer_information` (0) VALUES (Array)
ERROR - 2022-03-02 08:00:36 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `customer_information` (0) VALUES (Array)
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:00:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22' at line 1 - Invalid query: INSERT INTO `customer_information` (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98) VALUES (Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2022-03-02 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Severity: Notice --> Array to string conversion C:\laragon\www\git\erp_swapon\system\database\DB_driver.php 1471
ERROR - 2022-03-02 08:01:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22' at line 1 - Invalid query: INSERT INTO `customer_information` (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98) VALUES (Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array, Array)
ERROR - 2022-03-02 08:01:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\application\controllers\Ccustomer.php:327) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-03-02 08:03:31 --> Query error: Column 'customer_mobile' cannot be null - Invalid query: INSERT INTO `customer_information` (`customer_name`, `customer_mobile`, `zip`, `country`, `customer_email`, `city`, `customer_address`) VALUES ('BYNTAKCSfjLwPWyQ', NULL, NULL, NULL, 'bjoan733@gmail.com', NULL, NULL)
ERROR - 2022-03-02 17:30:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-02 17:30:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-03-02 17:30:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-02 17:30:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-03-02 17:30:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
