<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-11 12:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 12:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 13:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:07:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 710
ERROR - 2022-09-11 14:09:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:11:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:13:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:13:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:13:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:21:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:21:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:21:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:21:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:21:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:21:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:23:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:23:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:23:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:23:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:23:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:23:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:23:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:25:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:25:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:25:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:25:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:32:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:32:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:32:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:32:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:32:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:32:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:32:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:32:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:34:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:34:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:34:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:34:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:34:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:34:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:35:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:35:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:35:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:35:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:35:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:37:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:37:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:37:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-11 14:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-11 14:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-11 14:37:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-11 14:37:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:40:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:41:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:43:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:47:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 14:49:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 15:17:20 --> The upload path does not appear to be valid.
ERROR - 2022-09-11 15:17:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 15:19:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Returnse.php 776
ERROR - 2022-09-11 15:19:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-09-11 15:39:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 16:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 16:13:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-09-11 16:46:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\git\erp_swapon\application\views\invoice\pos_dell_arte_invoice_html_manual.php 320
ERROR - 2022-09-11 16:46:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\git\erp_swapon\application\views\invoice\pos_dell_arte_invoice_html_manual.php 320
ERROR - 2022-09-11 16:50:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.`is_return`
FROM `invoice` `a`
JOIN `invoice_details` `c` ON `c`.`invoice_id` =' at line 1 - Invalid query: SELECT `a`.`total_tax`, `a`.*, `b`.*, `c`.*, `d`.`product_id`, `d`.`product_name`, `d`.`sku`, `d`.`image`, `d`.`product_details`, `d`.`unit`, `d`.`product_model`, `d`.`price`, `a`.`paid_amount` as `paid_amount`, `a`.`due_amount` as `due_amount`, `m`.`color_name`, `n`.`size_name`, `e`.`branch_name`, `f`.`courier_name`, `o`.`receiver_name`, `a`.`receiver_number` as `rec_num`, `c`.`quantity`, `c`.`total_price_wd` `c`.`is_return`
FROM `invoice` `a`
JOIN `invoice_details` `c` ON `c`.`invoice_id` = `a`.`invoice_id`
LEFT JOIN `customer_information` `b` ON `b`.`customer_id` = `a`.`customer_id`
JOIN `product_information` `d` ON `d`.`product_id` = `c`.`product_id`
LEFT JOIN `color_list` `m` ON `m`.`color_id` = `d`.`color`
LEFT JOIN `size_list` `n` ON `n`.`size_id` = `d`.`size`
LEFT JOIN `branch_name` `e` ON `e`.`branch_id` = `a`.`branch_id`
LEFT JOIN `courier_name` `f` ON `f`.`courier_id` = `a`.`courier_id`
LEFT JOIN `receiever_info` `o` ON `o`.`id` = `a`.`reciever_id`
WHERE `a`.`invoice_id` = '9869374778'
GROUP BY `d`.`product_id`
ERROR - 2022-09-11 16:50:53 --> Severity: error --> Exception: Call to a member function num_rows() on bool C:\laragon\www\git\erp_swapon\application\models\Invoices.php 3495
ERROR - 2022-09-11 17:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 17:29:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 17:29:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 17:29:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 17:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
ERROR - 2022-09-11 17:40:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 709
