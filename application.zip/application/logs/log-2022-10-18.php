<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-18 10:43:53 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-18 10:53:07 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-18 10:53:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 10:53:14 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-18 10:53:17 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-18 11:05:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:05:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:05:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 11:05:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:06:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:06:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 11:06:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:12:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:12:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 11:12:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1187
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:13:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1202
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1203
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type float C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1208
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 72
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 72
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 72
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 76
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 76
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 76
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 79
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 79
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 79
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 81
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 81
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 81
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 83
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 83
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 83
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: i C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 139
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 139
ERROR - 2022-10-18 11:13:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 355
ERROR - 2022-10-18 11:13:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 411
ERROR - 2022-10-18 11:13:55 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 512
ERROR - 2022-10-18 11:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 355
ERROR - 2022-10-18 11:14:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 411
ERROR - 2022-10-18 11:17:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 379
ERROR - 2022-10-18 11:17:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 435
ERROR - 2022-10-18 11:17:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 355
ERROR - 2022-10-18 11:17:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 411
ERROR - 2022-10-18 11:18:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 379
ERROR - 2022-10-18 11:18:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 435
ERROR - 2022-10-18 11:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:24:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:25:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:25:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:25:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 11:25:31 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-18 11:27:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 11:27:16 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-18 11:27:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 11:27:17 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-18 11:27:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:27:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:28:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:28:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 365
ERROR - 2022-10-18 11:29:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 421
ERROR - 2022-10-18 11:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 11:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 11:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 11:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 11:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 11:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 11:40:09 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1218
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:42:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1203
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1204
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:42:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:42:18 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1218
ERROR - 2022-10-18 11:42:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:47:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:48:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:48:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:49:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:52:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:52:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:55:20 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1565
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Undefined variable: arr_ind_in C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1566
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1516
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1528
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1529
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1530
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1531
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1532
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1533
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:56:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 1534
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Undefined variable: fdate C:\laragon\www\git\erp_swapon\application\models\Reports.php 316
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1204
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1205
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: i C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 151
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 151
ERROR - 2022-10-18 11:56:38 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 173
ERROR - 2022-10-18 11:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 11:56:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 11:56:38 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 524
ERROR - 2022-10-18 11:56:49 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 173
ERROR - 2022-10-18 11:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 11:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 12:04:34 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-18 12:06:17 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 185
ERROR - 2022-10-18 12:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 379
ERROR - 2022-10-18 12:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 435
ERROR - 2022-10-18 12:21:51 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 185
ERROR - 2022-10-18 12:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 379
ERROR - 2022-10-18 12:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 435
ERROR - 2022-10-18 12:23:06 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 185
ERROR - 2022-10-18 12:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 379
ERROR - 2022-10-18 12:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 435
ERROR - 2022-10-18 12:54:11 --> Severity: Warning --> number_format() expects parameter 1 to be float, array given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 197
ERROR - 2022-10-18 12:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 391
ERROR - 2022-10-18 12:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 447
ERROR - 2022-10-18 13:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 13:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 458
ERROR - 2022-10-18 13:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 364
ERROR - 2022-10-18 13:08:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 420
ERROR - 2022-10-18 13:19:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:19:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:20:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:21:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:21:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:21:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:26:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:26:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:55:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 13:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 368
ERROR - 2022-10-18 13:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 424
ERROR - 2022-10-18 14:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 371
ERROR - 2022-10-18 14:00:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 427
ERROR - 2022-10-18 14:01:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 375
ERROR - 2022-10-18 14:01:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 431
ERROR - 2022-10-18 14:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 371
ERROR - 2022-10-18 14:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 427
ERROR - 2022-10-18 14:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 14:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 14:20:58 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 296
ERROR - 2022-10-18 14:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 14:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 14:23:00 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 296
ERROR - 2022-10-18 14:23:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 367
ERROR - 2022-10-18 14:23:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 423
ERROR - 2022-10-18 14:29:09 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 316
ERROR - 2022-10-18 14:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 387
ERROR - 2022-10-18 14:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 443
ERROR - 2022-10-18 14:29:46 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 316
ERROR - 2022-10-18 14:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 387
ERROR - 2022-10-18 14:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 443
ERROR - 2022-10-18 14:30:57 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 316
ERROR - 2022-10-18 14:30:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 387
ERROR - 2022-10-18 14:30:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 443
ERROR - 2022-10-18 14:31:55 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 314
ERROR - 2022-10-18 14:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 385
ERROR - 2022-10-18 14:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 441
ERROR - 2022-10-18 14:34:52 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 314
ERROR - 2022-10-18 14:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 385
ERROR - 2022-10-18 14:34:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 441
ERROR - 2022-10-18 14:37:25 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 321
ERROR - 2022-10-18 14:37:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 392
ERROR - 2022-10-18 14:37:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 448
ERROR - 2022-10-18 14:37:49 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 321
ERROR - 2022-10-18 14:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 392
ERROR - 2022-10-18 14:37:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 448
ERROR - 2022-10-18 14:38:30 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 321
ERROR - 2022-10-18 14:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 392
ERROR - 2022-10-18 14:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 448
ERROR - 2022-10-18 14:48:10 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 322
ERROR - 2022-10-18 14:48:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 393
ERROR - 2022-10-18 14:48:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 449
ERROR - 2022-10-18 14:51:03 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 322
ERROR - 2022-10-18 14:51:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 393
ERROR - 2022-10-18 14:51:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 449
ERROR - 2022-10-18 14:51:59 --> Severity: Warning --> Use of undefined constant total_sale - assumed 'total_sale' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 322
ERROR - 2022-10-18 14:51:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 393
ERROR - 2022-10-18 14:51:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 449
ERROR - 2022-10-18 14:53:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 393
ERROR - 2022-10-18 14:53:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 449
ERROR - 2022-10-18 14:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 381
ERROR - 2022-10-18 14:59:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 437
ERROR - 2022-10-18 14:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 393
ERROR - 2022-10-18 14:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 449
ERROR - 2022-10-18 15:04:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 449
ERROR - 2022-10-18 15:56:37 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1242
ERROR - 2022-10-18 15:57:16 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1242
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1577
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1188
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1188
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:17 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1209
ERROR - 2022-10-18 15:58:17 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1210
ERROR - 2022-10-18 15:58:17 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1242
ERROR - 2022-10-18 15:58:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1577
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1188
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1188
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 15:58:42 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1209
ERROR - 2022-10-18 15:58:42 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1210
ERROR - 2022-10-18 15:58:42 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1242
ERROR - 2022-10-18 15:58:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 15:59:24 --> Severity: error --> Exception: Unsupported operand types C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1242
ERROR - 2022-10-18 16:14:32 --> Severity: Warning --> Use of undefined constant total_i - assumed 'total_i' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 323
ERROR - 2022-10-18 16:14:32 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 323
ERROR - 2022-10-18 16:14:55 --> Severity: Warning --> Use of undefined constant total_i - assumed 'total_i' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 323
ERROR - 2022-10-18 16:14:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 323
ERROR - 2022-10-18 16:15:34 --> Severity: Warning --> Use of undefined constant total_i - assumed 'total_i' (this will throw an Error in a future version of PHP) C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 323
ERROR - 2022-10-18 16:15:34 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 323
ERROR - 2022-10-18 16:30:05 --> Query error: Unknown column 'acc_transaction.VDate' in 'where clause' - Invalid query: SELECT *
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `x`.`outlet_id` IS NULL
AND `HeadType` = 'I'
AND `acc_transaction`.`VDate` >= '2022-10-18'
AND `acc_transaction`.`VDate` <= '2022-10-18'
AND  `COAID` LIKE '%3040%' ESCAPE '!'
GROUP BY `a`.`HeadCode`
ERROR - 2022-10-18 16:30:05 --> Severity: error --> Exception: Call to a member function result() on bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1478
ERROR - 2022-10-18 16:31:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 16:31:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 16:31:19 --> Query error: Unknown column 'acc_transaction.VDate' in 'where clause' - Invalid query: SELECT *
FROM `acc_coa` `a`
JOIN `acc_transaction` `b` ON `a`.`HeadCode`=`b`.`COAID`
LEFT JOIN `outlet_warehouse` `x` ON `b`.`CreateBy` = `x`.`user_id`
WHERE `x`.`outlet_id` IS NULL
AND `HeadType` = 'I'
AND `acc_transaction`.`VDate` >= '2022-10-18'
AND `acc_transaction`.`VDate` <= '2022-10-18'
AND  `COAID` LIKE '%3040%' ESCAPE '!'
GROUP BY `a`.`HeadCode`
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1448
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Undefined variable: arr_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1576
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Undefined variable: arr_ind_ex C:\laragon\www\git\erp_swapon\application\models\Accounts_model.php 1577
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1188
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1188
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 16:36:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 16:36:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined index: oResultAsset C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1209
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined index: oResultLiability C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1210
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined variable: software_info C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 84
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 88
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 91
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 93
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined variable: company C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 95
ERROR - 2022-10-18 16:36:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 383
ERROR - 2022-10-18 16:36:43 --> Severity: Notice --> Undefined variable: links C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 550
ERROR - 2022-10-18 16:37:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 383
ERROR - 2022-10-18 16:38:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 383
ERROR - 2022-10-18 16:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 383
ERROR - 2022-10-18 16:46:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 400
ERROR - 2022-10-18 16:50:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 400
ERROR - 2022-10-18 16:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 400
ERROR - 2022-10-18 16:58:19 --> Query error: Illegal mix of collations (utf16_general_ci,IMPLICIT) and (utf8_general_ci,IMPLICIT) for operation '=' - Invalid query: SELECT SUM(a.stock_qty * s.supplier_price) as all_open_total
FROM `opening_inventory` `a`
LEFT JOIN `product_information` `p` ON `a`.`product_id` = `p`.`product_id`
LEFT JOIN `supplier_product` `s` ON `a`.`product_id` = `s`.`product_id`
WHERE `p`.`finished_raw` = 2
ERROR - 2022-10-18 16:58:19 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\laragon\www\git\erp_swapon\application\models\Purchases.php 1763
ERROR - 2022-10-18 16:58:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 400
ERROR - 2022-10-18 17:09:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 17:09:43 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-18 17:09:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 17:09:46 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:10:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:10:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 17:10:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:13:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 17:13:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:13:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:13:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '1'
ERROR - 2022-10-18 17:13:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\laragon\www\git\erp_swapon\system\core\Exceptions.php:271) C:\laragon\www\git\erp_swapon\system\core\Common.php 570
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:15:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:15:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 320
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 321
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 322
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 323
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 324
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 325
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:15:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 326
ERROR - 2022-10-18 17:15:27 --> Severity: Notice --> Undefined variable: first_outlet C:\laragon\www\git\erp_swapon\application\views\newaccount\trial_new.php 167
ERROR - 2022-10-18 17:18:25 --> Severity: error --> Exception: Object of class Accounts could not be converted to string C:\laragon\www\git\erp_swapon\application\controllers\Accounts.php 1307
ERROR - 2022-10-18 17:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 400
ERROR - 2022-10-18 17:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:22:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:22:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:33:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:33:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:34:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
ERROR - 2022-10-18 17:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 402
