<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-16 19:42:30 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-16 19:43:08 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
