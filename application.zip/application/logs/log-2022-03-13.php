<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-13 05:41:24 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-13 05:54:48 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6731512465', 'INV-CC', '2022-03-13', NULL, 'Courier Debit For Invoice No -  1001 Courier  Sundarban Courier', 0, 10000, 1, 'OpSoxJvBbbS8Rws', '2022-03-13 05:54:48', 1)
ERROR - 2022-03-13 05:54:48 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6731512465', 'INV-CC', '2022-03-13', NULL, 'Delivery Charge and Condition Charge For Invoice No -  1001 Courier  Sundarban Courier', 160, 0, 1, 'OpSoxJvBbbS8Rws', '2022-03-13 05:54:48', 1)
ERROR - 2022-03-13 07:11:39 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('6731512465', 'INV', '2022-03-13', NULL, 'Courier Credit For Invoice No -  1001 Courier  Sundarban Courier', 9840, 0, 1, 'OpSoxJvBbbS8Rws', '2022-03-13 07:11:39', 1)
ERROR - 2022-03-13 15:09:53 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-13 15:22:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 234
ERROR - 2022-03-13 15:23:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 234
ERROR - 2022-03-13 15:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 234
ERROR - 2022-03-13 15:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 1383
ERROR - 2022-03-13 15:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\due_invoice_list.php 68
ERROR - 2022-03-13 16:01:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:09:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:11:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:20:59 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:23:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:26:52 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:27:29 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:32:57 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:33:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:34:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:35:46 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:35:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:36:54 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:37:17 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:38:03 --> 404 Page Not Found: Cinvoice/add_new_sales
ERROR - 2022-03-13 16:38:09 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:38:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:39:27 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:39:55 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:40:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:40:38 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:41:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:41:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:42:51 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:43:07 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:43:34 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:44:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:45:39 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:46:01 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:48:03 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:48:36 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:50:50 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-13 16:51:14 --> 404 Page Not Found: My-assets/image
