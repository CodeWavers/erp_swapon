<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-22 04:43:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-22 04:43:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2657
ERROR - 2022-03-22 04:43:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-22 04:43:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2724
ERROR - 2022-03-22 04:43:53 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-22 04:49:14 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 04:49:24 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 264
ERROR - 2022-03-22 04:49:24 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 215
ERROR - 2022-03-22 04:49:24 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 264
ERROR - 2022-03-22 04:49:24 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 215
ERROR - 2022-03-22 04:49:28 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 118
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 118
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 140
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 140
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 147
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 148
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 149
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 150
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 154
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 155
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 102
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 140
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 148
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 156
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 157
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 157
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 166
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 166
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 174
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 174
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 222
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 287
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 287
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 288
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 288
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 292
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 296
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 296
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 309
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 309
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 318
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 326
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 336
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 336
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 343
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 343
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 350
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 351
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 351
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 359
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 359
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 360
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 360
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 371
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 371
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 384
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 384
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 405
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 405
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 406
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 406
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 435
ERROR - 2022-03-22 05:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 468
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 508
ERROR - 2022-03-22 05:01:02 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 508
ERROR - 2022-03-22 05:01:47 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:02:07 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:02:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:02:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:02:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:04:00 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:04:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:04:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:04:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:04:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:04:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:05:22 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:05:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:05:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:05:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:05:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:05:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:05:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:09:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:09:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:09:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:09:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:09:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:10:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:10:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:10:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:10:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:11:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:11:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:11:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:11:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:11:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:11:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:14:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:14:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:14:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:14:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:14:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:16:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:16:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:16:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:17:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:17:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:17:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:17:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:17:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:18:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:18:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:18:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:18:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:18:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:18:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:19:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:19:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:19:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:19:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:19:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:19:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:19:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:19:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:19:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:19:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:21:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:21:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:21:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:21:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:21:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:23:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:23:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:23:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:26:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:26:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:26:08 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:26:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:27:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:27:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:27:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:27:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:28:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:28:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:28:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:28:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:28:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:28:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:30:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:30:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:30:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:31:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:31:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:31:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:31:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:31:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:31:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:32:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:32:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:32:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:32:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:32:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:32:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:32:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:32:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:33:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:33:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:33:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:34:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:34:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:34:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:34:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:34:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:34:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:36:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:36:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:36:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:36:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:36:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:36:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:41:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:41:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:41:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:41:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:41:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:41:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:42:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:42:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:42:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:42:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:42:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:42:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 05:42:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 05:42:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 05:42:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 118
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'shipping_method' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 118
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 140
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'shipping_address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 140
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 147
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'email' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 148
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'phone' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 149
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'address' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 150
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'thana' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 151
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'division' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'district' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 153
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'country' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 154
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'postal_code' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 155
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'payment_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 92
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 142
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 142
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 150
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'delivery_status' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 150
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 158
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 158
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'date' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 159
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 168
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 168
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'payment_type' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 176
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 224
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 289
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 289
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 290
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'order_id' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 290
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'admin_coupon' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 294
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 298
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 298
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 311
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 313
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 313
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 320
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'shipping_cost' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 320
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 328
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'tax' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 328
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 338
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 338
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 345
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'admin_coupon_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 345
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 352
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 352
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 353
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'flat_discount' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 353
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 361
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 361
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 362
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 362
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 373
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'payment_details' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 373
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 386
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 386
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 407
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 407
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 408
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'grand_total' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 408
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 437
ERROR - 2022-03-22 05:45:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 470
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 530
ERROR - 2022-03-22 05:45:24 --> Severity: Notice --> Trying to get property 'code' of non-object C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 530
ERROR - 2022-03-22 05:50:51 --> Severity: Notice --> Undefined property: stdClass::$division C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 152
ERROR - 2022-03-22 05:51:11 --> Severity: Notice --> Undefined index: redirect_uri C:\laragon\www\git\erp_swapon\application\libraries\Lorder.php 179
ERROR - 2022-03-22 05:51:19 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-22 05:52:17 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-22 05:53:35 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-22 05:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 503
ERROR - 2022-03-22 05:53:35 --> Severity: Notice --> Undefined variable: card_list C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-22 05:53:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\purchase\add_purchase_form.php 509
ERROR - 2022-03-22 06:11:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-22 06:11:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 293
ERROR - 2022-03-22 06:11:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-22 06:11:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 294
ERROR - 2022-03-22 06:11:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-22 06:11:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-22 06:12:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 2153
ERROR - 2022-03-22 06:12:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Lreport.php 2153
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-22 06:47:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-22 06:47:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-22 06:47:25 --> 404 Page Not Found: My-assets/image
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 602
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 644
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 646
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 651
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 653
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 660
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 664
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 668
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 671
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 674
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 677
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 681
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 684
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 688
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 691
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 694
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 701
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 702
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 703
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 704
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Undefined variable: dt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 705
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Undefined variable: pt C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 706
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Undefined variable: st C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 707
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Undefined variable: con C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 708
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 709
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 710
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 711
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 712
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 713
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 714
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 715
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 716
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 717
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 718
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 719
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 720
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 721
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 723
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 724
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 725
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 727
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 728
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 729
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 730
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 738
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to get property 'first_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to get property 'last_name' of non-object C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 739
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-22 06:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 753
ERROR - 2022-03-22 06:47:47 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-03-22 06:47:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-03-22 08:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 08:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:40:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 08:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:40:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 08:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 08:41:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 08:41:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:41:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:41:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 08:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:45:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 08:45:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 08:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:45:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 08:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:46:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:46:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 08:46:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 08:46:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:46:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 08:46:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:47:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 08:47:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 08:47:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 08:47:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 08:47:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:28:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 09:28:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:28:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 09:28:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 09:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:28:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:28:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 09:28:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:28:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 09:28:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 09:28:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:29:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:29:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 09:29:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 09:29:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:29:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:29:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 09:30:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:30:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 09:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:30:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 09:30:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 09:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:31:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 09:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:31:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 09:31:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 09:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:52:04 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 466
ERROR - 2022-03-22 09:52:04 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 468
ERROR - 2022-03-22 09:52:04 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Ccourier.php 469
ERROR - 2022-03-22 09:52:04 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('5188192988', 'INV', '2022-03-22', NULL, 'Courier Credit For Invoice No -  1002 Courier  ', 237.5, 0, 1, 'OpSoxJvBbbS8Rws', '2022-03-22 09:52:04', 1)
ERROR - 2022-03-22 09:55:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:55:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 09:55:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 09:55:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:55:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 09:55:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 09:56:23 --> Severity: Notice --> Trying to get property 'id' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 268
ERROR - 2022-03-22 09:56:23 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 268
ERROR - 2022-03-22 09:56:23 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 270
ERROR - 2022-03-22 09:56:23 --> Severity: Notice --> Trying to get property 'courier_name' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 271
ERROR - 2022-03-22 09:56:23 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('359', 'INV-CC', NULL, NULL, 'Courier Debit For  e-commerce Order No -  00035984 Courier  ', 0, 75318.8, 1, 'OpSoxJvBbbS8Rws', '2022-03-22 09:56:23', 1)
ERROR - 2022-03-22 10:19:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 10:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:19:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 10:19:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 10:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:19:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 10:19:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 10:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:19:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:19:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 10:46:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:46:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 10:46:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 10:46:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:46:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 10:46:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:46:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:46:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 10:46:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 10:46:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:46:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 10:46:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:47:50 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Corder.php 270
ERROR - 2022-03-22 10:47:50 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('359', 'INV-CC', NULL, NULL, 'Courier Debit For  e-commerce Order No -  00035984 Courier  S.A Paribahan', 0, 75318.8, 1, 'OpSoxJvBbbS8Rws', '2022-03-22 10:47:50', 1)
ERROR - 2022-03-22 10:48:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 386
ERROR - 2022-03-22 10:48:33 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 386
ERROR - 2022-03-22 10:48:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 437
ERROR - 2022-03-22 10:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:48:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 10:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 10:48:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 10:48:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 10:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 11:11:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 11:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 11:11:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 11:11:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 11:11:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:11:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 11:12:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:12:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-22 11:12:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-22 11:12:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-22 11:12:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-22 11:12:00 --> 404 Page Not Found: Assets/js
