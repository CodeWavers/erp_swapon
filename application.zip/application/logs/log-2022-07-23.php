<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-23 06:23:35 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-23 09:33:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:33:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:33:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:33:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-23 09:33:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-23 09:33:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-23 09:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:44:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-23 09:44:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-23 09:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:44:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-23 09:44:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:57:38 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-23 09:57:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:57:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-23 09:57:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:57:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 09:57:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-23 10:01:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 10:01:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-23 10:01:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-23 10:01:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 10:01:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-23 10:01:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-23 13:33:39 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-07-23 14:40:36 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Credit`, `Debit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7337756211', 'INV-CC', '2022-07-23', NULL, 'Courier Credit For Invoice No -  1005 Courier  Sundarban Courier', '200', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-23 14:40:36', 1)
ERROR - 2022-07-23 14:40:36 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7337756211', 'INV', '2022-07-23', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID - 1005 Customer- karim', '549.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-23 14:40:36', 1)
ERROR - 2022-07-23 14:57:51 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '6-Sawdagar Paribahan', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 6, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 14:57:51')
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 138
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 164
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 189
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 257
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 309
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 332
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 355
ERROR - 2022-07-23 15:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\balance_sheet_new.php 392
ERROR - 2022-07-23 15:08:45 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '7-Karanfuli Paribahan', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 7, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:08:45')
ERROR - 2022-07-23 15:11:32 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '0-S.A Paribahan', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 0, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:11:32')
ERROR - 2022-07-23 15:15:31 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '9-Sawdagar Paribahan', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 9, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:15:31')
ERROR - 2022-07-23 15:19:21 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '0-Karanfuli Paribahan', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 0, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:19:21')
ERROR - 2022-07-23 15:19:28 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '11-S.A Paribahan', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 11, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:19:28')
ERROR - 2022-07-23 15:24:18 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '12-fhfghfghfg', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 12, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:24:18')
ERROR - 2022-07-23 15:28:37 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '13-ADASAS', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 13, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:28:37')
ERROR - 2022-07-23 15:37:15 --> Query error: Unknown column 'courier_id' in 'field list' - Invalid query: INSERT INTO `acc_coa` (`HeadCode`, `HeadName`, `PHeadName`, `HeadLevel`, `IsActive`, `IsTransaction`, `IsGL`, `HeadType`, `IsBudget`, `IsDepreciation`, `courier_id`, `DepreciationRate`, `CreateBy`, `CreateDate`) VALUES ('1020601', '14-sdfdsf', 'Courier Ledger', '3', '1', '0', '0', 'A', '0', '0', 14, '0', 'OpSoxJvBbbS8Rws', '2022-07-23 15:37:15')
ERROR - 2022-07-23 15:47:42 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('7337756211', 'INV', '2022-07-23', NULL, 'Customer Debit (Cash In Hand) Amount For Customer Invoice ID - 1005 Customer- karim', '349.00', 0, 1, 'OpSoxJvBbbS8Rws', '2022-07-23 15:47:42', 1)
ERROR - 2022-07-23 16:35:15 --> Severity: Notice --> Undefined variable: cuscredit C:\laragon\www\git\erp_swapon\application\models\Returnse.php 558
ERROR - 2022-07-23 16:42:33 --> Severity: Notice --> Undefined variable: cuscr C:\laragon\www\git\erp_swapon\application\models\Returnse.php 557
ERROR - 2022-07-23 16:44:14 --> Severity: Notice --> Undefined variable: cash C:\laragon\www\git\erp_swapon\application\models\Returnse.php 557
ERROR - 2022-07-23 16:45:51 --> Severity: Notice --> Undefined variable: cuscr C:\laragon\www\git\erp_swapon\application\models\Returnse.php 555
ERROR - 2022-07-23 16:46:10 --> Severity: Notice --> Undefined variable: cash C:\laragon\www\git\erp_swapon\application\models\Returnse.php 555
ERROR - 2022-07-23 16:46:28 --> Severity: Notice --> Undefined variable: cuscr C:\laragon\www\git\erp_swapon\application\models\Returnse.php 558
ERROR - 2022-07-23 16:46:28 --> Severity: Notice --> Undefined variable: corcr C:\laragon\www\git\erp_swapon\application\models\Returnse.php 559
ERROR - 2022-07-23 16:46:28 --> Severity: Notice --> Undefined variable: dc C:\laragon\www\git\erp_swapon\application\models\Returnse.php 560
ERROR - 2022-07-23 16:46:28 --> Severity: Notice --> Undefined variable: cash C:\laragon\www\git\erp_swapon\application\models\Returnse.php 561
ERROR - 2022-07-23 16:46:28 --> Severity: Notice --> Undefined variable: sale_income_dr C:\laragon\www\git\erp_swapon\application\models\Returnse.php 562
