<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-09-01 04:26:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-01 04:57:11 --> Severity: error --> Exception: syntax error, unexpected '/' C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_list.php 89
ERROR - 2022-09-01 04:58:11 --> Severity: Notice --> Undefined property: CI_Loader::$Warehouse C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_list.php 84
ERROR - 2022-09-01 04:58:11 --> Severity: error --> Exception: Call to a member function central_warehouse() on null C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_list.php 84
ERROR - 2022-09-01 04:58:21 --> Severity: error --> Exception: Call to a member function central_warehouse() on null C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_list.php 84
ERROR - 2022-09-01 04:58:22 --> Severity: error --> Exception: Call to a member function central_warehouse() on null C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_list.php 84
ERROR - 2022-09-01 05:05:24 --> 404 Page Not Found: My-assets/image
ERROR - 2022-09-01 05:32:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:32:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-01 05:32:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:32:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:32:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-01 05:32:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-01 05:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-01 05:34:02 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-01 05:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:34:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-01 05:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:43:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:43:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-01 05:43:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-01 05:43:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:43:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 05:43:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-01 06:55:08 --> The upload path does not appear to be valid.
ERROR - 2022-09-01 06:55:40 --> The upload path does not appear to be valid.
ERROR - 2022-09-01 06:56:38 --> The upload path does not appear to be valid.
ERROR - 2022-09-01 07:17:04 --> Query error: Column 'mid' cannot be null - Invalid query: INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-09-01 07:17:14 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `module` (`id`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-09-01 07:17:34 --> 404 Page Not Found: Permissionadd_menu/index
ERROR - 2022-09-01 07:17:38 --> Query error: Column 'mid' cannot be null - Invalid query: INSERT INTO `sub_module` (`id`, `mid`, `name`, `description`, `image`, `directory`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, 1)
ERROR - 2022-09-01 10:35:50 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-09-01 10:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-09-01 10:37:10 --> The upload path does not appear to be valid.
ERROR - 2022-09-01 10:37:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-09-01 10:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-09-01 10:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 703
ERROR - 2022-09-01 10:47:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
ERROR - 2022-09-01 10:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 10:49:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-09-01 10:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 10:49:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-09-01 10:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-09-01 10:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-09-01 10:53:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 704
