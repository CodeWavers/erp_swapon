<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-20 10:48:54 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 10:51:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-20 10:51:59 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-20 10:52:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-20 10:52:05 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 10:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 10:53:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-20 10:53:02 --> Severity: error --> Exception: Call to a member function row() on bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 626
ERROR - 2022-10-20 10:53:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:53:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 10:53:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:53:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 10:53:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:53:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 10:53:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 10:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 10:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:53:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 10:53:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 10:53:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 10:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:53:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:53:47 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-20 10:53:47 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-20 10:53:47 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-20 10:53:47 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-20 10:53:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
A' at line 4 - Invalid query: SELECT sum(a_qty) as totaloutletQnty
FROM `rqsn_details`
JOIN `rqsn` ON `rqsn`.`rqsn_id` = `rqsn_details`.`rqsn_id`
WHERE `rqsn`.`date` < `IS` `NULL`
AND `isaprv` = 1
AND `isrcv` = 1
AND `rqsn`.`to_id` = 'HK7TGDT69VFMXB7'
AND `product_id` = '17972P'
ERROR - 2022-10-20 10:54:11 --> Severity: Notice --> Trying to get property 'product_id' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 568
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 10:55:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 10:55:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:55:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 10:55:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 10:55:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 10:55:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:55:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined variable: columnName C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined variable: columnSortOrder C:\laragon\www\git\erp_swapon\application\models\Reports.php 400
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined variable: rowperpage C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined variable: start C:\laragon\www\git\erp_swapon\application\models\Reports.php 402
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined property: stdClass::$supplier_id C:\laragon\www\git\erp_swapon\application\models\Invoices.php 599
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined property: stdClass::$color_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 604
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined property: stdClass::$size_name C:\laragon\www\git\erp_swapon\application\models\Invoices.php 605
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined property: stdClass::$warehouse C:\laragon\www\git\erp_swapon\application\models\Invoices.php 610
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined property: stdClass::$warrenty_date C:\laragon\www\git\erp_swapon\application\models\Invoices.php 611
ERROR - 2022-10-20 10:55:36 --> Severity: Notice --> Undefined property: stdClass::$expired_date C:\laragon\www\git\erp_swapon\application\models\Invoices.php 612
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 10:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 10:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 10:55:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 10:55:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 10:55:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 10:59:37 --> The upload path does not appear to be valid.
ERROR - 2022-10-20 10:59:37 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1031
ERROR - 2022-10-20 10:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 10:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 10:59:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 10:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 10:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 235
ERROR - 2022-10-20 10:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 10:59:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 10:59:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 11:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 11:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 11:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 11:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 11:07:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 11:07:36 --> The upload path does not appear to be valid.
ERROR - 2022-10-20 11:07:36 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1031
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 11:07:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 11:09:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:09:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 11:09:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 11:09:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:09:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:09:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 11:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 11:10:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:10:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 11:10:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 11:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:10:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 11:10:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 11:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 11:11:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:11:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 11:11:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 11:11:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 11:11:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:11:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:13:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 11:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:13:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 11:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 11:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 11:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 11:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 11:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 11:15:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:15:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 11:15:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 11:15:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 11:15:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:15:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 11:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 403
ERROR - 2022-10-20 11:34:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\profit_loss.php 403
ERROR - 2022-10-20 11:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 170
ERROR - 2022-10-20 11:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\product\edit_product_form.php 484
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 12:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 12:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 12:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 12:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 283
ERROR - 2022-10-20 12:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 12:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 646
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 652
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 713
ERROR - 2022-10-20 12:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 719
ERROR - 2022-10-20 12:18:34 --> The upload path does not appear to be valid.
ERROR - 2022-10-20 12:18:34 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1031
ERROR - 2022-10-20 12:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 235
ERROR - 2022-10-20 12:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 12:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 12:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 235
ERROR - 2022-10-20 12:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 12:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 12:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 235
ERROR - 2022-10-20 12:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 12:25:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 12:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 239
ERROR - 2022-10-20 12:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 950
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 956
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 976
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-10-20 12:25:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-10-20 12:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 239
ERROR - 2022-10-20 12:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 950
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 956
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 976
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-10-20 12:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 239
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 950
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 956
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 976
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-10-20 12:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-10-20 12:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 235
ERROR - 2022-10-20 12:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 12:28:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 12:28:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 235
ERROR - 2022-10-20 12:28:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 12:28:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 239
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 950
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 956
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 976
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1017
ERROR - 2022-10-20 12:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1023
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 12:29:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 12:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 12:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 12:32:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 12:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 14:33:48 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-10-20 14:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:34:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 14:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:35:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 14:35:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:35:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 14:40:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 14:40:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 14:40:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 14:40:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 14:40:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 14:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 14:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:44:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 14:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 14:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 227
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 314
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 314
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 316
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 316
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 389
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 389
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 440
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 473
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 14:57:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:02:44 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('359', 'INV-CC', '2022-01-02', NULL, 'Customer debit For Invoice No -  1003 Customer ', '74438.8', 0, 1, 'OpSoxJvBbbS8Rws', '2022-10-20 15:02:44', 1)
ERROR - 2022-10-20 15:02:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:02:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:07:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:07:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:08:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:08:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:10:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:10:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 520
ERROR - 2022-10-20 15:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\order\order_status.php 545
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 677
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 683
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 744
ERROR - 2022-10-20 15:16:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 750
ERROR - 2022-10-20 15:21:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 15:21:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 15:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 15:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 15:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 15:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 15:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 15:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 15:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 15:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 15:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 15:29:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 15:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 15:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 15:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 15:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 15:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 15:30:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 15:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 15:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 15:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 15:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 15:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 15:32:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 15:32:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 15:32:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 15:32:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 15:32:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 15:32:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 15:32:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 15:36:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 15:36:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 15:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-10-20 15:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 395
ERROR - 2022-10-20 15:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 672
ERROR - 2022-10-20 15:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 677
ERROR - 2022-10-20 15:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 691
ERROR - 2022-10-20 15:37:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 697
ERROR - 2022-10-20 15:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 15:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 15:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 15:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 15:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 15:41:00 --> The upload path does not appear to be valid.
ERROR - 2022-10-20 15:41:04 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 15:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 15:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 15:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 15:43:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 15:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:45:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:45:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:45:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:46:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:56:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:56:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 15:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 15:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 15:57:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 239
ERROR - 2022-10-20 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 757
ERROR - 2022-10-20 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 976
ERROR - 2022-10-20 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 981
ERROR - 2022-10-20 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 995
ERROR - 2022-10-20 15:57:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\return\return_data_form.php 1001
ERROR - 2022-10-20 15:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 15:57:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 15:57:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 15:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 15:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:00:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:00:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:00:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:00:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:00:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:00:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:00:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:00:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:03:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:03:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:03:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:03:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:04:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:04:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:04:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:04:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:04:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:05:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:05:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:05:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:05:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:05:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1888
ERROR - 2022-10-20 16:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1889
ERROR - 2022-10-20 16:06:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1890
ERROR - 2022-10-20 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:12:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:13:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:13:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:13:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:13:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:13:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:13:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:13:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1888
ERROR - 2022-10-20 16:13:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1889
ERROR - 2022-10-20 16:13:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1890
ERROR - 2022-10-20 16:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1888
ERROR - 2022-10-20 16:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1889
ERROR - 2022-10-20 16:13:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\controllers\Admin_dashboard.php 1890
ERROR - 2022-10-20 16:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:14:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:14:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:14:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:14:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:14:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:14:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:14:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:14:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:14:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:14:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:14:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:20:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:20:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:20:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:20:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:20:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:21:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:21:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:21:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:22:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:22:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:22:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-20 16:22:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-10-20 16:22:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:22:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-10-20 16:22:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-20 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 16:22:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:24:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-10-20 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 703
ERROR - 2022-10-20 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 708
ERROR - 2022-10-20 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-10-20 16:24:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-10-20 16:28:33 --> The upload path does not appear to be valid.
ERROR - 2022-10-20 16:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 16:28:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 295
ERROR - 2022-10-20 16:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\report\sales_cheque_report.php 313
ERROR - 2022-10-20 16:29:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 16:29:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:29:20 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 16:32:48 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 16:32:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 16:32:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 16:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:34:00 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 16:40:35 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 16:42:17 --> 404 Page Not Found: My-assets/image
ERROR - 2022-10-20 16:45:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 253
ERROR - 2022-10-20 16:45:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 271
ERROR - 2022-10-20 16:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 263
ERROR - 2022-10-20 16:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 281
ERROR - 2022-10-20 16:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 264
ERROR - 2022-10-20 16:48:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-20 16:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 264
ERROR - 2022-10-20 16:49:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-20 16:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 264
ERROR - 2022-10-20 16:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
ERROR - 2022-10-20 16:49:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 263
ERROR - 2022-10-20 16:49:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 281
ERROR - 2022-10-20 16:49:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 264
ERROR - 2022-10-20 16:49:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\invoice.php 282
