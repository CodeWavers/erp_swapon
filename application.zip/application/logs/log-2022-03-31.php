<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-31 04:46:35 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-31 04:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-31 04:46:35 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-31 04:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-31 04:46:35 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-31 06:57:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-31 06:57:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2739
ERROR - 2022-03-31 06:57:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-31 06:57:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2806
ERROR - 2022-03-31 06:57:25 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-03-31 06:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-31 06:58:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 254
ERROR - 2022-03-31 06:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-31 06:58:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 255
ERROR - 2022-03-31 06:58:40 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-31 06:58:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 256
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 296
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 296
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 297
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 297
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 06:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined variable: nagad_list C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 06:58:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 553
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-31 06:58:48 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 559
ERROR - 2022-03-31 07:02:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 07:02:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 07:12:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 07:12:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 07:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 07:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 07:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 07:19:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 08:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 08:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 08:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 530
ERROR - 2022-03-31 08:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 536
ERROR - 2022-03-31 08:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 256
ERROR - 2022-03-31 08:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 571
ERROR - 2022-03-31 08:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 577
ERROR - 2022-03-31 08:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 256
ERROR - 2022-03-31 08:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 571
ERROR - 2022-03-31 08:47:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 577
ERROR - 2022-03-31 08:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 256
ERROR - 2022-03-31 08:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 571
ERROR - 2022-03-31 08:47:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 577
ERROR - 2022-03-31 08:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 256
ERROR - 2022-03-31 08:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 571
ERROR - 2022-03-31 08:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 577
ERROR - 2022-03-31 08:48:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 08:48:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 08:48:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 08:48:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 08:48:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 08:48:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 08:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 256
ERROR - 2022-03-31 08:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 571
ERROR - 2022-03-31 08:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 577
ERROR - 2022-03-31 08:55:43 --> Severity: error --> Exception: Call to a member function aggre_list_product() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 295
ERROR - 2022-03-31 08:56:09 --> Severity: error --> Exception: Call to a member function employee_list() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 281
ERROR - 2022-03-31 08:56:21 --> Severity: Notice --> Undefined property: Cinvoice::$Service C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 281
ERROR - 2022-03-31 08:56:21 --> Severity: error --> Exception: Call to a member function employee_list() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 281
ERROR - 2022-03-31 08:56:42 --> Severity: Notice --> Undefined property: Cinvoice::$Aggre C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 296
ERROR - 2022-03-31 08:56:42 --> Severity: error --> Exception: Call to a member function aggre_list_product() on null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 296
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 311
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 311
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 312
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 312
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 313
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 313
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 594
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 594
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 594
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 594
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 600
ERROR - 2022-03-31 08:56:58 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 600
ERROR - 2022-03-31 08:56:59 --> Severity: Notice --> Undefined index: card_no_id C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 600
ERROR - 2022-03-31 08:56:59 --> Severity: Notice --> Undefined index: card_no C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 600
ERROR - 2022-03-31 09:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:36:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:36:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:40:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:40:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:40:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:40:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:41:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:41:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:41:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:41:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:41:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:41:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:41:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:41:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:41:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:41:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:41:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:41:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:42:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:42:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:42:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:42:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:42:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:42:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:42:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:42:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:42:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:43:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:43:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:43:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:43:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:43:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:43:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:54:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:54:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 09:54:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 09:54:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 09:54:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 09:54:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:02:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:02:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 10:02:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 10:02:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:02:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:02:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 10:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:21:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 10:21:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 10:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:21:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:21:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 10:29:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:29:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 10:29:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 10:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:29:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 10:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:31:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:31:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 10:31:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:31:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 10:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 10:31:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:35:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 10:35:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 10:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:35:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 10:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:36:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:36:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 10:36:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 10:36:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 10:36:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 10:36:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:21:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:21:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:21:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:21:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:22:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:22:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:22:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:22:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:22:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:23:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:23:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:23:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:28:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:28:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:28:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:28:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:28:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:28:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:29:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:29:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:29:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:29:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:29:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:29:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:34:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:34:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:34:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:34:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:34:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:34:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:35:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:35:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:35:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:35:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:35:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:36:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:36:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:36:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:36:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:36:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:36:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:37:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:37:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:37:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:37:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:37:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:37:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:38:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:38:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:38:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:38:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:38:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:38:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:38:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:38:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:38:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:38:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:42:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:42:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-03-31 11:42:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-03-31 11:42:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-03-31 11:42:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:42:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-03-31 11:42:59 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 911
ERROR - 2022-03-31 11:42:59 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 912
ERROR - 2022-03-31 11:42:59 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\models\Invoices.php 915
