<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-05 10:51:46 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-05 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 10:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:52:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 10:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:54:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 10:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:55:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 10:56:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:56:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:56:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 10:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:57:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 10:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 10:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 10:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 11:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-05 11:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-05 11:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-05 11:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 11:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 11:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 11:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 11:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 11:46:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:33:00 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-05 12:34:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:39:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:45:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:47:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:54:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:56:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 12:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 12:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:56:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 12:56:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:56:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:56:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:56:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 12:56:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:56:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 12:56:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 12:56:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:58:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:58:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 12:58:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 12:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:58:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 12:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 12:59:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 12:59:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 12:59:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 12:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 12:59:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 12:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:00:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:00:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:00:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:00:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:00:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:00:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:00:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:00:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:00:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:01:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:01:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:01:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:01:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:01:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:01:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:01:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:01:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:02:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:02:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:02:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:02:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:02:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:02:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:02:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:02:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:02:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:02:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:02:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:07:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:07:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:07:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:08:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:08:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:08:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:08:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:08:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:08:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:08:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:08:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:08:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:08:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-05 13:08:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-11-05 13:08:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:08:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-11-05 13:08:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-05 13:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:09:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:09:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:09:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 318
ERROR - 2022-11-05 13:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 682
ERROR - 2022-11-05 13:10:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_pos_invoice_form.php 688
ERROR - 2022-11-05 13:31:55 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-05 13:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 251
ERROR - 2022-11-05 13:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 722
ERROR - 2022-11-05 13:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 728
ERROR - 2022-11-05 13:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\debit_voucher.php 156
ERROR - 2022-11-05 13:33:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\debit_voucher.php 162
ERROR - 2022-11-05 13:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\debit_voucher.php 156
ERROR - 2022-11-05 13:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\debit_voucher.php 162
ERROR - 2022-11-05 13:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\credit_voucher.php 156
ERROR - 2022-11-05 13:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\newaccount\credit_voucher.php 162
ERROR - 2022-11-05 17:42:52 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-11-05 17:43:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\controllers\Cproduct.php 54
