<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-10 05:13:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-10 05:13:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-02-10 05:13:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-10 05:13:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-02-10 05:13:31 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-02-10 05:25:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:25:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:25:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:25:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:25:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:25:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:25:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:25:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:25:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:25:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:25:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:31:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:31:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:31:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:37:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:37:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:37:23 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:37:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:37:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:37:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:42:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:42:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:42:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:42:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:42:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:42:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:47:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:47:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:47:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:47:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:47:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:48:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:48:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:48:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:49:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:49:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:49:29 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:49:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 05:49:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:49:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:54:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 05:54:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 05:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:54:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 05:54:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:01:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:01:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:01:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:01:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:01:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:01:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to get property 'supplier_price' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 1535
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:04:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:04:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:04:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:04:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:04:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:04:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:04:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:06:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:06:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:06:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:06:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:06:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:06:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:06:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:06:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:06:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:06:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:07:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:07:22 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:07:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:07:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:07:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:07:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:07:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:12:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:12:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:12:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:12:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:13:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:13:32 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:13:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:13:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:13:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:13:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:14:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:18:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:18:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:18:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:18:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:18:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:18:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:18:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:18:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:18:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:18:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:20:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:20:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:20:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:20:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:20:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:20:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:20:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:22:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:22:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:22:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:22:34 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:22:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:22:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:22:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:23:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 06:34:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:35:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:35:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:35:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:35:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:35:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:48:43 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:48:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:48:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:48:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:48:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:48:45 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:52:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:52:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:52:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:52:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:52:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:52:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:52:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:54:21 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:54:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:54:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:54:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:54:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:54:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:55:27 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:55:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:55:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:55:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 06:55:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:55:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 06:55:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 06:55:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 06:59:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 06:59:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:00:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:00:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:00:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:00:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:00:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:00:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:02:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:02:50 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:03:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:03:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:03:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:03:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:03:42 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:03:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:03:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:03:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:03:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:04:11 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:04:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:04:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:04:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:04:30 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:04:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:04:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:23 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:07:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:07:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:07:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:07:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:07:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:07:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:07:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:07:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:07:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:07:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:07:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:08:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:08:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:08:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:08:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:08:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:08:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:08:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:08:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:08:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:08:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:08:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:08:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:09:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:09:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:09:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:09:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:09:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:09:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:09:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:10:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:10:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:10:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:10:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:10:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:10:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:10:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:10:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:10:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:10:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:11:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:11:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:11:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:11:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:11:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:11:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:11:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:11:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:11:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:11:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:11:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:11:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:11:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:12:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:12:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:12:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:12:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:12:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:12:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:12:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:12:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:12:44 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:12:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:12:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:12:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:13:03 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:13:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:13:30 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:13:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:13:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:13:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:13:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:13:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:13:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:13:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:14:25 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:14:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:14:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:14:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:14:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:15:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:15:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:15:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:15:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:16:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:16:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:17:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:17:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:17:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:18:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:18:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:18:12 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:18:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:18:46 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:18:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:19:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:19:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:19:18 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:19:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:19:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:19:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:19:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:19:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:19:55 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:19:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:19:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:19:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:20:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:20:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:20:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:20:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:21:32 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:21:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:21:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:21:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:21:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:22:14 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:22:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:22:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:22:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:22:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:22:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:22:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:22:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:23:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:23:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:23:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:23:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:23:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:23:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:23:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:24:07 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:24:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:24:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:24:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:24:26 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:24:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:24:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:24:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:26:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:26:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:26:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:26:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:26:19 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:26:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:26:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:26:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:30:57 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:30:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 657
ERROR - 2022-02-10 07:30:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:31:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:31:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:31:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:31:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:31:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:33:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 658
ERROR - 2022-02-10 07:33:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 658
ERROR - 2022-02-10 07:33:12 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:33:12 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:33:12 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:33:14 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:33:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:34:10 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:34:13 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:34:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:34:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:15 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 658
ERROR - 2022-02-10 07:34:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 658
ERROR - 2022-02-10 07:34:15 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:34:15 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:34:15 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:34:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:34:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:34:17 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:34:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:34:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:19 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:35:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:35:19 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:35:19 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:35:19 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:35:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:35:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:35:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:46 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:35:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:35:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:35:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:35:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:36:04 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:36:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:36:04 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:36:04 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:36:04 --> Severity: Notice --> Undefined variable: sale_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:36:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:36:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:37:00 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:37:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:37:00 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:37:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:37:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:37:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:37:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:37:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:37:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:39:38 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:39:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:39:38 --> Severity: 8192 --> Unparenthesized `a ? b : c ? d : e` is deprecated. Use either `(a ? b : c) ? d : e` or `a ? b : (c ? d : e)` C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html_manual.php 175
ERROR - 2022-02-10 07:39:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:39:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:39:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:39:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:39:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:39:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:40:31 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:40:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:40:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:40:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:40:50 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:40:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:41:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:41:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:41:04 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:41:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:41:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:41:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:41:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:41:11 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:41:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:41:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:41:20 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:41:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:41:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:42:23 --> Severity: Notice --> Trying to get property 'aggre_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 891
ERROR - 2022-02-10 07:42:23 --> Severity: Notice --> Trying to get property 'HeadCode' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 893
ERROR - 2022-02-10 07:42:23 --> Severity: Notice --> Trying to get property 'aggre_name' of non-object C:\laragon\www\git\erp_swapon\application\models\Invoices.php 894
ERROR - 2022-02-10 07:42:23 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('9145947838', 'INV', '2022-02-10', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 9145947838 Customer- ', 0, '400', 1, 'OpSoxJvBbbS8Rws', '2022-02-10 07:42:23', 1)
ERROR - 2022-02-10 07:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:51:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:51:47 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:51:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:51:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:51:47 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:52:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:52:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:52:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-02-10 07:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:52:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:52:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: customer_address C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 92
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: customer_mobile C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 97
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: customer_email C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 100
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: is_unit C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 116
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: is_desc C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 119
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: is_serial C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 122
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: is_discount C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 126
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: discount_type C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 155
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 158
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 161
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 162
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 170
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 187
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 195
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 202
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 211
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 215
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: position C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: currency C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 219
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Undefined variable: invoice_all_data C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 07:53:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\views\invoice\invoice_html.php 222
ERROR - 2022-02-10 07:53:03 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:53:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 659
ERROR - 2022-02-10 07:53:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-02-10 07:53:05 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-02-10 07:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-02-10 07:53:05 --> 404 Page Not Found: Assets/plugins
