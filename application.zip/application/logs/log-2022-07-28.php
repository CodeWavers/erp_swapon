<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-07-28 05:24:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 05:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 05:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 05:25:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 05:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 05:25:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 05:25:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 05:26:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 05:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 05:26:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 05:26:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 05:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 05:26:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 05:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 09:57:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 10:11:39 --> Severity: error --> Exception: Class 'dompdf\DOMPDF' not found C:\laragon\www\git\erp_swapon\application\controllers\Cinvoice.php 508
ERROR - 2022-07-28 10:36:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 10:38:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 121
ERROR - 2022-07-28 10:38:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\edit_invoice_form.php 178
ERROR - 2022-07-28 10:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:45:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 10:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:45:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 10:45:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 10:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:48:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 10:48:31 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 10:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:48:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 10:48:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:51:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 10:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 10:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:51:48 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 10:51:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 10:51:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 11:26:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-28 11:26:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:26:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 11:26:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:26:22 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 11:26:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 11:26:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-28 11:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-28 11:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-28 11:33:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-28 11:35:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\quotation\quotation_form.php 251
ERROR - 2022-07-28 11:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 11:43:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 11:45:23 --> The upload path does not appear to be valid.
ERROR - 2022-07-28 11:45:23 --> Query error: Column 'COAID' cannot be null - Invalid query: INSERT INTO `acc_transaction` (`VNo`, `Vtype`, `VDate`, `COAID`, `Narration`, `Debit`, `Credit`, `IsPosted`, `CreateBy`, `CreateDate`, `IsAppove`) VALUES ('5856236157', 'INV', '2022-07-28', NULL, 'Customer credit (Cash In Hand) for Paid Amount For Customer Invoice ID - 5856236157 Customer- karim', 0, '100', 1, 'OpSoxJvBbbS8Rws', '2022-07-28 11:45:23', 1)
ERROR - 2022-07-28 11:46:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:46:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 11:46:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:46:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:46:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 11:46:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 11:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:46:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 11:46:27 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 11:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:46:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-07-28 11:50:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\git\erp_swapon\application\views\invoice\add_invoice_form.php 258
ERROR - 2022-07-28 11:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:50:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-07-28 11:50:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-07-28 11:50:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:50:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-07-28 11:50:40 --> 404 Page Not Found: Assets/plugins
