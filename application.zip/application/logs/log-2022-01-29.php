ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 389
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 389
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 394
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 394
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 395
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 395
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 396
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 396
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 397
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 397
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 398
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 398
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 399
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 399
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 400
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 400
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 401
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 401
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 402
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 403
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 404
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 404
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 405
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 405
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 406
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 406
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 407
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 407
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 408
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 409
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 409
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 410
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 410
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 411
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 411
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-01-29 11:18:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 412
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 414
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 414
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 415
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 416
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 417
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 425
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 426
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 429
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 429
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 430
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 430
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 431
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 432
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 432
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 435
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-01-29 11:18:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Linvoice.php 436
ERROR - 2022-01-29 11:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:33:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:33:54 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:33:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:34:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:34:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:34:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:34:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:35:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:35:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:35:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:35:57 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:37:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:37:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:37:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:37:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:37:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:41:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:41:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:41:43 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:41:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:41:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:44:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:44:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:44:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:44:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:44:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:50:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:50:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:50:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:50:18 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:50:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-29 11:51:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:51:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-29 11:51:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-29 11:51:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-29 11:51:24 --> 404 Page Not Found: Assets/plugins
