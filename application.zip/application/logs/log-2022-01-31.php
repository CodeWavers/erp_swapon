<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-31 04:47:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-01-31 04:47:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 11
ERROR - 2022-01-31 04:47:12 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-01-31 04:47:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\libraries\Auth.php 16
ERROR - 2022-01-31 04:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-31 04:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2646
ERROR - 2022-01-31 04:47:26 --> Severity: Notice --> Trying to access array offset on value of type bool C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-31 04:47:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\git\erp_swapon\application\models\Reports.php 2713
ERROR - 2022-01-31 04:47:26 --> Severity: Warning --> A non-numeric value encountered C:\laragon\www\git\erp_swapon\application\views\include\admin_home.php 333
ERROR - 2022-01-31 04:54:38 --> Severity: Notice --> Undefined index: qty C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 84
ERROR - 2022-01-31 04:54:38 --> Severity: Notice --> Undefined index: qty C:\laragon\www\git\erp_swapon\application\views\production\production_list_form.php 84
ERROR - 2022-01-31 05:38:36 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 05:44:45 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 05:44:52 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 05:47:28 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 06:00:07 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 06:00:29 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 06:00:40 --> Severity: Notice --> Undefined index: rqsn_no C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 661
ERROR - 2022-01-31 06:15:07 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 201
ERROR - 2022-01-31 06:23:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:23:59 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:23:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:23:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:23:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:26:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:26:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:26:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:29:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:30:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:30:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:30:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:31:52 --> Severity: Notice --> Trying to get property 'price' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 318
ERROR - 2022-01-31 06:31:52 --> Severity: Notice --> Trying to get property 'unit' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 322
ERROR - 2022-01-31 06:35:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:35:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:35:37 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:35:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:35:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:36:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:36:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:36:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:36:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:36:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:38:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:38:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:38:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:38:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:38:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:39:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:39:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:39:36 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:39:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:41:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:41:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:42:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:42:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:42:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:48:49 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:48:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:48:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:52:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 715
ERROR - 2022-01-31 06:52:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:52:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:52:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:52:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 06:52:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:52:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 06:52:56 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 06:52:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 06:52:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 07:09:17 --> Severity: Notice --> Undefined variable: closing_inventory C:\laragon\www\git\erp_swapon\application\models\Reports.php 428
ERROR - 2022-01-31 07:11:55 --> Severity: Notice --> Trying to get property 'quantity' of non-object C:\laragon\www\git\erp_swapon\application\models\Rqsn.php 201
ERROR - 2022-01-31 07:17:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 715
ERROR - 2022-01-31 08:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 08:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 08:57:16 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 08:57:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 08:57:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 08:57:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\git\erp_swapon\application\models\Production.php 967
ERROR - 2022-01-31 08:57:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 08:57:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 08:57:42 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 08:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 08:57:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:00:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:00:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:00:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:04:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:04:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:04:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:04:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:04:40 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:04:43 --> Severity: Notice --> Trying to get property 'finishing' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 287
ERROR - 2022-01-31 09:08:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:08:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:08:25 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:08:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:08:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:08:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:08:35 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:08:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:14:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:14:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:14:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:14:24 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:14:28 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 289
ERROR - 2022-01-31 09:14:28 --> Severity: Notice --> Trying to get property 'finishing' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 289
ERROR - 2022-01-31 09:15:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:15:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:15:44 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:15:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:15:47 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 289
ERROR - 2022-01-31 09:15:47 --> Severity: Notice --> Trying to get property 'finishing' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 289
ERROR - 2022-01-31 09:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:16:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:16:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:16:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:16:31 --> Severity: Notice --> Trying to get property 'isrcv' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 296
ERROR - 2022-01-31 09:17:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:17:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:17:33 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:17:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:17:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:18:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:18:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:18:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:18:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:18:01 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:18:05 --> Severity: Notice --> Trying to get property 'finishing' of non-object C:\laragon\www\git\erp_swapon\application\controllers\Cproduction.php 296
ERROR - 2022-01-31 09:21:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:21:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:21:39 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:21:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:21:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:22:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:22:07 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:22:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:22:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:28 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:22:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:22:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:22:41 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:22:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:22:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:22:51 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:22:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:22:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:23:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:23:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:23:55 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:23:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:23:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:24:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:24:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:24:09 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:24:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:24:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:24:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:24:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:24:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:24:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:35:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:35:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:35:53 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:35:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:35:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:36:00 --> Severity: Notice --> Undefined variable: closing_inventory C:\laragon\www\git\erp_swapon\application\models\Reports.php 428
ERROR - 2022-01-31 09:39:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:39:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:39:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:39:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:39:52 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:42:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:42:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:42:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:42:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:42:00 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:42:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:42:21 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 09:45:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-01-31 09:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-01-31 09:45:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2022-01-31 09:45:06 --> 404 Page Not Found: Assets/datatables
ERROR - 2022-01-31 10:26:35 --> Severity: Notice --> Undefined property: stdClass::$finishing C:\laragon\www\git\erp_swapon\application\controllers\Crqsn.php 663
